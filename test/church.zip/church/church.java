import core.main;

public class church {
	
	public static void main(String[] args){
		new main();
	}
	
}