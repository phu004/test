package core;
//determine the drawing orders for polygons and models
public class geometry {
	
	//determine which 3d model should be rendered first based on their geometry locations
	public final static boolean compareModels(model a, model b){
		if(a.getVisibility() == false)
			return false;
		if(a.getVisibility() == false)
			return true;
		
	
	
		
		polygon3D[] aPolygons = a.getBoundary();
		polygon3D[] bPolygons = b.getBoundary();
		
		float heightA = aPolygons[5].realCentre.y;
		float heightB = bPolygons[5].realCentre.y;
		float heightCamera = camera.position.y;
		
		if(heightCamera > heightA && heightA > heightB){
			boolean AIsAboveB = true;
			
			for(int i = 0; i < 6; i++){
				if(heightA < bPolygons[i].realCentre.y){
					AIsAboveB = false;
					break;
				}
					
			}
			if(AIsAboveB)
				return true;
		}
		
		
		
		if(heightCamera > heightB && heightB > heightA){
			boolean BIsAboveA = true;
			for(int i = 0; i < 6; i++){
				if(heightB < aPolygons[i].realCentre.y){
					BIsAboveA = false;
					break;
				}
					
			}
			if(BIsAboveA)
				return false;
			
		}
		
		float topA = aPolygons[4].realCentre.y;
		float topB = bPolygons[4].realCentre.y;
		float topCamera = camera.position.y;
		
		if(topCamera < topA && topA < topB){
			boolean AIsAboveB = true;
			
			for(int i = 0; i < 6; i++){
				if(topA > bPolygons[i].realCentre.y){
					AIsAboveB = false;
					break;
				}
					
			}
			if(AIsAboveB)
				return true;
		}
		
		
		
		if(topCamera < topB && topB < topA){
			boolean BIsAboveA = true;
			for(int i = 0; i < 6; i++){
				if(topB > aPolygons[i].realCentre.y){
					BIsAboveA = false;
					break;
				}
					
			}
			if(BIsAboveA)
				return false;
			
		}
		
	
		
		float frontA = aPolygons[2].realCentre.z;
		float frontB = bPolygons[2].realCentre.z;
		float frontCamera = camera.position.z;
		
		if(frontCamera > frontA && frontA > frontB){
			boolean AIsAboveB = true;
			
			for(int i = 0; i < 6; i++){
				if(frontA < bPolygons[i].realCentre.z){
					AIsAboveB = false;
					break;
				}
					
			}
			if(AIsAboveB)
				return true;
		}
		
		
		
		if(frontCamera > frontB && frontB > frontA){
			boolean BIsAboveA = true;
			for(int i = 0; i < 6; i++){
				if(frontB < aPolygons[i].realCentre.z){
					BIsAboveA = false;
					break;
				}
					
			}
			if(BIsAboveA)
				return false;
			
		}
		
		
		

		boolean insideA = true;
		boolean insideB = true;

		vector origin = new vector(0,0,0);
		for(int i = 0; i < 6; i++){
			origin.reset();
			origin.subtract(aPolygons[i].centre);
			if(origin.dot(aPolygons[i].normal) > 0)
				insideA = false;
		}

		for(int i = 0; i < 6; i++){
			origin.reset();
			origin.subtract(bPolygons[i].centre);
			if(origin.dot(bPolygons[i].normal) > 0)
				insideB = false;
		}

		if(insideA)
			return true;

		if(insideB)
			return false;

		
	
		
			


		
		vector difference = new vector(0,0,0);
		difference.set(a.getCentre());
		difference.subtract(b.getCentre());

		polygon3D comparebleA =  aPolygons[0];
		for(int i = 0; i < 6; i++){
			if(aPolygons[i].visible){
				comparebleA = aPolygons[i];
				break;
			}
		}

		for(int i = 0; i < 6; i++){
			if(aPolygons[i].visible){
				if(Math.abs(comparebleA.normal.dot(difference)) < Math.abs(aPolygons[i].normal.dot(difference)))
					comparebleA = aPolygons[i];
			}
		}

		polygon3D comparebleB =  bPolygons[0];
		for(int i = 0; i < 6; i++){
			if(bPolygons[i].visible){
				comparebleB = bPolygons[i];
				break;
			}
		}

		for(int i = 0; i < 6; i++){
			if(bPolygons[i].visible){
				if(Math.abs(comparebleB.normal.dot(difference)) < Math.abs(bPolygons[i].normal.dot(difference)))
					comparebleB = bPolygons[i];
			}
		}

		if(comparePolygons(comparebleA, comparebleB))
			return true;

		return false;
	}

	
	
	//determine which polygon should be rendered first based on their geometry locations
	public static boolean comparePolygons(polygon3D a, polygon3D b){
		if(!a.visible)
			return false;
		if(!b.visible)
			return true;

	
		if(a.tempVertex[0].z < b.tempVertex[0].z && a.tempVertex[1].z < b.tempVertex[1].z && a.tempVertex[2].z < b.tempVertex[2].z && a.tempVertex[3].z < b.tempVertex[3].z)
			return true;

		vector tempVector = new vector(0,0,0);
		
		boolean aIsAboveB = false;
		boolean bIsAboveA = false;

		boolean inside = true;
		for(int i = 0; i < b.tempVertex.length; i++){
			tempVector.set(b.tempVertex[i]);
			tempVector.subtract(a.centre);
			tempVector.unit();

			if(tempVector.dot(a.normal) > 0.0001 ){
				inside = false;
				break;
			}

		}
		if(inside)
			aIsAboveB = true;

		if(!aIsAboveB){
			inside = true;
			for(int i = 0; i <a.tempVertex.length; i++){
				tempVector.set(a.tempVertex[i]);
				tempVector.subtract(b.centre);
				tempVector.unit();

				if(tempVector.dot(b.normal) < -0.0001 ){
					inside = false;
					break;
				}
			}

			if(inside)
				aIsAboveB = true;
		}
		

		
		if(aIsAboveB)
			return true;

		return false;
	}
}
