package core;
//stores  directions of light from several light sources
public class lightSources {
	
	public static vector lightSource1 = new vector(0, -1.5f, -2f);
	public static vector lightSource2 = new vector(-1.5f, -0.25f, -2f);
	public static vector lightSource3 = new vector(0f, 0.5f, -1f);
	public static vector lightSource4 = new vector(0, 0, 1);
	public static vector lightSource5 = new vector(0, -1.5f, 0.5f);
	
	
	public static void init(){
		lightSource1.unit();
		lightSource2.unit();
		lightSource3.unit();
		lightSource4.unit();
		lightSource5.unit();
	}
	
	
	
}
