package core;
//The skybox as the background of the scene
public class skybox {
	
	private  polygon3D[] polygons; 
	
	//3D axis of the object 
	public vector iDirection, jDirection, kDirection;
	
	public skybox(){
		//the skybox is a simple cube with up to 6 different textures
		polygons = new polygon3D[6];
		
	
		
		iDirection = new vector(1,0,0);
		jDirection = new vector(0,1,0);
		kDirection = new vector(0,0,1);

		
		//vertices
		vector[] t;
		
		//we want skybox as big as possible so it will look stationary with the respect of the viewer
		t = new vector[]{put(-10, 10, 10), put(10,10, 10), put(10,-10, 10), put(-10, -10, 10)};
		polygons[0] = new polygon3D(t, put(-10.1f, 10.1, 10), put(10,10.1, 10), put(-10.1, -10.1, 10), main.textures[4], 1, 1, 1);
		
		t = new vector[]{put(10, 10, 10), put(10,10, -10), put(10,-10, -10), put(10, -10, 10)};
		polygons[1] = new polygon3D(t, put(10, 10.1, 10.1),  put(10,10.1, -10), put(10, -10.1, 10.1), main.textures[1],1,1,1);

		t = new vector[]{put(10, 10, -10), put(-10,10, -10), put(-10, -10, -10), put(10, -10, -10)};
		polygons[2] = new polygon3D(t,put(10.1, 10.1, -10), put(-10,10.1, -10), put(10.1, -10.1, -10), main.textures[2],1,1,1);

		t = new vector[]{put(-10, 10, -10), put(-10,10, 10), put(-10, -10, 10), put(-10, -10, -10)};
		polygons[3] = new polygon3D(t, put(-10, 10.1, -10.1),  put(-10,10.1, 10), put(-10, -10.1, -10.1), main.textures[3],1,1,1);

		t = new vector[]{put(-10, 10, -10), put(10,10, -10), put(10, 10, 10), put(-10, 10, 10)};
		polygons[4] = new polygon3D(t, put(-10.1, 9.95, 10.1),put(-10.1, 9.95, -10.1), put(10.1, 9.95, 10.1), main.textures[0],1,1,1);

		t = new vector[]{put(-10, -10, 10), put(10,-10, 10), put(10, -10, -10), put(-10, -10, -10)};
		polygons[5] = new polygon3D(t, put(10,-9.9, 10), put(10, -9.9, -10), put(-10, -9.9, 10), main.textures[5],1,1,1);

	
	}
	
	public void update(){
		
		for(int i = 0; i < 6; i ++){
			polygons[i].update();
		}
		
		
	}
	
	public void draw(){
		for(int i = 0; i < 6; i ++){
			polygons[i].draw();
		}
	}
	
	public vector put(double i, double j, double k){
		vector temp = new vector(0,0,0);
		temp.add(iDirection, (float)i);
		temp.add(jDirection, (float)j);
		temp.add(kDirection, (float)k);
		return temp;
	}
	
}
