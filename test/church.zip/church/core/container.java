package core;
//containers  are invisible cubes in the scene space, it partition the space
//into smaller volumes, polygons that inside different containers will never compare
//against one another during hidden surface removal. 

public class container implements model{

	//reference point of the model (in world coordinate)
	public vector start;
	
	//3d models inside the container
	public model[] models;
	
	//3d models inside the container and always drawn before anything else
	public model misc;
	
	//A rough  boundary of this model, contains 6 polygons
	public polygon3D[] boundary;
	
	//the centre of the model in world coordinate
	public vector centre;
	
	//the centre of the model in camera coordinate
	public vector tempCentre;
	
	//whether the contents of the container need to be sent to drawing pipeline
	public boolean visible;
	
	//the number of models that are enclosed inside this container 
	public int modelCount;
	
	//the reference axis of the model  (in world coordinate)
	public vector iDirection, jDirection, kDirection;
	
	
	//constructor
	public container(vector start, float l, float h, float w){
		this.start = start;
		
		iDirection = new vector(1,0,0);
		jDirection = new vector(0,1,0);
		kDirection = new vector(0,0,1);
		
		centre = start.myClone();

		tempCentre = centre.myClone();
		
		makeBoundary(l,h,w);
		
		visible = testVisibility();
		
		models = new model[50];
		
	}
	
	//Create a rough 3D cuboid boundary for this model.
	public final void makeBoundary(float l, float h, float w){
		boundary = new polygon3D[6];
		vector[] front = new vector[]{put(l, h, w), put(-l, h, w), put(-l, -h, w), put(l, -h, w)};
		boundary[0] = new polygon3D(front, null, null, null, null, 0,0,0);
		vector[] right = new vector[]{put(l, h, -w), put(l, h, w), put(l, -h, w), put(l, -h, -w)};
		boundary[1] = new polygon3D(right, null, null, null, null, 0,0,0);
		vector[] back = new vector[]{put(-l, h, -w), put(l, h, -w), put(l, -h, -w), put(-l, -h, -w)};
		boundary[2] = new polygon3D(back, null, null, null, null, 0,0,0);
		vector[] left = new vector[]{put(-l, h, w), put(-l, h, -w), put(-l, -h, -w), put(-l, -h, w)};
		boundary[3] = new polygon3D(left, null, null, null, null, 0,0,0);
		vector[] top = new vector[]{put(-l, h, w), put(l, h, w), put(l, h, -w), put(-l, h, -w)};
		boundary[4] = new polygon3D(top, null, null, null, null, 0,0,0);
		vector[] buttom = new vector[]{put(-l, -h, -w), put(l, -h, -w), put(l, -h, w), put(-l, -h, w)};
		boundary[5] = new polygon3D(buttom, null, null, null, null, 0,0,0);
	}
	
	
	//if all the boundary polygons are not visible, and the view point is not inside the model,
	//the models inside this container will not be rendered
	public  boolean testVisibility(){
		boolean inside = true;
		vector origin = new vector(0,0,0);

		for(int i = 0; i < 6; i++){
			if(boundary[i].visible)
				
				return true;
			
			origin.reset();
			origin.subtract(boundary[i].centre);
			if(origin.dot(boundary[i].normal) > 0){
				
				inside = false;
			}
		}
		return inside;
	}
	
	//get a rough 3D boundary of the model in camera coordinate
	public  polygon3D[] getBoundary(){
		return boundary;
	}

	//get centre of this model in camera coordinate
	public  vector getCentre(){
		return tempCentre;
	}
	
	//return centre in world coordinate
	public  vector getRealCentre(){
		return centre;
	}
	
	//return visibility
	public boolean getVisibility(){
		return visible;
	}
	
	//update container and its contents
	public void update(){
		//update boundary for this model
		for(int i = 0; i < boundary.length; i++){
			//update center in camera coordinate
			boundary[i].centre.set(boundary[i].realCentre);
			boundary[i].centre.subtract(camera.position);
			boundary[i].centre.rotate_XZ(camera.XZ_angle);
			boundary[i].centre.rotate_YZ(camera.YZ_angle);
		
			boundary[i].normal.set(boundary[i].realNormal);
			boundary[i].normal.rotate_XZ(camera.XZ_angle);
			boundary[i].normal.rotate_YZ(camera.YZ_angle);
			
			boundary[i].update();
		}
		
		//test if the container is visible, 
		visible = testVisibility();
	
		
		if(!visible)
			return;
		
		//update center in camera coordinate
		tempCentre.set(centre);
		tempCentre.subtract(camera.position);
		tempCentre.rotate_XZ(camera.XZ_angle);
		tempCentre.rotate_YZ(camera.YZ_angle);
		tempCentre.updateLocation();
		
	
		
		//update the models which lie inside the container
		for(int i = 0; i < modelCount; i++){
			models[i].update();
		}
		
		if(misc != null){
			
			misc.update();
		}
		
		
		//sort models inside the container, the further models will get drawn before
		//the closer models.
		if(!visible)
			return;

		int length = modelCount; // - backGroundModelCount;


		//sort models based on their geometry location
		if(((main.timer <=1) || camera.updating)){
			for(int i = 1; i < length; i++){
				for(int j = 0; j <length - i; j++){
					if(geometry.compareModels(models[j],models[j+1])){
						model temp = models[j+1];
						models[j+1] = models[j];
						models[j] = temp;
					}
				}
			}
		}
	}
	
	public void addModel(model m){
		for(int i = 0; i < models.length; i ++){
			if(models[i] == null){
				models[i] = m;
				modelCount++;
				return;
			}
		}
	}
	
	public void addMisc(model m){
		misc = m;
	}
	
	
	//draw models inside the container
	public void draw(){
		if(visible){
			if(misc != null)
				misc.draw();
			
			for(int i = 0; i < modelCount; i++){
				models[i].draw();
			}
			
			
		}
	}
	
	//iterate through each model inside the container and draw reflected image of that model.
	public void drawReflection(){
		for(int i = 0; i < models.length; i ++){
			if(models[i] != null){
				models[i].drawReflection();
			}
		}
	}
	
	//create a arbitrary vertex
	public final vector put(float i, float j, float k){
		vector temp = start.myClone();
		temp.add(iDirection, i);
		temp.add(jDirection, j);
		temp.add(kDirection, k);
		return temp;
	}

	
}
