package core;
//3d model: wall to the north of the main hall
public class wall_north extends solidObject{
	
	public wall_north(vector centre){
		//centre point of the model (in world coordinate)
		start = centre.myClone();
		this.centre = start.myClone();
		tempCentre = start.myClone();
		
		
		//define reference axis (in world coordinate)
		iDirection = new vector(1,0,0);
		jDirection = new vector(0,1,0);
		kDirection = new vector(0,0,1);
		
		//create a rough 3D cuboid boundary for this model.
		makeBoundary(0.4f, 0.6f, 0.001f);
		
		//create polygons
		makePolygons();
	}
	
	//all the polygon vertices  are hard coded here
	public void makePolygons(){
		polygons = new polygon3D[24];
		vector[] t;
		
		t = new vector[]{put(-0.4, -0.15, 0),put(0.4, -0.15, 0), put(0.4, -0.3, 0),put(-0.4, -0.3, 0)};
		polygons[0] = new polygon3D(t, t[0], t[1], t[3], main.textures[7], 4.5f,1, 6); 
		polygons[0].diffuse_I = 20;
		polygons[0].shininess = -24;
		
		
		
		double gradient = 1;
		vector top = put(0, 0.2 + gradient*0.4, 0);
		vector left1 = put(-0.1, 0.2 + gradient*0.3, 0);
		vector right1 = put(0.1, 0.2 + gradient*0.3, 0);
		vector left2 = put(-0.25, 0.2 + gradient*0.15, 0);
		vector right2 = put(0.25, 0.2 + gradient*0.15, 0);
		
		t = new vector[]{left1, top,right1, put(0.1, -0.151, 0), put(-0.1, -0.151, 0)};
		polygons[1] = new polygon3D(t, put(-0.4, -0.15, 0), put(0.4, -0.152, 0), put(-0.4, -0.3, 0), main.textures[7], 4.5f,1, 6); 
		polygons[1].diffuse_I =20;
		polygons[1].shininess = -20;
		
		t = new vector[]{put(-0.4, 0.2, 0), left2, put(-0.25, -0.15, 0), put(-0.4, -0.15, 0)};
		polygons[2] = new polygon3D(t, put(-0.4, -0.15, 0), put(0.4, -0.152, 0), put(-0.4, -0.3, 0), main.textures[7], 4.5f,1, 6); 
		polygons[2].diffuse_I = 20;
		polygons[2].shininess = -20;
		
		t = new vector[]{right2, put(0.4, 0.2, 0), put(0.4, -0.15, 0), put(0.25, -0.15, 0)};
		polygons[3] = new polygon3D(t, put(-0.4, -0.15, 0), put(0.4, -0.152, 0), put(-0.4, -0.3, 0), main.textures[7], 4.5f,1, 6); 
		polygons[3].diffuse_I = 20;
		polygons[3].shininess = -20;
		
		
		float[] heights = new float[]{0.f, 0.04f, 0.06f, 0.075f, 0.088f, 0.093f, 0.088f, 0.075f, 0.06f, 0.04f, 0.f};
		
		vector[] top1 = new vector[11];
		vector[] bottom1 = new vector[11];
		for(int i = 0; i < 11; i++){
			top1[i] = put(-0.25f + i*0.015, 0.2 + gradient*(0.15+0.015*i), 0);
			bottom1[i] = put(-0.25f + i*0.015, heights[i]+ 0.15,0);
		}
		
		for(int i = 0; i < 10; i ++){
			t = new vector[]{top1[i], top1[i+1], bottom1[i+1],bottom1[i]};
			polygons[4+i] = new polygon3D(t, put(-0.4, -0.15, 0), put(0.4, -0.152, 0), put(-0.4, -0.3, 0), main.textures[7], 4.5f,1, 6); 
			polygons[4+i].diffuse_I = 20;
		
		}
		
		vector[] top2 = new vector[11];
		vector[] bottom2 = new vector[11];
		for(int i = 0; i < 11; i++){
			top2[i] = put(0.1f + i*0.015, 0.2 + gradient*(0.15+0.015*(10-i)), 0);
			bottom2[i] = put(0.1f + i*0.015, heights[i]+ 0.15,0);
		}
		
		for(int i = 0; i < 10; i ++){
			t = new vector[]{top2[i], top2[i+1], bottom2[i+1],bottom2[i]};
			polygons[14+i] = new polygon3D(t, put(-0.4, -0.15, 0), put(0.4, -0.152, 0), put(-0.4, -0.3, 0), main.textures[7], 4.5f,1, 6); 
			polygons[14+i].diffuse_I = 20;
		
		}
		
		for(int i = 0; i < polygons.length; i++){
			if(polygons[i].type == 6){
				polygons[i].diffuse_I -=8;
			}
		}
		
	}
	
	public void drawReflection(){}
}
