package core;
//3d model: wall to the west of the main hall
public class wall_west extends solidObject{

	public wall_west(vector centre){
		//centre point of the model (in world coordinate)
		start = centre.myClone();
		this.centre = start.myClone();
		tempCentre = start.myClone();
		
		//define reference axis (in world coordinate)
		iDirection = new vector(1,0,0);
		jDirection = new vector(0,1,0);
		kDirection = new vector(0,0,1);
		
		//create a rough 3D cuboid boundary for this model.
		makeBoundary(0.001f, 0.3f, 0.6f);
		
		//create polygons
		makePolygons();
	}
	
	//all the polygon vertices  are hard coded here
	public void makePolygons(){
		polygons = new polygon3D[35];
		vector[] t;
		
		t = new vector[]{put(0, -0.148, -0.6), put(0, -0.148, 0.6), put(0, -0.3, 0.6), put(0, -0.3, -0.6)};
		polygons[0] = new polygon3D(t, put(0, 0.2, 0.38),put(0, 0.2, 0.6), put(0, -0.15, 0.38), main.textures[7], 1f,2, 6); 
		
		
		t = new vector[]{put(0, 0.2, -0.6), put(0, 0.2, -0.45), put(0, -0.15, -0.45), put(0, -0.15, -0.6)};
		polygons[1] = new polygon3D(t, put(0, 0.2, 0.38),put(0, 0.2, 0.6), put(0, -0.15, 0.38), main.textures[7], 1f,2, 6); 
		
		
		t = new vector[]{put(0, 0.2, -0.32), put(0, 0.2, -0.1), put(0, -0.15, -0.1), put(0, -0.15, -0.32)};
		polygons[2] = new polygon3D(t, put(0, 0.2, 0.38),put(0, 0.2, 0.6), put(0, -0.15, 0.38), main.textures[7], 1f,2, 6); 
	
		
		t = new vector[]{put(0, 0.2, 0.03), put(0, 0.2, 0.25), put(0, -0.15, 0.25), put(0, -0.15, 0.03)};
		polygons[3] = new polygon3D(t, put(0, 0.2, 0.38),put(0, 0.2, 0.6), put(0, -0.15, 0.38), main.textures[7], 1f,2, 6); 
		
		
		t = new vector[]{put(0, 0.2, 0.38), put(0, 0.2, 0.6), put(0, -0.15, 0.6), put(0, -0.15, 0.38)};
		polygons[4] = new polygon3D(t, put(0, 0.2, 0.38),put(0, 0.2, 0.6), put(0, -0.15, 0.38), main.textures[7], 1f,2, 6); 
	
		
		float[] heights = new float[]{0.f, 0.04f, 0.06f, 0.075f, 0.088f, 0.093f, 0.088f, 0.075f, 0.06f, 0.04f, 0.f};
		
		for(int i = 0; i < 10; i++){
			t = new vector[]{put(0, 0.2, -0.45 + 0.013*i), put(0, 0.2, -0.45 + 0.013*(i+1)), put(0, heights[i+1], -0.45+ 0.013*(i+1)), put(0, heights[i], -0.45+ 0.013*i)};
			polygons[i+ 5] = new polygon3D(t, put(0, 0.2, 0.38),put(0, 0.2, 0.6), put(0, -0.15, 0.38), main.textures[7], 1f,2, 6); 
			
		}
		
		for(int i = 0; i < 10; i++){
			t = new vector[]{put(0, 0.2, -0.1 + 0.013*i), put(0, 0.2, -0.1 + 0.013*(i+1)), put(0, heights[i+1], -0.1+ 0.013*(i+1)), put(0, heights[i], -0.1+ 0.013*i)};
			polygons[i+ 15] = new polygon3D(t, put(0, 0.2, 0.38),put(0, 0.2, 0.6), put(0, -0.15, 0.38), main.textures[7], 1f,2, 6); 
			
		}
		
		for(int i = 0; i < 10; i++){
			t = new vector[]{put(0, 0.2, 0.25 + 0.013*i), put(0, 0.2, 0.25 + 0.013*(i+1)), put(0, heights[i+1], 0.25+ 0.013*(i+1)), put(0, heights[i], 0.25+ 0.013*i)};
			polygons[i+ 25] = new polygon3D(t, put(0, 0.2, 0.38),put(0, 0.2, 0.6), put(0, -0.15, 0.38), main.textures[7], 1f,2, 6); 
		
		}
		
		
		for(int i = 0; i < polygons.length; i++){
			
			polygons[i].diffuse_I = 20;
		}
		
		for(int i = 0; i < polygons.length; i++){
			if(polygons[i].type == 6){
				polygons[i].diffuse_I -=7;
			}
		}
	}
	
	public void drawReflection(){}
}
