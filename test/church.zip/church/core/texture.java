package core;
//the texture dimension should only be power of 2
import java.awt.image.PixelGrabber;
import java.awt.*;

public class texture {
	//holds the pixel data in 15bits color format
	public short[] Texture;
	
	//hold mipmaps of the original texture
	public short[][] mipmap;
	
	
	//holds the pixel data in 24bits color format
	public int[] texture_24bits;
	
	//holds distortion information on the texture for each texel
	public byte[][] distortionMap;
	
	//dimension of the texture
	public int height, width, heightMask, widthMask, widthBits, heightBits;
	
	//temporary array for holding image pixels
	public static int[]TextureTemp;
	
	
	//produce a simple texture
	public texture(Image img, int widthBits , int heightBits, String type){
		init(img, widthBits,heightBits);
		
		//sky box texture
		if(type.equals("skybox")){
			texture_24bits = new int[width*height];
			for(int i = 0; i < width*height; i ++){
				texture_24bits[i] = TextureTemp[i];
			}
		}
		//free memory
		TextureTemp = null;
		img = null;
	}
	
	//produce texture with customised image
	public texture(int[] TextureTemp, int widthBits, int heightBits, String Type){
		this.widthBits = widthBits;
		this.heightBits = heightBits;
		
		height = (int)Math.pow(2, heightBits);
		width = (int)Math.pow(2, widthBits);
		
		//convert the color depth of the texture from 24bits to 15bits
		Texture = new short[width*height];
		float r,g,b;
		for(int i = 0; i < width*height; i ++){
			r = (TextureTemp[i] & 0x00ff0000)>>16;
			g = (TextureTemp[i] & 0x0000ff00)>>8;
			b = (TextureTemp[i] & 0x000000ff);
			r = r/8;
			g = g/8;
			b = b/8;
			Texture[i] = (short)((int)r <<10 | (int)g << 5 | (int)b);
		}
		TextureTemp = null;
	}
	
	//produce texture with distortion effect
	public texture(Image img, Image distortion, int widthBits, int heightBits, int distortionDepth, String type){
		PixelGrabber pg = init(img, widthBits,heightBits);
		
		//load distortion image 
		pg = new PixelGrabber(distortion, 0, 0, width, height, TextureTemp, 0, width);
		try {
			pg.grabPixels();
		}catch(Exception e){
			System.out.println(e);
		}
		
		//generate distortion map
		distortionMap = new byte[height*width][2];
		for(int j = 0; j < height; j++){
			for(int i = 0; i < width; i++){
				if(i != 0 && j != 0 && i != (width-1) && j != (height-1)){
					int index = i + j*width;
					//find the color gradient of the distortion image in x direction 
					distortionMap[index][0] = (byte)(((TextureTemp[index +1]&0xff) - (TextureTemp[index -1]&0xff))*distortionDepth);
					
					
					
					//find the color gradient of the distortion image in y direction 
					distortionMap[index][1] = (byte)(((TextureTemp[index + width]&0xff) - (TextureTemp[index - width]&0xff))*distortionDepth);
				}
			}
		}
		
		
		//free memory
		TextureTemp = null;
		img = null;
		distortion = null;
		
		
	}
	
	
	//produce bump mapped texture
	public texture(int mipmapLevel, Image img, int widthBits , int heightBits, String type){
		init(img, widthBits,heightBits);
		
		//create mipmap
		if(type.equals("mipmap")){
			mipmap = new short[mipmapLevel][];
		
			
			//assign the first mipmap to the original image
			mipmap[0] = Texture;
			int w = width;
			int h = height;
			
			
			for(int i = 1; i < mipmapLevel; i++){
				//each mipmap is one-fourth the total area of the previous one
				w/=2;
				h/=2;
				if(w == 0 || h ==0){
					//Minimum size of mipmap is 1 x 1
					mipmap[i] = new short[1];
					mipmap[i][0] = mipmap[i-1][0];
				}else{
					mipmap[i] = new short[w*h];
					for(int j = 0; j < h; j++){
						for(int k = 0; k < w; k++){
							int index1 = k*2 + j*2*w*2;
							int index2 = index1+1;
							int index3 = k*2 + (j*2+1)*w*2;
							int index4 = index3+1;
							
							int r1 = (mipmap[i-1][index1]& 31744) >> 10;
							int r2 = (mipmap[i-1][index2]& 31744) >> 10;
							int r3 = (mipmap[i-1][index3]& 31744) >> 10;
							int r4 = (mipmap[i-1][index4]& 31744) >> 10;
			
							int g1 = (mipmap[i-1][index1] & 992) >> 5;
							int g2 = (mipmap[i-1][index2] & 992) >> 5;
							int g3 = (mipmap[i-1][index3] & 992) >> 5;
							int g4 = (mipmap[i-1][index4] & 992) >> 5;
							
							int b1 = mipmap[i-1][index1] & 31;
							int b2 = mipmap[i-1][index2] & 31;
							int b3 = mipmap[i-1][index3] & 31;
							int b4 = mipmap[i-1][index4] & 31;
							
							int r_average = (r1 + r2 + r3 + r4)/4;
							int g_average = (g1 + g2 + g3 + g4)/4;
							int b_average = (b1 + b2 + b3 + b4)/4;
							
							mipmap[i][k + j*w] = (short)(r_average <<10 | g_average << 5 | b_average);
						}
					}
				
				}
			}
			
			
		}
		
		//free memory
		TextureTemp = null;
		img = null;
	}
	
	//Initialisation 
	private PixelGrabber init(Image img, int widthBits , int heightBits){
		this.widthBits = widthBits;
		this.heightBits = heightBits;

		height = (int)Math.pow(2, heightBits);
		width = (int)Math.pow(2, widthBits);
		
		heightMask = height -1;
		widthMask = width - 1;
		
		TextureTemp = new int[width*height];
		
		//load texture image and store it as an array of int
		PixelGrabber pg = new PixelGrabber(img, 0, 0, width, height, TextureTemp, 0, width);
		try {
			pg.grabPixels();
		}catch(Exception e){
			System.out.println(e);
		}
		
		Texture = new short[width*height];
		//convert the color depth of the texture from 24bits to 15bits
		float r, g, b;
		for(int i = 0; i < width*height; i ++){
			r = (TextureTemp[i] & 0x00ff0000)>>16;
			g = (TextureTemp[i] & 0x0000ff00)>>8;
			b = (TextureTemp[i] & 0x000000ff);
			r = r/8;
			g = g/8;
			b = b/8;
			Texture[i] = (short)((int)r <<10 | (int)g << 5 | (int)b);
		}
		
		img = null;
		
		return pg;
	}
}
