package core;
//3d models 
public class stair extends solidObject{
	public stair(vector centre){
		//centre point of the model (in world coordinate)
		start = centre.myClone();
		this.centre = start.myClone();
		tempCentre = start.myClone();
		
		//define reference axis (in world coordinate)
		iDirection = new vector(1,0,0);
		jDirection = new vector(0,1,0);
		kDirection = new vector(0,0,1);
		
		//create a rough 3D cuboid boundary for this model.
		makeBoundary(0.2f, 0.01699f, 0.15f);
		
		makePolygons();
	}

	
	//all the polygon vertices  are hard coded here
	public void makePolygons(){
		polygons = new polygon3D[27];
		vector[] t;
		
		t = new vector[]{put(-0.2, 0, 0.136), put(-0.17, 0, 0.136), put(-0.17, 0, -0.136), put(-0.2, 0, -0.136)};
		polygons[0] = new polygon3D(t, put(-0.4, 0, 0.136), put(0.4, 0, 0.136),put(-0.4, 0, -1.064), main.textures[6], 6,9, 5); 
		polygons[0].diffuse_I = 20;
		
		
		t = new vector[]{put(0.2, 0, -0.136), put(0.17, 0, -0.136), put(0.17, 0, 0.136), put(0.2, 0, 0.136)};
		polygons[1] = new polygon3D(t, put(-0.4, 0, 0.136), put(0.4, 0, 0.136),put(-0.4, 0, -1.064), main.textures[6], 6,9, 5); 
		polygons[1].diffuse_I = 20;
		
	
		t = new vector[]{put(-0.171, 0, -0.106), put(-0.1, 0, -0.106), put(-0.1, 0, -0.136), put(-0.171, 0, -0.136)};
		polygons[2] = new polygon3D(t, put(-0.4, 0, 0.136), put(0.4, 0, 0.136),put(-0.4, 0, -1.064), main.textures[6], 6,9, 5); 
		polygons[2].diffuse_I = 20;
	
		
		t = new vector[]{put(0.171, 0, -0.136), put(0.1, 0, -0.136), put(0.1, 0, -0.106), put(0.171, 0, -0.106)};
		polygons[3] = new polygon3D(t, put(-0.4, 0, 0.136), put(0.4, 0, 0.136),put(-0.4, 0, -1.064), main.textures[6], 6,9, 5); 
		polygons[3].diffuse_I = 20;
		
		
		t = new vector[]{put(-0.2, 0, 0.136), put(-0.195, 0, 0.136), put(-0.195, 0, -0.136), put(-0.2, 0, -0.136)};
		polygons[4] = new polygon3D(t, t[1], t[2], t[0], main.textures[26], 1f,1,3); 
		polygons[4].diffuse_I = 25;
		
		t = new vector[]{put(-0.1951, 0, -0.131), put(-0.1, 0, -0.131), put(-0.1, 0, -0.136), put(-0.1951, 0, -0.136)};
		polygons[5] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 1f,1,3); 
		polygons[5].diffuse_I = 25;
		
		t = new vector[]{put(0.2, 0, -0.136), put(0.195, 0, -0.136), put(0.195, 0, 0.136), put(0.2, 0, 0.136)};
		polygons[6] = new polygon3D(t, t[1], t[2], t[0], main.textures[26], 1f,1,3); 
		polygons[6].diffuse_I = 25;
		
		t = new vector[]{put(0.1951, 0, -0.136), put(0.1, 0, -0.136), put(0.1, 0, -0.131), put(0.1951, 0, -0.131)};
		polygons[7] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 1f,1,3); 
		polygons[7].diffuse_I = 25;
		
		t = new vector[]{put(-0.171, 0.017, -0.106), put(-0.1, 0.017, -0.106), put(-0.1, 0, -0.106), put(-0.171, 0, -0.106)};
		polygons[8] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 1f,1,3); 
		polygons[8].diffuse_I = 20;
		
		t = new vector[]{put(0.171, 0, -0.106), put(0.1, 0, -0.106), put(0.1, 0.0171, -0.106), put(0.171, 0.0171, -0.106)};
		polygons[9] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 1f,1,3); 
		polygons[9].diffuse_I = 20;
		
		t = new vector[]{put(-0.1, 0.017, -0.106), put(-0.1, 0.017, -0.136), put(-0.1, 0, -0.136), put(-0.1, 0, -0.106)};
		polygons[10] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 1f,1,3); 
		polygons[10].diffuse_I = 15;
		
		t = new vector[]{put(0.1, 0, -0.106), put(0.1, 0, -0.136), put(0.1, 0.017, -0.136), put(0.1, 0.017, -0.106)};
		polygons[11] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 1f,1,3); 
		polygons[11].diffuse_I = 15;
		
		t = new vector[]{put(-0.17, 0.017, 0.136), put(-0.17, 0.017, -0.106), put(-0.17, -0.001, -0.106), put(-0.17, -0.001, 0.136)};
		polygons[12] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 1f,1,3); 
		polygons[12].diffuse_I = 15;
		
		t = new vector[]{put(0.17, -0.001, 0.136), put(0.17, -0.001, -0.106), put(0.17, 0.017, -0.106), put(0.17, 0.017, 0.136)};
		polygons[13] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 1f,1,3); 
		polygons[13].diffuse_I = 15;
		
		
		
		
		
		t = new vector[]{put(-0.2, 0.001, -0.136), put(0.2, 0.001, -0.136), put(0.2, -0.017, -0.136), put(-0.2, -0.017, -0.136)};
		polygons[14] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 1f,1,3); 
		polygons[14].diffuse_I = 20;
		
		t = new vector[]{put(-0.2, 0.0005, 0.131), put(-0.2, 0.0005, -0.136),  put(-0.2, -0.0174, -0.136), put(-0.2, -0.0174, 0.131)};
		polygons[15] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 1f,1,3); 
		polygons[15].diffuse_I = 15;
		
		t = new vector[]{put(0.2, -0.0174, 0.131),  put(0.2, -0.0174, -0.136), put(0.2, 0.0005, -0.136), put(0.2, 0.0005, 0.131)};
		polygons[16] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 1f,1,3); 
		polygons[16].diffuse_I = 15;
		
		
		
		t = new vector[]{put(-0.1, 0.017, -0.136),put(0.1, 0.017, -0.136), put(0.1, 0, -0.136), put(-0.1, 0, -0.136)};
		polygons[17] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 1f,1,3); 
		polygons[17].diffuse_I = 20;
		
		t = new vector[]{put(-0.17, 0.0169, 0.136), put(0.17, 0.0169, 0.136), put(0.17, 0.0169, -0.106), put(-0.17, 0.0169, -0.106)};
		polygons[18] = new polygon3D(t, put(-0.4, 0.017, 0.136), put(0.4, 0.017, 0.136),put(-0.4, 0.017, -1.064), main.textures[6], 6,9, 5); 
		polygons[18].diffuse_I = 20;
		polygons[18].shininess = 0;
		
		
		t = new vector[]{put(-0.1, 0.0169, -0.105), put(0.1, 0.0169, -0.105), put(0.1, 0.0169, -0.136), put(-0.1, 0.0169, -0.136) };
		polygons[19] = new polygon3D(t, put(-0.4, 0.017, 0.136), put(0.4, 0.017, 0.136),put(-0.4, 0.017, -1.064), main.textures[6], 6,9, 5); 
		polygons[19].diffuse_I = 20;
		polygons[19].shininess = 0;
		
		t = new vector[]{put(-0.17, 0.017, 0.136), put(-0.165, 0.017, 0.136), put(-0.165, 0.017, -0.1061), put(-0.17, 0.017, -0.1061)};
		polygons[20] = new polygon3D(t, t[1], t[2], t[0], main.textures[26], 1f,1,3); 
		polygons[20].diffuse_I = 25;
		
		t = new vector[]{put(-0.166, 0.017, -0.101), put(-0.1, 0.017, -0.101), put(-0.1, 0.017, -0.1065), put(-0.166, 0.017, -0.1065)};
		polygons[21] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 1f,1,3); 
		polygons[21].diffuse_I = 25;
		
		t = new vector[]{put(-0.1, 0.017, -0.101), put(-0.095, 0.017, -0.101), put(-0.095, 0.017, -0.1363), put(-0.1, 0.017, -0.1363)};
		polygons[22] = new polygon3D(t, t[1], t[2], t[0], main.textures[26], 1f,1,3); 
		polygons[22].diffuse_I = 25;
		
		t = new vector[]{put(0.17, 0.017, -0.1061), put(0.165, 0.017, -0.1061), put(0.165, 0.017, 0.136), put(0.17, 0.017, 0.136)};
		polygons[23] = new polygon3D(t, t[1], t[2], t[0], main.textures[26], 1f,1,3); 
		polygons[23].diffuse_I = 25;
		
		t = new vector[]{put(0.166, 0.017, -0.1065), put(0.1, 0.017, -0.1065), put(0.1, 0.017, -0.101), put(0.166, 0.017, -0.101)};
		polygons[24] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 1f,1,3); 
		polygons[24].diffuse_I = 25;
		
		t = new vector[]{put(0.1, 0.017, -0.1363), put(0.095, 0.017, -0.1363), put(0.095, 0.017, -0.101), put(0.1, 0.017, -0.101)};
		polygons[25] = new polygon3D(t, t[1], t[2], t[0], main.textures[26], 1f,1,3); 
		polygons[25].diffuse_I = 25;
		
		t = new vector[]{put(-0.095, 0.017, -0.131), put(0.095, 0.017, -0.131), put(0.095, 0.017, -0.1363), put(-0.095, 0.017, -0.1363)};
		polygons[26] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 1f,1,3); 
		polygons[26].diffuse_I = 25;
	}
	
	public void drawReflection(){
		
	}
}
