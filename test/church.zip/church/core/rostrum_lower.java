package core;

public class rostrum_lower extends solidObject{
	public  rostrum_lower(vector centre){
		//centre point of the model (in world coordinate)
		start = centre.myClone();
		this.centre = start.myClone();
		tempCentre = start.myClone();
		
		//define reference axis (in world coordinate)
		iDirection = new vector(0.8f,0,0);
		jDirection = new vector(0,1,0);
		kDirection = new vector(0,0,0.65f);
		
		//create a rough 3D cuboid boundary for this model.
		makeBoundary(0.05f, 0.007499f, 0.05f);
		
		//create polygons
		makePolygons();
	
	}
	
	public void makePolygons(){
		polygons = new polygon3D[9];
		vector[] t;
		
		start.add(0,0.0425f,0);
		
		t = new vector[]{put(-0.04,-0.04, -0.04), put(0.04,-0.04, -0.04), put(0.04,-0.05, -0.04), put(-0.04,-0.05, -0.04)};
		polygons[0] = new polygon3D(t, t[0], t[1], t[3], main.textures[28], 2f,0.5f, 3); 
		polygons[0].diffuse_I = 25;
		
		t = new vector[]{put(-0.04,-0.05, 0.04),put(0.04,-0.05, 0.04), put(0.04,-0.04, 0.04), put(-0.04,-0.04, 0.04)};
		polygons[1] = new polygon3D(t, t[0], t[1], t[3], main.textures[28], 2f,0.5f, 3); 
		polygons[1].diffuse_I = 35;
		
		t = new vector[]{put(0.04,-0.04, -0.04), put(0.04,-0.04, 0.04), put(0.04,-0.05, 0.04), put(0.04,-0.05, -0.04)};
		polygons[2] = new polygon3D(t, t[0], t[1], t[3], main.textures[28], 2f,0.5f, 3); 
		polygons[2].diffuse_I = 30;
		
		t = new vector[]{put(-0.04,-0.05, -0.04), put(-0.04,-0.05, 0.04), put(-0.04,-0.04, 0.04), put(-0.04,-0.04, -0.04)};
		polygons[3] = new polygon3D(t, t[0], t[1], t[3], main.textures[28], 2f,0.5f, 3); 
		polygons[3].diffuse_I = 30;
		
		t = new vector[]{put(-0.035,-0.035, -0.035), put(0.035,-0.035, -0.035), put(0.04,-0.04, -0.04), put(-0.04,-0.04, -0.04)};
		polygons[4] = new polygon3D(t, put(-0.04,-0.035, -0.035),  put(0.04,-0.035, -0.035), t[3], main.textures[28], 2f,0.5f, 3); 
		polygons[4].diffuse_I = 30;
		
		t = new vector[]{put(-0.04,-0.04, 0.04), put(0.04,-0.04, 0.04), put(0.035,-0.035, 0.035),put(-0.035,-0.035, 0.035) };
		polygons[5] = new polygon3D(t, put(0.04,-0.035, 0.035),  put(-0.04,-0.035, 0.035),put(0.04,-0.04, 0.04), main.textures[28], 2f,0.5f, 3); 
		polygons[5].diffuse_I = 45;
		
		t = new vector[]{put(0.035,-0.035, -0.035), put(0.035,-0.035, 0.035),put(0.04,-0.04, 0.04), put(0.04,-0.04, -0.04)};
		polygons[6] = new polygon3D(t, put(0.035,-0.035, -0.04),  put(0.035,-0.035, 0.04),put(0.04,-0.04, -0.04), main.textures[28], 2f,0.5f, 3); 
		polygons[6].diffuse_I = 40;
		
		t = new vector[]{put(-0.04,-0.04, -0.04),put(-0.04,-0.04, 0.04), put(-0.035,-0.035, 0.035), put(-0.035,-0.035, -0.035)};
		polygons[7] = new polygon3D(t, put(-0.035,-0.035, 0.04),  put(-0.035,-0.035,-0.04),put(-0.04,-0.04, 0.04), main.textures[28], 2f,0.5f, 3); 
		polygons[7].diffuse_I = 40;
		
		t = new vector[]{put(-0.035,-0.035, 0.035), put(0.035,-0.035, 0.035), put(0.035,-0.035, -0.035), put(-0.035,-0.035, -0.035)};
		polygons[8] = new polygon3D(t, t[0], t[1], t[3], main.textures[28], 2f,2f, 3); 
		polygons[8].diffuse_I = 35;
		
		//define reflection polygons
		reflection = new polygon3D[polygons.length];
		
		vector temp = new vector(0,0,0);
		
		for(int i = 0; i < reflection.length; i++){
			t = new vector[polygons[i].vertex3D.length];
			for(int j = 0; j < t.length; j++){
				temp.set(polygons[i].vertex3D[j]); 
				temp.y = (float)(-0.066 - (temp.y - (-0.066)));
				t[t.length - 1 - j] = temp.myClone();
			}
			
			vector origin = polygons[i].origin.myClone();
			origin.y = (float)(-0.066 - (origin.y - (-0.066)));
			vector rightEnd = polygons[i].rightEnd.myClone();
			rightEnd.y = (float)(-0.066 - (rightEnd.y - (-0.066)));
			vector bottomEnd = polygons[i].bottomEnd.myClone();
			bottomEnd.y = (float)(-0.066 - (bottomEnd.y - (-0.066)));
			texture theTexture = polygons[i].myTexture;
			float scaleX = polygons[i].scaleX;
			float scaleY = polygons[i].scaleY;
			
			reflection[i] = new polygon3D(t,origin, rightEnd, bottomEnd,theTexture, scaleX, scaleY,  8);
			reflection[i].diffuse_I = polygons[i].diffuse_I- 20;
			if(reflection[i].diffuse_I< 0)
				reflection[i].diffuse_I = 1;
			if(reflection[i].diffuse_I> 10)
				reflection[i].diffuse_I = 10;
			reflection[i].diffuse_I = 0;
			
		}
	}
	
	public  void drawReflection(){}
	
	public  void drawReflections(){
		for(int i = 0; i < reflection.length; i++){
			reflection[i].update();
			reflection[i].draw();
		}
	}
}
