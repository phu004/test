package core;
//3d model: wall to the south of the main hall
public class wall_south extends solidObject{

	public wall_south(vector centre){
		//centre point of the model (in world coordinate)
		start = centre.myClone();
		this.centre = start.myClone();
		tempCentre = start.myClone();
		
		
		//define reference axis (in world coordinate)
		iDirection = new vector(1,0,0);
		jDirection = new vector(0,1,0);
		kDirection = new vector(0,0,1);
		
		//create a rough 3D cuboid boundary for this model.
		makeBoundary(0.4f, 0.6f, 0.001f);
		
		//create polygons
		makePolygons();
	}
	
	//all the polygon vertices  are hard coded here
	public void makePolygons(){
		polygons = new polygon3D[4];
		vector[] t;
		
		t = new vector[]{put(0.4, 0.2, 0), put(0.0995, 0.2, 0), put(0.0995, -0.3, 0),put(0.4, -0.3, 0)};
		polygons[0] = new polygon3D(t, put(0.4, 0.2, 0), put(0.1, 0.2, 0), put(0.4, -0.3, 0), main.textures[7], 1.6f,2.85f, 6); 
		polygons[0].diffuse_I = 20;
		
		
		t = new vector[]{put(-0.0995, 0.2, 0), put(-0.4, 0.2, 0), put(-0.4, -0.3, 0),put(-0.0995, -0.3, 0)};
		polygons[1] = new polygon3D(t, put(0.4, 0.2, 0), put(0.1, 0.2, 0), put(0.4, -0.3, 0), main.textures[7], 1.6f,2.85f, 6); 
		polygons[1].diffuse_I = 20;
		
		
		t = new vector[]{put(0.101, 0.2, 0), put(-0.101, 0.2, 0), put(-0.101, -0.05, 0),put(0.101, -0.05, 0)};
		polygons[2] = new polygon3D(t, put(0.4, 0.2, 0), put(0.1, 0.2, 0), put(0.4, -0.3, 0), main.textures[7], 1.6f,2.85f, 6); 
		polygons[2].diffuse_I = 20;
		
		t = new vector[]{put(0, 0.6, 0), put(-0.4, 0.198, 0), put(0.4, 0.198, 0)};
		polygons[3] = new polygon3D(t, put(0.4, 0.2, 0), put(0.1, 0.2, 0), put(0.4, -0.3, 0), main.textures[7], 1.6f,2.85f, 6); 
		polygons[3].diffuse_I = 20;
		
		
		for(int i = 0; i < polygons.length; i++){
			if(polygons[i].type == 6){
				polygons[i].diffuse_I -=5;
			}
		}
	}
	
	public void drawReflection(){}
}
