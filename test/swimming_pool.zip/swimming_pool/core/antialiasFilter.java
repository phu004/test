package core;

public class antialiasFilter implements Runnable{

	public static int[] screen;
	
	public static int screen_width = mainThread.screen_w;
	public static int screen_height = mainThread.screen_h;
	
	public boolean isFiltering;
	
	public static boolean AA_ON;
	
	
	public static void init(){
		screen = mainThread.screen;
		
		
		AA_ON = true;
	}
	
	public void run(){
		while(true){
			synchronized (this) {
				try {
					wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			
			if(AA_ON)
				applyAAFilter();
			
		}
	}
	
	
	

	
	public  void applyAAFilter(){
		
		isFiltering = true;
		
		int index,rowIndex;	
		int r1, r2, r3, r4, 
		g1, g2, g3, g4,
		b1,b2,b3,b4, 
		r_average, g_average, b_average, 
		color1, color2, color3, color4, color5, color6, color7, color, r, g, b;
		
		int polyIndex, polyIndex1, polyIndex2, polyIndex3;
		
		boolean equalOnX_rightEnd = false;
		boolean equalOnY_rightEnd = false;	
		boolean equalOnX_leftEnd = false;
		
		for(int i =(screen_height-2); i > 1; i--){
			int counter = 0;
			for(int j = 1; j < (screen_width-1); j++){
				index = j+ i*screen_width;
				
				polyIndex =  screen[index]&0xff000000;
				polyIndex1 = screen[index + 1]&0xff000000;
				polyIndex2 = screen[index + screen_width]&0xff000000;
				
				equalOnX_rightEnd = polyIndex == polyIndex1;
				equalOnY_rightEnd = polyIndex == polyIndex2;
				
				if(equalOnX_rightEnd && !equalOnY_rightEnd){
					applyBoxFilter(index);
					counter++;
				}else {
					if(counter > 0 && counter < 512){
						if(!equalOnX_rightEnd && !equalOnY_rightEnd){
							color3 = screen[index - counter -1];
							polyIndex3 = color3&0xff000000;
							equalOnX_leftEnd = polyIndex == polyIndex3;
							if(equalOnX_leftEnd){
								for(int k = index + screen_width - counter, c = 1; c <= counter; c++, k++){
									color1 = screen[k-screen_width];
									color2 = screen[k];
									
									r1 = (((color2&0xff0000)>>16) * c  + ((color1&0xff0000)>>16) * (counter + 1 -c)) /(counter+1);
									g1 = (((color2&0xff00)>>8) * c  + ((color1&0xff00)>>8) * (counter + 1 -c)) /(counter+1);
									b1 = ((color2&0xff) * c  + (color1&0xff) * (counter + 1 -c)) /(counter+1);
									screen[k] = (color2&0xff000000) |  r1 << 16 | g1 << 8 | b1;
								}
							}else if(counter < 64){
								int counter1 = counter/2;
								int counter2 = counter - counter1;
								
								for(int k = index - counter, c = 0; c < counter1; c++, k++){
									color1 = screen[index - counter -1];;
									color2 = screen[k];
									r1 = (((color2&0xff0000)>>16) * c  + ((color1&0xff0000)>>16) * (counter1 -c)) /counter1;
									g1 = (((color2&0xff00)>>8) * c  + ((color1&0xff00)>>8) * (counter1 -c)) /counter1;
									b1 = ((color2&0xff) * c  + (color1&0xff) * (counter1 -c)) /counter1;
							
									if((screen[k]&0xff000000) != (screen[k + screen_width]&0xff000000) && (screen[k]&0xff000000) != (screen[k - screen_width]&0xff000000))
										screen[k] = (color2&0xff000000) |  r1 << 16 | g1 << 8 | b1;
								}
								
								for(int k = index - counter + counter1, c = 0; c < counter2; c++, k++){
									color1 = screen[k];
									color2 = screen[index + 1];
									r1 = (((color2&0xff0000)>>16) * c  + ((color1&0xff0000)>>16) * (counter2 -c)) /counter2;
									g1 = (((color2&0xff00)>>8) * c  + ((color1&0xff00)>>8) * (counter2 -c)) /counter2;
									b1 = ((color2&0xff) * c  + (color1&0xff) * (counter2 -c)) /counter2;
									if((screen[k]&0xff000000) != (screen[k + screen_width]&0xff000000) && (screen[k]&0xff000000) != (screen[k - screen_width]&0xff000000))
										screen[k] = (color2&0xff000000) |  r1 << 16 | g1 << 8 | b1;
								}
							}
						}else if((equalOnX_rightEnd && equalOnY_rightEnd)){
							color3 = screen[index - counter -1];
							polyIndex3 = color3&0xff000000;
							equalOnX_leftEnd = polyIndex == polyIndex3;
							
							if(!equalOnX_leftEnd){
							
								for(int k = index + screen_width - counter, c = 0; c < counter; c++, k++){
									color1 = screen[k-screen_width];
									color2 = screen[k];
									
									r1 = (((color1&0xff0000)>>16) * c  + ((color2&0xff0000)>>16) * (counter -c)) /counter;
									g1 = (((color1&0xff00)>>8) * c  + ((color2&0xff00)>>8) * (counter -c)) /counter;
									b1 = ((color1&0xff) * c  + (color2&0xff) * (counter -c)) /counter;
								
									screen[k] = (color2&0xff000000) | r1 << 16 | g1 << 8 | b1;
								}
							}
						}
					}
					counter = 0;
				}
			}
		}
	
	
		
		boolean equalOnY_bottomEnd = false;
		boolean equalOnX_bottomEnd = false;
		boolean equalOnY_topEnd = false;
	
		for(int i =(screen_width-1); i > 1; i--){
			int counter = 0;
			for(int j = 1; j < (screen_height-1); j++){
				index = i+ j*screen_width;
				polyIndex = screen[index]&0xff000000;
				polyIndex1 = screen[index + screen_width]&0xff000000;
				polyIndex2 = screen[index + 1]&0xff000000;
				
				equalOnY_bottomEnd = polyIndex == polyIndex1;
				equalOnX_bottomEnd = polyIndex == polyIndex2;
				
				if(equalOnY_bottomEnd && !equalOnX_bottomEnd){	
					counter++;
				}else {
					if(counter > 0 && counter < 512){
						
						if(!equalOnY_bottomEnd && !equalOnX_bottomEnd ){
							color3 = screen[index - counter* screen_width - screen_width];
							polyIndex3 = color3&0xff000000;
							equalOnY_topEnd = polyIndex == polyIndex3;
								
							if(equalOnY_topEnd){
								for(int k = index - counter*screen_width + 1, c = 1; c <= counter; c++, k+=screen_width){
									color1 = screen[k-1];
									color2 = screen[k];
									r1 = (((color2&0xff0000)>>16) * c  + ((color1&0xff0000)>>16) * (counter +1 -c)) /(counter+1);
									g1 = (((color2&0xff00)>>8) * c  + ((color1&0xff00)>>8) * (counter +1 -c)) /(counter+1);
									b1 = ((color2&0xff) * c  + (color1&0xff) * (counter +1 -c)) /(counter+1);
									
									screen[k] = r1 << 16 | g1 << 8 | b1;
								}
							}
							
						}else if((equalOnY_bottomEnd && equalOnX_bottomEnd)){
							color3 = screen[index - counter* screen_width - screen_width];
							polyIndex3 = color3&0xff000000;
							equalOnY_topEnd = polyIndex == polyIndex3;
							if(!equalOnY_topEnd){
								for(int k = index - counter*screen_width + 1, c = 0; c < counter; c++, k+=screen_width){
									color1 = screen[k- 1];
									color2 = screen[k];
									
									r1 = (((color1&0xff0000)>>16) * c  + ((color2&0xff0000)>>16) * (counter -c)) /counter;
									g1 = (((color1&0xff00)>>8) * c  + ((color2&0xff00)>>8) * (counter -c)) /counter;
									b1 = ((color1&0xff) * c  + (color2&0xff) * (counter -c)) /counter;
									
									screen[k] = r1 << 16 | g1 << 8 | b1;
								}
							}
						}
						
					}
					counter = 0;
				}
			}
		}
		
		
		
		
		color1 = screen[1+2*screen_width];
		color = screen[2*screen_width];
		r1 = (color1& 0xff0000) >> 16;
		r = (color& 0xff0000) >> 16;
		g1 = (color1 & 0xff00) >> 8;
		g = (color & 0xff00) >> 8;
		b1 = color1 & 0xff;
		b = color & 0xff;
		
		for(int i = 2; i < (screen_height-1); i++){
			rowIndex = i*screen_width;
			for(int j = 0; j < (screen_width-2); j++){
				index = j + rowIndex;
				
				color2 = color;
				color = color1;
				color1 = screen[index+1];
				
				
				r2 = r;
				r = r1;
				r1 = (color1& 0xff0000) >> 16;
			
				
				g2=g;
				g = g1;
				g1 = (color1 & 0xff00) >> 8;
			
				
				b2=b;
				b = b1;
				b1 = color1 & 0xff;
				
				
				color5 = (g1 + g2 )>>1;
				color6 = (r1 + r2 )>>1;
				color7 = (b1 + b2 )>>1;
				
				if(Math.abs(color5 -g) < 48 && Math.abs(color6 -r) < 48 && Math.abs(color7 -b) < 48)
					continue;
				
				color3 = screen[index+screen_width];
				color4 = screen[index-screen_width];
				g3 = (color3 & 0xff00) >> 8;
				g4 = (color4 & 0xff00) >> 8;
				r3 = (color3& 0xff0000) >> 16;
				r4 = (color4& 0xff0000) >> 16;
				b3 = color3 & 0xff;
				b4 = color4 & 0xff;
				
				r_average = (color6 +  + r3 + r4 + (r))>>2;
				g_average = (color5 + g3 + g4 +  (g))>>2;    
				b_average = (color7  + b3 + b4 + (b))>>2;
				
			
				screen[index] = r_average <<16 | g_average << 8 | b_average;
				
			}
		}
		

		isFiltering = false;
	}
			
	public void applyBoxFilter(int index) {
		
		int leftColor = screen[index - 1];
		int rightColor = screen[index + 1];
		int topColor = screen[index - screen_width];
		int buttomColor = screen[index + screen_width];
		int topLeftColor = screen[index - 1 - screen_width];
		int buttomRightColor = screen[index + 1 + screen_width];
		int topRightColor = screen[index + 1 - screen_width];
		int buttomLeftColor = screen[index - 1 + screen_width];
		
		
		int leftIndex = leftColor&0xff000000;
		int rightIndex = rightColor&0xff000000;
		int topIndex = topColor&0xff000000;
		int buttomIndex = buttomColor&0xff000000;
		int topLeftIndex = topLeftColor&0xff000000;
		int buttomRightIndex = buttomRightColor&0xff000000;
		int topRightIndex = topRightColor&0xff000000;
		int buttomLeftIndex = buttomLeftColor&0xff000000;
		
		
		int currentIndex = screen[index]&0xff000000;
		
		if((leftIndex != currentIndex && rightIndex != currentIndex) || (topIndex != currentIndex && buttomIndex != currentIndex) ||
		   (topLeftIndex != currentIndex && buttomRightIndex != currentIndex) || (topRightIndex != currentIndex && buttomLeftIndex != currentIndex)) {
			
			int red = ((leftColor&0xff0000) >> 16) + ((rightColor&0xff0000) >> 16) + ((topColor&0xff0000) >> 16) + ((buttomColor&0xff0000) >> 16)+
					  ((topLeftColor&0xff0000) >> 16) + ((buttomRightColor&0xff0000) >> 16) + ((topRightColor&0xff0000) >> 16) + ((buttomLeftColor&0xff0000) >> 16) + ((screen[index]&0xff0000) >> 16)*4;
			int green = ((leftColor&0xff00) >> 8) + ((rightColor&0xff00) >> 8) + ((topColor&0xff00) >> 8) + ((buttomColor&0xff00) >> 8) + 
					    ((topLeftColor&0xff00) >> 8) + ((buttomRightColor&0xff00) >> 8) + ((topRightColor&0xff00) >> 8) + ((buttomLeftColor&0xff00) >> 8) + ((screen[index]&0xff00) >> 8)*4;
			int blue = ((leftColor&0xff)) + ((rightColor&0xff)) + ((topColor&0xff)) + ((buttomColor&0xff)) +
					   ((topLeftColor&0xff)) + ((buttomRightColor&0xff)) + ((topRightColor&0xff)) + ((buttomLeftColor&0xff)) + ((screen[index]&0xff))*4;
			
			screen[index] = currentIndex | (red/12) << 16 | (green/12) << 8 | (blue/12);
		}
		
	}
		
	
	
	
	

}
