import core.mainThread;

public class main {
	
	public static void main(String[] args){
		System.setProperty("sun.java2d.uiScale", "1.0");
		new mainThread();
	}
	
}