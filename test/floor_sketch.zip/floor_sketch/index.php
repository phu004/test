<?php

	if($_POST['action']=="saveFloor"){

		$filename = "floor_json/".$_POST['floorName'].".json";
		
		$myfile = fopen($filename, "w") or die("Unable to open file!");
		
		
		fwrite($myfile, $_POST['floorFile']);
		
		fclose($myfile);
		
		echo $_POST['floorFile'];
		
		exit();
	}

	$current_page = "index.php";
	
	$dir    = 'floor_png';
	$files = scandir($dir);
	$floorFiles = "";
	for($i = 0; $i < sizeof($files); $i++){
		$floorFiles = $floorFiles.$files[$i].";";
	}
?>


<html>
    <body>
        <div style="width: 99%; white-space: nowrap;">
            <div style="position: relative; overflow: scroll; display: inline-block; width: 67.5%; background: #d2d2d2; border: solid 1px #000000; height: 900px; vertical-align: bottom;">
                    <canvas id="backgroundCanvas" width = "100" height = "100" style="position: absolute; top: 0; left:0; border:0px solid #000000;">
                        Your browser does not support the HTML5 canvas tag.
                    </canvas>
                    <canvas tabIndex="0" id="myCanvas" width = "100" height = "100" onkeydown="handleKeyInput(event)" onmousemove="getMousePosition(event)" onclick="handleClick(event)" style="position: absolute; top: 0; left:0; border:0px solid #000000;">
                            Your browser does not support the HTML5 canvas tag.
                    </canvas>
            </div>
            
            <div align="left" style="display: inline-block; width: 32.5%; border: solid 1px #000000; height: 900px;  vertical-align: bottom;">
                <br>
                <form  action="" style="padding-left: 20px; width: 80%">
                    <input type="radio" name="editMode" id="select" onclick="clickRadioButton(this)" > Select object<br>
                    <input type="radio" name="editMode" id="wall" onclick="clickRadioButton(this)"> Add wall<br>
                    <input type="radio" name="editMode" id="door" onclick="clickRadioButton(this)"> Add door<br>
                    <input type="radio" name="editMode" id="stair" onclick="clickRadioButton(this)"> Add stair<br>
                    <input type="radio" name="editMode" id="lift" onclick="clickRadioButton(this)"> Add lift<br>
                    <input type="radio" name="editMode" id="exit" onclick="clickRadioButton(this)"> Add exit<br>
                    <input type="radio" name="editMode" id="paw" onclick="clickRadioButton(this)"> Add paw<br>
                </form>
           
				<label style="padding-left: 25px;">In select mode, press backspace to remove selected item.</label><br>
				<label style="padding-left: 25px;">In other modes, press backspace to remove the last created item.</label><br><br><br>
				
                <div  id="object_info" onkeydown="handleInformationDivEvent(event)" style="padding-left: 20px; width: 80%">
                   
                </div> 
			
				<br><br><br>
				
				<div   style="padding-left: 20px; width: 80%">
					<p>Select A Floor To Edit</p>
					<select id="changeFloorSelect" onchange="changeFloor(this)" style="width: 160px">
						<option value="">
					</select>
				</div>
				
				<br><br><br>
				
				<div   style="padding-left: 20px; width: 80%">
					<button onclick="saveFloor()" style="">Save Floor</button>
				</div>

            </div>
        </div>
    </body> 
</html>

<script src="wall.js?<?php echo rand();?>" type="text/javascript"></script>
<script src="door.js?<?php echo rand();?>" type="text/javascript"></script>
<script src="stair.js?<?php echo rand();?>" type="text/javascript"></script>
<script src="lift.js?<?php echo rand();?>" type="text/javascript"></script>
<script src="exit.js?<?php echo rand();?>" type="text/javascript"></script>
<script src="paw.js?<?php echo rand();?>" type="text/javascript"></script>
<script src="path.js?<?php echo rand();?>" type="text/javascript"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script>
	
	var selectedFloor = "";
	var floorFiles = "<?php echo $floorFiles ?>".split(";");
	for(var i = 0; i < floorFiles.length; i++){
		if(floorFiles[i] != "" && floorFiles[i] != "." && floorFiles[i] != ".."){
			var opt = document.createElement('option');
			opt.innerHTML = floorFiles[i].split(".")[0];
			opt.value = floorFiles[i];
			document.getElementById("changeFloorSelect").appendChild(opt);
		}
	}
	
    var backgroundCanvas = document.getElementById("backgroundCanvas");
    var backgroundCtx = backgroundCanvas.getContext("2d");

    var c = document.getElementById("myCanvas");
    var ctx = c.getContext("2d");

    var img = new Image();

    var stairImg = new Image();
    stairImg.src = 'img/stair.png';

    var liftImg = new Image();
    liftImg.src = 'img/lift.png';

    var exitImg = new Image();
    exitImg.src = 'img/exit.png';

    var pawImg = new Image();
    pawImg.src = 'img/paw.png';

    
    var editMode = "";
    var objects = [];
    var pathNodes = [];
    var selectedObject = null;
    var firstClickX = "";
    var firstClickY = "";
    var secondClickX = "";
    var secondClickY = "";
    var mouseX = "";
    var mouseY = "";
    var mouseClicked = false;
    var needToRecalculatePath = false;

    function clickRadioButton(element){
        editMode = element.id;
        firstClickX = "";
        firstClickY = "";
        secondClickX = "";
        secondClickY = "";
        if(selectedObject != null)
            selectedObject.isSelected = false;

        var infoDiv = document.getElementById("object_info");
        while (infoDiv.firstChild) {
            infoDiv.removeChild(infoDiv.firstChild);
        }

        c.focus();
    }
    
    //start canvas animation loop
    setInterval(repaintCanvas, 20);

    function repaintCanvas(){
        ctx.clearRect(0, 0, c.width, c.height);
		
		if(selectedFloor == "")
			return;

        //draw objects
        for(var i = 0; i < objects.length; i++){
            if(objects[objects.length - 1 - i] != null)
                objects[objects.length - 1 - i].draw();
        }

        //console.log(path.indexNumber);

        //handle  object creation
        if(editMode == "wall"){
            wall.handleCreation();
        }else if(editMode == "door"){
            door.handleCreation();
        }else if(editMode == "stair"){
            stair.handleCreation();
        }else if(editMode == "lift"){
            lift.handleCreation();
        }else if(editMode == "exit"){
            exit.handleCreation();
        }else if(editMode == "paw"){
            paw.handleCreation();
        }

        //handle object selection
        if(editMode == "select"){
            //check if the mouse cursor is on top of an object
            for(var i = 0; i < objects.length; i++){
                if(objects[i] != null){
                    if(objects[i].isSelectable(mouseX, mouseY)){
                        objects[i].isHighLighted = true;
                        
                        if(mouseClicked){
                            if(selectedObject!= null)
                                selectedObject.isSelected = false;
                            selectedObject =  objects[i];
                            objects[i].isSelected = true;
                            objects[i].createInfo(this);
                        }
                        break;
                    }
                }
            }
        }

        if(needToRecalculatePath){
            recalculatePath();
        }
        
        mouseClicked = false;
        needToRecalculatePath = false;
    }

    function handleClick(event){
        if(selectedFloor == "")
			return;
		
		var x = event.offsetX;
        var y = event.offsetY;
       
        if(firstClickX == ""){
            firstClickX = x;
            firstClickY = y; 
        }else if(secondClickX == ""){
            secondClickX = x;
            secondClickY = y;
            if(Math.abs(firstClickX - x) < 5)
                secondClickX = firstClickX;
            if(Math.abs(firstClickY - y) < 5)
                secondClickY = firstClickY;
        }else if(secondClickX != ""){
            firstClickX = secondClickX;
            firstClickY = secondClickY;
            secondClickX = x;
            secondClickY = y;
            if(Math.abs(firstClickX - x) < 7)
                secondClickX = firstClickX;
            if(Math.abs(firstClickY - y) < 7)
                secondClickY = firstClickY;
        }

       mouseClicked = true;
    }

    function getMousePosition(event){
        mouseX = event.offsetX;
        mouseY = event.offsetY;
    }
    
    function handleKeyInput(event){
        
        if(event.keyCode == "27") {
            firstClickX = "";
            firstClickY = "";
            secondClickX = "";
            secondClickY = "";
        }

        if(event.keyCode == "8") {

            firstClickX = "";
            firstClickY = "";
            secondClickX = "";
            secondClickY = "";

            var infoDiv = document.getElementById("object_info");
            while (infoDiv.firstChild) {
                infoDiv.removeChild(infoDiv.firstChild);
            }
            
            if(editMode == "select"){
                if(selectedObject != null)
                    for(var i = 0; i < objects.length; i++){
                        if(objects[i] === selectedObject){
                            objects[i].cleanUp(objects);
                            objects[i] = null;
                            selectedObject = null;
                            needToRecalculatePath = true;
                            break;
                        }
                    }
            }else{
                if(editMode == "door"){
                    for(var i = 0; i < objects.length; i++){
                        if(objects[i] != null && objects[i].type == editMode){
                            objects[i].cleanUp(objects);
                            objects[i] = null;
                            needToRecalculatePath = true;
                            break;
                        }
                    }
                }else{
                    for(var i = 0; i < objects.length; i++){
                        if(objects[objects.length - 1 - i] != null && objects[objects.length - 1 - i].type == editMode){
                            objects[objects.length - 1 - i].cleanUp(objects);
                            objects[objects.length - 1 - i] = null;
                            needToRecalculatePath = true;
                            break;
                        }
                    }
                }
            }
        }
    }

    function handleInformationDivEvent(event){
        if(event.keyCode == "27") {
            c.focus();
        }
    }

    function createElementFromHTML(htmlString) {

        var div = document.createElement('div');
        div.innerHTML = htmlString.trim();

        // Change this to div.childNodes to support multiple top-level nodes
        return div.firstChild; 
    }
    
	function recalculatePath(){
        //remove exisiting path and destinations
        path.indexNumber = 0;
        pathNodes = [];
        for(var i = 0; i < objects.length; i++){
           if(objects[i] != null && objects[i].type == "path"){
                objects[i].cleanUp(objects);
                objects[i] = null;
            }
            if(objects[i] != null && (objects[i].type == "stair" || objects[i].type == "paw" || objects[i].type == "exit" || objects[i].type == "lift")){
                pathNodes.push(objects[i]);
                objects[i].destinations = [];
            }
        }
       
       //remove empty objects
        objects = objects.filter(function (el) {
            return el != null;
        });
        
        //reconstruct path
        for(var i = 0; i < objects.length; i++){
            if(objects[i] != null && objects[i].type == "paw"){
                objects[i].constructPath(objects);
            }
        }
	}
   
	function saveFloor(){
		firstClickX = "";
		firstClickY = "";
		secondClickX = "";
		secondClickY = "";
		
		if(selectedFloor == "")
			return;
		
		//create the json file for the current floor
		var floorJson = generateFloorFile();
		
		$.ajax({
			type: 'POST',
			url: "<?php echo $current_page ?>",
			data : { action : 'saveFloor',
                     floorName: selectedFloor.split(".")[0],
					 floorFile: floorJson
			},
			success: function(msg){ 
				console.log(msg);
			},
			async:false
		});
	}
	
	function changeFloor(mySelect){
		selectedFloor = mySelect.value;
		objects = [];
		pathNodes = [];
		selectedObject = null;
		firstClickX = "";
		firstClickY = "";
		secondClickX = "";
		secondClickY = "";
		mouseX = "";
		mouseY = "";
		mouseClicked = false;
		needToRecalculatePath = false;
		
		door.indexNumber = 0;
		wall.indexNumber = 0;
		stair.indexNumber = 0;
		path.indexNumber = 0;
		lift.indexNumber = 0;
		exit.indexNumber = 0;
		paw.indexNumber = 0;
		
		var infoDiv = document.getElementById("object_info");
        while (infoDiv.firstChild) {
            infoDiv.removeChild(infoDiv.firstChild);
        }
		
		if(selectedFloor == ""){
			backgroundCtx.globalAlpha = 1;
			backgroundCtx.fillStyle = "lightgray";
			backgroundCtx.fillRect(0, 0, backgroundCanvas.width, backgroundCanvas.height);
			backgroundCanvas.width = 50;
			backgroundCanvas.height = 50;
			c.width = 50;
			c.height = 50;
			
		}else{
			img.src = 'floor_png/' + selectedFloor;
			
			img.onload = function(){
			
				backgroundCanvas.width = img.width;
				backgroundCanvas.height = img.height;
			   
				c.width = img.width;
				c.height = img.height;
				
				backgroundCtx.fillStyle = "white";
				backgroundCtx.fillRect(0, 0, backgroundCanvas.width, backgroundCanvas.height);

				backgroundCtx.globalAlpha = 0.4;
				backgroundCtx.drawImage(img, 0, 0);
			}
			//load json file to poplulate the floor map
			$.ajaxSetup({ cache: false });
			$.getJSON("floor_json/" + selectedFloor.split(".")[0] + ".json", function(result){
				
				//load walls
				for(var i = 0; i < result.walls.length; i++){
					if(wall.indexNumber < result.walls[i].id.split("_")[1])
						wall.indexNumber = result.walls[i].id.split("_")[1];
					var newWall = new wall(result.walls[i].x1, result.walls[i].y1, result.walls[i].x2, result.walls[i].y2);
					newWall.id = result.walls[i].id;
					objects.push(newWall);
				}
				
				//load doors;
				for(var i = 0; i < result.doors.length; i++){
					if(door.indexNumber < result.doors[i].id.split("_")[1])
						door.indexNumber = result.doors[i].id.split("_")[1];
					var myWall = null;
					for(var j = 0; j < objects.length; j++){
						if(objects[j].id == result.doors[i].myWall)
							myWall = objects[j];
					}
					var newDoor = new door(myWall,  result.doors[i].x,  result.doors[i].y);
					newDoor.id = result.doors[i].id;
					newDoor.roomNumber = result.doors[i].doorNumber;
					objects.unshift(newDoor);
				}
				
				//load exits
				for(var i = 0; i < result.exits.length; i++){
					if(exit.indexNumber < result.exits[i].id.split("_")[1])
						exit.indexNumber = result.exits[i].id.split("_")[1];
					var newExit = new exit(result.exits[i].x, result.exits[i].y);
					newExit.id = result.exits[i].id;
					newExit.exitFloorName = result.exits[i].exitFloorName;
					objects.push(newExit);
				}
				
				//load stairs
				for(var i = 0; i < result.stairs.length; i++){
					if(stair.indexNumber < result.stairs[i].id.split("_")[1])
						stair.indexNumber = result.stairs[i].id.split("_")[1];
					var newStair = new stair(result.stairs[i].x, result.stairs[i].y);
					newStair.id = result.stairs[i].id;
					newStair.upstairFloorName = result.stairs[i].upstairFloorName;
					newStair.downstairFloorName = result.stairs[i].downstairFloorName;
					objects.push(newStair);
				}
				
				//load lifts
				for(var i = 0; i < result.lifts.length; i++){
					if(lift.indexNumber < result.lifts[i].id.split("_")[1])
						lift.indexNumber = result.lifts[i].id.split("_")[1];
					var newLift = new lift(result.lifts[i].x, result.lifts[i].y);
					newLift.id = result.lifts[i].id;
					for(var j = 0; j < result.lifts[i].floors.length; j++)
						newLift.floors.push(result.lifts[i].floors[j]);
					objects.push(newLift);
				}
				
				//load paws
				for(var i = 0; i < result.paws.length; i++){
					if(exit.indexNumber < result.paws[i].id.split("_")[1])
						exit.indexNumber = result.paws[i].id.split("_")[1];
					var newPaw = new paw(result.paws[i].x, result.paws[i].y);
					newPaw.id = result.paws[i].id;
					newPaw.pawNumber = result.paws[i].pawNumber;
					objects.push(newPaw);
				}
				
				
			});
			$.ajaxSetup({ cache: true });
		}
		
		
	}
	
	function generateFloorFile(){
		var floorJson = "";
		
		
		floorJson+="{\n";
		floorJson+=('    "floorName": "' + selectedFloor.split(".")[0] + '",\n\n');
			
		//create doors as json
		floorJson+=('    "doors": [\n');
		floorJson+= door.createJson();
		floorJson+=('    ],\n\n');
		
		//create paws as json
		floorJson+=('    "paws": [\n');
		floorJson+= paw.createJson();
		floorJson+=('    ],\n\n');
		
		//create lifts as json
		floorJson+=('    "lifts": [\n');
		floorJson+= lift.createJson();
		floorJson+=('    ],\n\n');
		
		//create stairs as json
		floorJson+=('    "stairs": [\n');
		floorJson+= stair.createJson();
		floorJson+=('    ],\n\n');
		
		//create exits as json
		floorJson+=('    "exits": [\n');
		floorJson+= exit.createJson();
		floorJson+=('    ],\n\n');
			
		//create walls as json
		floorJson+=('    "walls": [\n');
		floorJson+= wall.createJson();
		floorJson+=('    ]\n\n');
		
		floorJson+="}\n";
		
		
		
		return floorJson;
	}

</script>    