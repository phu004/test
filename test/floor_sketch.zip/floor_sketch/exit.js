//static variable for ID generation
exit.indexNumber = 0;

function exit(mouseX, mouseY){
    this.type = "exit";
  
    exit.indexNumber++;
    this.id = "exit_" + exit.indexNumber;

    this.exitFloorName = "";
   

    this.isHighLighted = false;
    this.isSelected = false;

    this.x = mouseX;
    this.y = mouseY;

    this.isHighLighted = false;

    needToRecalculatePath = true;

    this.destinations = [];

    this.draw = function(){
       
        if(this.isHighLighted || this.isSelected){

            ctx.globalAlpha = 0.85;
            ctx.drawImage(exitImg, this.x - 25, this.y - 25);
          
            ctx.globalAlpha = 0.3;
            ctx.drawImage(exitImg, this.x - 26, this.y - 26, 52,52);
            ctx.globalAlpha = 0.3;
            ctx.drawImage(exitImg, this.x - 27, this.y - 27, 54,54);
            
        }else{
            ctx.globalAlpha = 0.65;
            ctx.drawImage(exitImg, this.x - 25, this.y - 25);
        }

        var myColor = 'green';
        if(this.exitFloorName == "")
            myColor = 'red';
        ctx.beginPath();
        ctx.globalAlpha = 0.6;
        ctx.arc(this.x, this.y - 20, 4, 0, 2 * Math.PI, true);
        ctx.fillStyle = myColor;
        ctx.fill();
        
        this.isHighLighted = false;
    };

    //check if the current mouse cursor is on top of the exit object
    this.isSelectable = function(mouseX,mouseY){
       
        var distance = Math.sqrt((mouseX - this.x) * (mouseX - this.x) + (mouseY - this.y) * (mouseY - this.y));

        if(distance > 25)
            return false;
        
            return true;
    };

    this.createInfo = function(){
        var infoDiv = document.getElementById("object_info");
        while (infoDiv.firstChild) {
            infoDiv.removeChild(infoDiv.firstChild);
        }
        infoDiv.appendChild(createElementFromHTML('<p>Exit floor name:</p><br>'));
        var exitInput = createElementFromHTML('<input id="exitInput" onkeyup="exit.saveExitFloorName(this, '+ "'" + this.id +  "'" + ')" style="width: 160px" value="' + this.exitFloorName +'"></input><br><br>');
        infoDiv.appendChild(exitInput);
        exitInput.focus();

    }

    //clean up function
    this.cleanUp = function(objects){
    
    }

    
};

exit.handleCreation = function(){
    //check if the mouse cursor is on top of a wall object
    if(mouseClicked){
        var newexit = new exit(mouseX, mouseY);
        objects.push(newexit);
        newexit.createInfo();
    }
}

exit.saveExitFloorName = function(myInput, exitID){
    for(var i = 0; i < objects.length; i++){
        if(objects[i] != null && objects[i].id == exitID){
            objects[i].exitFloorName = myInput.value;
            break;
        }
    }
}

exit.createJson = function(){
	var exitJson = "";
	for(var i = 0; i < objects.length; i++){
		if(objects[i] != null && objects[i].type == "exit"){
			exitJson+=('		{"id": "' + objects[i].id + '", ');
			exitJson+=('"x": ' + objects[i].x + ', ');
			exitJson+=('"y": ' + objects[i].y + ', ');
			exitJson+=('"exitFloorName": "' + objects[i].exitFloorName + '", ');
			
			var nearbypaws = "[";
			for(var j = 0; j < objects.length; j++){
				if(objects[j] != null && objects[j].type == "path"){
					if(objects[j].startNode === objects[i])
						nearbypaws+=('"' + objects[j].endNode.id + '", ');
					else if(objects[j].endNode === objects[i])
						nearbypaws+=('"' + objects[j].startNode.id + '", ');
				}
			}
			if(nearbypaws.length > 2)
				nearbypaws = nearbypaws.substring(0, nearbypaws.length - 2);
			nearbypaws+="]";
			exitJson+=('"nearbypaws": ' + nearbypaws);
			exitJson+="},\n";
		}
	}
	
	if(exitJson.length > 2)
		exitJson = exitJson.substring(0, exitJson.length - 2) + "\n";
	
	return exitJson;
}
