//static variable for ID generation
lift.indexNumber = 0;

function lift(mouseX, mouseY){
    this.type = "lift";
  
    lift.indexNumber++;
    this.id = "lift_" + lift.indexNumber;

    this.isHighLighted = false;
    this.isSelected = false;

    this.x = mouseX;
    this.y = mouseY;

    this.floors = [];

    this.isHighLighted = false;

    needToRecalculatePath = true;

    this.destinations = [];

    this.draw = function(){
        

        if(this.isHighLighted || this.isSelected){
            ctx.globalAlpha = 0.85;
            ctx.drawImage(liftImg, this.x - 25, this.y - 25);

            ctx.globalAlpha = 0.3;
            ctx.drawImage(liftImg, this.x - 26, this.y - 26, 52,52);
            ctx.globalAlpha = 0.3;
            ctx.drawImage(liftImg, this.x - 27, this.y - 27, 54,54);
            
        }else{
            ctx.globalAlpha = 0.65;
            ctx.drawImage(liftImg, this.x - 25, this.y - 25);
        }

        var myColor = 'green';
        if(this.floors.length == 0)
            myColor = 'red';
        ctx.beginPath();
        ctx.globalAlpha = 0.6;
        ctx.arc(this.x + 17, this.y - 26, 4, 0, 2 * Math.PI, true);
        ctx.fillStyle = myColor;
        ctx.fill();

        this.isHighLighted = false;

    };

    //check if the current mouse cursor is on top of the lift object
    this.isSelectable = function(mouseX,mouseY){
       
        var distance = Math.sqrt((mouseX - this.x) * (mouseX - this.x) + (mouseY - this.y) * (mouseY - this.y));

        if(distance > 25)
            return false;
        
            return true;
    };

    this.createInfo = function(){
        var infoDiv = document.getElementById("object_info");
        while (infoDiv.firstChild) {
            infoDiv.removeChild(infoDiv.firstChild);
        }
       
        infoDiv.appendChild(createElementFromHTML('<p>New floor name:</p><br>'));
        var floorInput = createElementFromHTML('<input id="newFloorInput" style="width: 160px"></input>');
        infoDiv.appendChild(floorInput);

        var space = createElementFromHTML('&nbsp;');
        infoDiv.appendChild(space);

        var addFloorButton = createElementFromHTML('<button onclick="lift.addNewFloor('+  "'" + this.id +  "'" + ')">Add floor</button>');
        infoDiv.appendChild(addFloorButton);

        var newLine1 = createElementFromHTML('<br>');
        infoDiv.appendChild(newLine1);
        var newLine2 = createElementFromHTML('<br>');
        infoDiv.appendChild(newLine2);

        var floorList =  createElementFromHTML('<select id="floorSelect" size="8" style="width: 160px"></select>');
        infoDiv.appendChild(floorList);

        for(var i = 0; i < this.floors.length; i++){
            var opt = document.createElement('option');
            opt.innerHTML = this.floors[i];
            opt.value = this.floors[i];
            floorList.appendChild(opt);
        }

        var space1 = createElementFromHTML('&nbsp;');
        infoDiv.appendChild(space1);

        var removeFloorButton = createElementFromHTML('<button onclick="lift.removeFloor('+  "'" + this.id +  "'" + ')">Remove floor</button>');
        infoDiv.appendChild(removeFloorButton);

        floorInput.focus();



    }

    //clean up function
    this.cleanUp = function(objects){
    
    }

};

lift.handleCreation = function(){
    //check if the mouse cursor is on top of a wall object
    if(mouseClicked){
        var newLift = new lift(mouseX, mouseY);
        objects.push(newLift);
        newLift.createInfo();
    }
    
}

lift.addNewFloor = function(liftID){
    var myFloor = document.getElementById("newFloorInput").value.trim();
    if(myFloor == "")
        return;
    
    for(var i = 0; i < objects.length; i++){
        if(objects[i] != null && objects[i].id == liftID){
            objects[i].floors.push(myFloor);
            break;
        }
    }
    var opt = document.createElement('option');
    opt.innerHTML = myFloor;
    opt.value = myFloor;
    document.getElementById("floorSelect").appendChild(opt);
}

lift.removeFloor = function(liftID){
    var floorList = document.getElementById("floorSelect");
    var selectedFloor = floorList.value;
    floorList.remove(floorList.selectedIndex);

    for(var i = 0; i < objects.length; i++){
        if(objects[i] != null && objects[i].id == liftID){
            
            for(var j = 0; j < objects[i].floors.length; j++){
                if(objects[i].floors[j] == selectedFloor){
                    objects[i].floors.splice(j, 1);
                    break;
                }
            }
            break;
        }
    }
}

lift.createJson = function(){
	var liftJson = "";
	for(var i = 0; i < objects.length; i++){
		if(objects[i] != null && objects[i].type == "lift"){
			liftJson+=('		{"id": "' + objects[i].id + '", ');
			liftJson+=('"x": ' + objects[i].x + ', ');
			liftJson+=('"y": ' + objects[i].y + ', ');
			liftJson+='"floors": ';
			liftJson+=('[');
			for(var j = 0; j< objects[i].floors.length; j++){
				liftJson+=('"' + objects[i].floors[j] + '", ');
			}
			if(liftJson.substring(liftJson.length-1, liftJson.length) != "[")
				liftJson = liftJson.substring(0, liftJson.length - 2);
			liftJson+=('], ');
			var nearbypaws = "[";
			for(var j = 0; j < objects.length; j++){
				if(objects[j] != null && objects[j].type == "path"){
					if(objects[j].startNode === objects[i])
						nearbypaws+=('"' + objects[j].endNode.id + '", ');
					else if(objects[j].endNode === objects[i])
						nearbypaws+=('"' + objects[j].startNode.id + '", ');
				}
			}
			if(nearbypaws.length > 2)
				nearbypaws = nearbypaws.substring(0, nearbypaws.length - 2);
			nearbypaws+="]";
			liftJson+=('"nearbypaws": ' + nearbypaws);
			liftJson+="},\n";
		}
	}

	if(liftJson.length > 2)
		liftJson = liftJson.substring(0, liftJson.length - 2) + "\n";
	return liftJson;
}
