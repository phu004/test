function wall(x1,y1,x2,y2){
    this.type = "wall";

    wall.indexNumber++;
    this.id = "wall_" + wall.indexNumber;

    this.isHighLighted = false;
    this.isSelected = false;

    this.doors = [];
    
    this.x1 = x1;
    this.y1 = y1;
    this.x2 = x2;
    this.y2 = y2;

    this.xMax = Math.max(x1, x2);
    this.yMax = Math.max(y1, y2);
    this.xMin = Math.min(x1, x2);
    this.yMin = Math.min(y1, y2);

    needToRecalculatePath = true;

    this.draw = function(){
        
        ctx.beginPath();
        ctx.strokeStyle="#0000FF";
        ctx.globalAlpha = 0.6;
        ctx.lineWidth = 5;
        ctx.moveTo(this.x1, this.y1);
        ctx.lineTo(this.x2, this.y2);
        ctx.stroke();

        if(this.isHighLighted || this.isSelected){
            ctx.globalAlpha = 0.15;
            ctx.lineWidth = 9;
            ctx.moveTo(this.x1, this.y1);
            ctx.lineTo(this.x2, this.y2);
            ctx.stroke();
            ctx.globalAlpha = 0.125;
            ctx.lineWidth = 13;
            ctx.moveTo(this.x1, this.y1);
            ctx.lineTo(this.x2, this.y2);
            ctx.stroke();
            ctx.globalAlpha = 0.1;
            ctx.lineWidth = 17;
            ctx.moveTo(this.x1, this.y1);
            ctx.lineTo(this.x2, this.y2);
            ctx.stroke();
           
        }
        
        this.isHighLighted = false;
    };

    //check if the current mouse cursor is on top of the wall object
    this.isSelectable = function(mouseX,mouseY){
       
        if(mouseX < this.xMin - 7 || mouseX > this.xMax + 7 || mouseY < this.yMin - 7 || mouseY > this.yMax + 7)
            return false;

        //fins the angle between the 2 lines from mouse point to both ends of the wall
        var v1x = mouseX - this.x1;
        var v1y = mouseY - this.y1;
        var v2x = mouseX - this.x2;
        var v2y = mouseY - this.y2;
        
        if(Math.abs(Math.abs(Math.atan2(v2y, v2x) - Math.atan2(v1y, v1x)) - 3.14) > 0.2){
            return false;
        }

        return true;
    };

    //clean up function
    this.cleanUp = function(objects){
        for(var i = 0; i < this.doors.length; i++){
            if(this.doors[i] != null){
                for(var j = 0; j < objects.length; j++){
                    if(objects[j] === this.doors[i])
                        objects[j] = null;
                }
                this.doors[i] = null;
            }
        }
    }

    this.createInfo = function(myWindow){}

}

wall.handleCreation = function(){
    //draw a line to represent where the wall will be placed
            
    if(secondClickX != ""){
        ctx.beginPath();
        ctx.lineWidth = 1;
        ctx.globalAlpha = 1;
        ctx.strokeStyle="#000000";
        ctx.moveTo(secondClickX,secondClickY);
        ctx.lineTo(mouseX,mouseY);
        ctx.stroke();
    }else if(firstClickX != ""){
        ctx.beginPath();
        ctx.lineWidth = 1;
        ctx.globalAlpha = 1;
        ctx.strokeStyle="#000000";
        ctx.moveTo(firstClickX,firstClickY);
        ctx.lineTo(mouseX,mouseY);
        ctx.stroke();
    }

    if(mouseClicked){
        if(firstClickX != "" && secondClickX != ""){
            objects.push(new wall(firstClickX, firstClickY, secondClickX, secondClickY));
        }
    }
}

wall.createJson = function(){
	var wallJson = "";
	for(var i = 0; i < objects.length; i++){
		if(objects[i] != null && objects[i].type == "wall"){
			wallJson+=('		{"id": "' + objects[i].id + '", ');
			wallJson+=('"x1": ' + objects[i].x1 + ', ');
			wallJson+=('"y1": ' + objects[i].y1 + ', ');
			wallJson+=('"x2": ' + objects[i].x2 + ', ');
			wallJson+=('"y2": ' + objects[i].y2);
			wallJson+="},\n";
		}
	}
	
	if(wallJson.length > 2)
		wallJson = wallJson.substring(0, wallJson.length - 2) + "\n";
	
	return wallJson;
}

//static variable for ID generation
wall.indexNumber = 0;