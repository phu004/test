//static variable for ID generation
stair.indexNumber = 0;

function stair(mouseX, mouseY){
    this.type = "stair";
  
    stair.indexNumber++;
    this.id = "stair_" + stair.indexNumber;

    this.upstairFloorName = "";
    this.downstairFloorName = "";

    this.isHighLighted = false;
    this.isSelected = false;

    this.x = mouseX;
    this.y = mouseY;

    this.isHighLighted = false;

    needToRecalculatePath = true;

    this.destinations = [];


    this.draw = function(){
       

        if(this.isHighLighted || this.isSelected){

            ctx.globalAlpha = 0.85;
            ctx.drawImage(stairImg, this.x - 25, this.y - 25);
          
            ctx.globalAlpha = 0.3;
            ctx.drawImage(stairImg, this.x - 26, this.y - 26, 52,52);
            ctx.globalAlpha = 0.3;
            ctx.drawImage(stairImg, this.x - 27, this.y - 27, 54,54);
            
        }else{
            ctx.globalAlpha = 0.65;
            ctx.drawImage(stairImg, this.x - 25, this.y - 25);
        }

        var myColor = 'green';
        if(this.upstairFloorName == "")
            myColor = 'red';
        ctx.beginPath();
        ctx.globalAlpha = 0.6;
        ctx.arc(this.x + 16, this.y - 27, 4, 0, 2 * Math.PI, true);
        ctx.fillStyle = myColor;
        ctx.fill();
        
        myColor = 'green';
        if(this.downstairFloorName == "")
            myColor = 'red';
        ctx.beginPath();
        ctx.globalAlpha = 0.6;
        ctx.arc(this.x - 27, this.y + 16, 4, 0, 2 * Math.PI, true);
        ctx.fillStyle = myColor;
        ctx.fill();

        this.isHighLighted = false;
    };

    //check if the current mouse cursor is on top of the stair object
    this.isSelectable = function(mouseX,mouseY){
       
        var distance = Math.sqrt((mouseX - this.x) * (mouseX - this.x) + (mouseY - this.y) * (mouseY - this.y));

        if(distance > 25)
            return false;
        
            return true;
    };

    this.createInfo = function(){
        var infoDiv = document.getElementById("object_info");
        while (infoDiv.firstChild) {
            infoDiv.removeChild(infoDiv.firstChild);
        }
        infoDiv.appendChild(createElementFromHTML('<p>Upstair floor name:</p><br>'));
        var upstair = createElementFromHTML('<input id="upstairInput" onkeyup="stair.saveUpstairFloorName(this, '+ "'" + this.id +  "'" + ')" style="width: 100px" value="' + this.upstairFloorName +'"></input><br><br>');
        infoDiv.appendChild(upstair);
        upstair.focus();

        infoDiv.appendChild(createElementFromHTML('<p>Downstair floor name:</p><br>'));
        var downstair = createElementFromHTML('<input id="downstairInput" onkeyup="stair.saveDownstairFloorName(this, '+ "'" + this.id +  "'" + ')" style="width: 100px" value="' + this.downstairFloorName +'"></input><br>');
        infoDiv.appendChild(downstair);

    }

    //clean up function
    this.cleanUp = function(objects){
    
    }

    
};

stair.handleCreation = function(){
    //check if the mouse cursor is on top of a wall object
    if(mouseClicked){
        var newStair = new stair(mouseX, mouseY);
        objects.push(newStair);
        newStair.createInfo();

    }
    
}

stair.saveUpstairFloorName = function(myInput, stairID){
    for(var i = 0; i < objects.length; i++){
        if(objects[i] != null && objects[i].id == stairID){
            objects[i].upstairFloorName = myInput.value;
            break;
        }
    }
}

stair.saveDownstairFloorName = function(myInput, stairID){
    for(var i = 0; i < objects.length; i++){
        if(objects[i] != null && objects[i].id == stairID){
            objects[i].downstairFloorName = myInput.value;
            break;
        }
    }
}

stair.createJson = function(){
	var stairJson = "";
	for(var i = 0; i < objects.length; i++){
		if(objects[i] != null && objects[i].type == "stair"){
			stairJson+=('		{"id": "' + objects[i].id + '", ');
			stairJson+=('"x": ' + objects[i].x + ', ');
			stairJson+=('"y": ' + objects[i].y + ', ');
			stairJson+=('"upstairFloorName": "' + objects[i].upstairFloorName + '", ');
			stairJson+=('"downstairFloorName": "' + objects[i].downstairFloorName + '", ');
			var nearbypaws = "[";
			for(var j = 0; j < objects.length; j++){
				if(objects[j] != null && objects[j].type == "path"){
					if(objects[j].startNode === objects[i])
						nearbypaws+=('"' + objects[j].endNode.id + '", ');
					else if(objects[j].endNode === objects[i])
						nearbypaws+=('"' + objects[j].startNode.id + '", ');
				}
			}
			if(nearbypaws.length > 2)
				nearbypaws = nearbypaws.substring(0, nearbypaws.length - 2);
			nearbypaws+="]";
			stairJson+=('"nearbypaws": ' + nearbypaws);
			stairJson+="},\n";
		}
	}
	
	if(stairJson.length > 2)
		stairJson = stairJson.substring(0, stairJson.length - 2) + "\n";
	
	return stairJson;
}