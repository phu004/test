function door(myWall, mouseX, mouseY){
    this.type = "door";

    this.roomNumber = "";
    door.indexNumber++;
    this.id = "door_" + door.indexNumber;

    this.isHighLighted = false;
    this.isSelected = false;
    
    var doorLength = 25;
    
    var x1 = myWall.x1; 
    var y1 = myWall.y1;
    var x2 = myWall.x2;
    var y2 = myWall.y2;

    var length1 = Math.sqrt((mouseX - x1) * (mouseX - x1) + (mouseY - y1) * (mouseY - y1));
    var length2 = Math.sqrt((mouseX - x2) * (mouseX - x2) + (mouseY - y2) * (mouseY - y2));
    var totalLength = length1 + length2;
    
    if(doorLength > totalLength/2){
        length1 = totalLength/2;
        length2 = totalLength/2;
        doorLength = totalLength/2;
    }else if(doorLength > length1){
        length1 = doorLength;
        length2 = totalLength - length1;
    }else if(doorLength > length2){
        length2 = doorLength;
        length1 = totalLength - length2;
    }

    this.d1x = x2 + (x1 - x2)*(length2+doorLength)/totalLength;
    this.d1y = y2 + (y1 - y2)*(length2+doorLength)/totalLength;

    this.d2x = x2 + (x1 - x2)*(length2-doorLength)/totalLength;
    this.d2y = y2 + (y1 - y2)*(length2-doorLength)/totalLength;

    this.x = (this.d1x + this.d2x)/2;
    this.y = (this.d1y + this.d2y)/2;

    this.xMax = Math.max(this.d1x, this.d2x);
    this.yMax = Math.max(this.d1y, this.d2y);
    this.xMin = Math.min(this.d1x, this.d2x);
    this.yMin = Math.min(this.d1y, this.d2y);

    this.theWall = myWall;
    myWall.doors.push(this);

    this.connectedPath = null;
    this.connectoinDistance = 1000000;
    this.NodeX = "";
    this.NodeY = "";

    needToRecalculatePath = true;

    this.draw = function(){
        var myColor = "#FF0000";
        if(this.roomNumber != ""){
            myColor = "#FF00FF"
        }
		
		if(this.roomNumber != "" && this.connectedPath != null)
			myColor = "#AACC00"
		
		

        ctx.beginPath();
        ctx.strokeStyle=myColor;
        ctx.globalAlpha = 0.7;
        ctx.lineWidth = 9;
        ctx.moveTo(this.d1x, this.d1y);
        ctx.lineTo(this.d2x, this.d2y);
        ctx.stroke();

        if(this.isHighLighted || this.isSelected){
            ctx.globalAlpha = 0.15;
            ctx.lineWidth = 13;
            ctx.moveTo(this.d1x, this.d1y);
            ctx.lineTo(this.d2x, this.d2y);
            ctx.stroke();
            ctx.globalAlpha = 0.125;
            ctx.lineWidth = 17;
            ctx.moveTo(this.d1x, this.d1y);
            ctx.lineTo(this.d2x, this.d2y);
            ctx.stroke();
            ctx.globalAlpha = 0.1;
            ctx.lineWidth = 21;
            ctx.moveTo(this.d1x, this.d1y);
            ctx.lineTo(this.d2x, this.d2y);
            ctx.stroke();
           
        }
        
        this.isHighLighted = false;
    };

    //check if the current mouse cursor is on top of the door object
    this.isSelectable = function(mouseX,mouseY){
       
        if(mouseX < this.xMin - 10 || mouseX > this.xMax + 10 || mouseY < this.yMin - 10 || mouseY > this.yMax + 10)
            return false;

        //find the angle between the 2 lines from mouse point to both ends of the door
        var v1x = mouseX - this.x1;
        var v1y = mouseY - this.y1;
        var v2x = mouseX - this.x2;
        var v2y = mouseY - this.y2;
        
        if(Math.abs(Math.abs(Math.atan2(v2y, v2x) - Math.atan2(v1y, v1x)) - 3.14) > 0.3){
            return false;
        }

        return true;
    };

    //clean up function
    this.cleanUp = function(objects){
        for(var i = 0; i < this.theWall.doors.length; i++){
            if(this === this.theWall.doors[i])
                this.theWall.doors[i] = null;
        }
    }

    this.createInfo = function(){
        var infoDiv = document.getElementById("object_info");
        while (infoDiv.firstChild) {
            infoDiv.removeChild(infoDiv.firstChild);
        }
        infoDiv.appendChild(createElementFromHTML('<p>Room number:</p><br>'));
        var myInput = createElementFromHTML('<input id="doorNumberInput" onkeyup="door.saveRoomNumber(this, '+ "'" + this.id +  "'" + ')" style="width: 100px" value="' + this.roomNumber +'"></input>');
        infoDiv.appendChild(myInput);
        myInput.focus();
    }

    
};

//set room number
door.saveRoomNumber = function(myInput, doorID){
    for(var i = 0; i < objects.length; i++){
        if(objects[i].id == doorID){
            objects[i].roomNumber = myInput.value;
            break;
        }
    }
}

door.handleCreation = function(){
     //check if the mouse cursor is on top of a wall object
     for(var i = 0; i < objects.length; i++){
        if(objects[i] != null && objects[i].type == "wall" && objects[i].isSelectable(mouseX, mouseY)){
			
			door.drawDoorPlacer(objects[i]);
			if(mouseClicked){
                var newDoor = new door(objects[i], mouseX, mouseY);
                objects.unshift(newDoor);
                newDoor.createInfo();
            }
			break;
        }
    }
}

//draw door placer indicator
door.drawDoorPlacer = function(myWall){
	
    var doorLength = 25;
    
    var x1 = myWall.x1;
    var y1 = myWall.y1;
    var x2 = myWall.x2;
    var y2 = myWall.y2;

    var length1 = Math.sqrt((mouseX - x1) * (mouseX - x1) + (mouseY - y1) * (mouseY - y1));
    var length2 = Math.sqrt((mouseX - x2) * (mouseX - x2) + (mouseY - y2) * (mouseY - y2));
    var totalLength = length1 + length2;
    
    if(doorLength > totalLength/2){
        length1 = totalLength/2;
        length2 = totalLength/2;
        doorLength = totalLength/2;
    }else if(doorLength > length1){
        length1 = doorLength;
        length2 = totalLength - length1;
    }else if(doorLength > length2){
        length2 = doorLength;
        length1 = totalLength - length2;
    }

    var d1x = x2 + (x1 - x2)*(length2+doorLength)/totalLength;
    var d1y = y2 + (y1 - y2)*(length2+doorLength)/totalLength;

    var d2x = x2 + (x1 - x2)*(length2-doorLength)/totalLength;
    var d2y = y2 + (y1 - y2)*(length2-doorLength)/totalLength;

    ctx.beginPath();
    ctx.strokeStyle="#FF0000";
    ctx.globalAlpha = 0.5;
    ctx.lineWidth = 9;
    ctx.moveTo(d1x, d1y);
    ctx.lineTo(d2x, d2y);
    ctx.stroke();
};

door.createJson = function(){
	var doorJson = "";
	for(var i = 0; i < objects.length; i++){
		if(objects[i] != null && objects[i].type == "door"){
			
			doorJson+=('		{"id": "' + objects[i].id + '", ');
			doorJson+=('"x": ' + objects[i].x + ', ');
			doorJson+=('"y": ' + objects[i].y + ', ');
			//find closest portal
			var nearestPortal = "";
			if(objects[i].connectedPath != null){
				var d1 =  Math.pow((objects[i].connectedPath.startNode.x - objects[i].x), 2) + Math.pow((objects[i].connectedPath.startNode.y - objects[i].y), 2);
				var d2 =  Math.pow((objects[i].connectedPath.endNode.x - objects[i].x), 2) + Math.pow((objects[i].connectedPath.endNode.y - objects[i].y), 2);
			
				if(d1 < d2)
					nearestPortal = objects[i].connectedPath.startNode.id;
				else
					nearestPortal = objects[i].connectedPath.endNode.id;
			}
			doorJson+=('"nearestPortal": "' + nearestPortal + '", ');
			doorJson+=('"myWall": "' + objects[i].theWall.id + '", ');
			doorJson+=('"doorNumber": "' + objects[i].roomNumber + '"');
			doorJson+="},\n";
		}
	}
	if(doorJson.length > 2)
		doorJson = doorJson.substring(0, doorJson.length - 2) + "\n";
	return doorJson;
}



//static variable for ID generation
door.indexNumber = 0;
