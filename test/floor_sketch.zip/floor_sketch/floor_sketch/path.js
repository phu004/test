//static variable for ID generation
path.indexNumber = 0;

function path(startNode, endNode){
    this.type = "path";

    path.indexNumber++;
    this.id = "path_" + path.indexNumber;

    this.startNode = startNode;
    this.endNode = endNode;

    //find the unit normal vector of this path
    var dx = startNode.x - endNode.x;
    var dy = startNode.y - endNode.y;
    var d = Math.sqrt(dx*dx + dy*dy);
    this.nx = dx/d;
    this.ny = dy/d;
    var temp =  this.nx;
    this.nx = - this.ny;
    this.ny = temp;

    this.doors = [];

    this.isSelectable = function(mouseX,mouseY){
        return false;
    }

    this.noWallsInBetween = function(objects, nodeX, nodeY, desNode){
        for(var i = 0; i < objects.length; i++){
            if(objects[i] != null && objects[i].type == "wall" && !(objects[i] === desNode.theWall)){
               
                var m1 = (objects[i].y2 - objects[i].y1)/(objects[i].x2 - objects[i].x1);
                if(objects[i].x2 - objects[i].x1 == 0)
                    m1 = 10000000;

                var m2 = (desNode.y - nodeY)/(desNode.x - nodeX);
                if(desNode.x - nodeX == 0)
                    m2 = 10000000;

                if(m1 == m2)
                    return true;

                var b1 = objects[i].y1 - m1*objects[i].x1;
                var b2 = nodeY - m2*nodeX;

                var intersectX = (b1 - b2)/(m2 - m1);
                var intersectY = b1 + m1*intersectX;
                 
                //check if the intersection is within boundary
                    
                var l1 = (objects[i].x2 - intersectX)*(objects[i].x1 - intersectX);
                var l2 = (objects[i].y2 - intersectY)*(objects[i].y1 - intersectY);
                var l3 = (nodeX - intersectX)*(desNode.x - intersectX);
                var l4 = (nodeY - intersectY)*(desNode.y - intersectY);
                var smallNumber = 0.000001;

                if(l1 <= smallNumber && l2 <= smallNumber && l3 <= smallNumber &&  l4 <= smallNumber){
                    return false;
                }
            }
        }

        return true;
    }

    for(var i = 0; i < objects.length; i++){
        if(objects[i] != null && objects[i].type == "door"){
            //find doors along the path. First calculate the shortest distance between the door and the path, then check if there is any obstacle in between;
            //t = - ((vx1−px)(vx2−vx1)+(vy1−py)(vy2−vy1)) / ((vx2−vx1)^2+(vy2−vy1)^2)
            //If 0 ≤ t ≤ 1 then the perpendicular line intersects the line segment and the minimum distance is:
            //|(vx2−vx1)(vy1−py)−(vy2−vy1)(vx1−px)| / sqrt((vx2−vx1)^2+(vy2−vy1)^2)
        
            var vx1 = startNode.x;
            var vy1 = startNode.y;
            var vx2 = endNode.x;
            var vy2 = endNode.y;
            var px = objects[i].x;
            var py = objects[i].y;
            var NodeX =  objects[i].NodeX;
            var NodeY =  objects[i].NodeY;

            var t = - ((vx1-px)*(vx2-vx1) + (vy1-py)*(vy2-vy1)) / ((vx2-vx1)*(vx2-vx1)+(vy2-vy1)*(vy2-vy1));

            if( 0 <= t && t <= 1){
                var distance = Math.abs((vx2-vx1)*(vy1-py)-(vy2-vy1)*(vx1-px)) / Math.sqrt((vx2-vx1)*(vx2-vx1)+(vy2-vy1)*(vy2-vy1));
                if(objects[i].connectedPath != null && objects[i].connectoinDistance < distance)
                    continue;

               
                var somevalue = (objects[i].x - startNode.x) * this.nx + (objects[i].y - startNode.y) * this.ny;
                if(somevalue > 0){
                    objects[i].NodeX = objects[i].x - this.nx*distance;
                    objects[i].NodeY = objects[i].y - this.ny*distance;
                }else{
                    objects[i].NodeX = objects[i].x + this.nx*distance;
                    objects[i].NodeY = objects[i].y + this.ny*distance;
                }

                //check if connection is blocked by any walls
                if(this.noWallsInBetween(objects, objects[i].NodeX, objects[i].NodeY, objects[i])){
                    this.doors.push(objects[i]);
                    objects[i].connectedPath = this;
                    objects[i].connectoinDistance = distance;
                    continue;
                }
            }

            objects[i].NodeX = NodeX;
            objects[i].NodeY = NodeY;

            var distanceFromStart = Math.sqrt((objects[i].x - startNode.x)*(objects[i].x - startNode.x) + (objects[i].y - startNode.y)*(objects[i].y - startNode.y));
            var distanceFromEnd =  Math.sqrt((objects[i].x - endNode.x)*(objects[i].x - endNode.x) + (objects[i].y - endNode.y)*(objects[i].y - endNode.y));

            if(objects[i].connectedPath != null && (objects[i].connectoinDistance < distanceFromStart && objects[i].connectoinDistance < distanceFromEnd))
                continue;

            if(distanceFromStart < distanceFromEnd){
                objects[i].NodeX = startNode.x;
                objects[i].NodeY = startNode.y;

                if(!this.noWallsInBetween(objects, objects[i].NodeX, objects[i].NodeY, objects[i])){
                    objects[i].NodeX = NodeX;
                    objects[i].NodeY = NodeY;
                    continue;
                }

                this.doors.push(objects[i]);
                objects[i].connectedPath = this;
                objects[i].connectoinDistance = distanceFromStart;
            }else{
                objects[i].NodeX = endNode.x;
                objects[i].NodeY = endNode.y;

                if(!this.noWallsInBetween(objects, objects[i].NodeX, objects[i].NodeY, objects[i])){
                    objects[i].NodeX = NodeX;
                    objects[i].NodeY = NodeY;
                    continue;
                }

                this.doors.push(objects[i]);
                objects[i].connectedPath = this;
                objects[i].connectoinDistance = distanceFromEnd;
            }

        }
    }

    //clean up function
    this.cleanUp = function(objects){
        for(var i = 0; i < this.doors.length; i++){
            if(this.doors[i] != null){
                this.doors[i].connectedPath = null;
                this.doors[i].NodeX = "";
                this.doors[i].NodeY = "";
                this.doors[i].connectoinDistance = 1000000;
                this.doors[i] = null;
            }
        }
    }

    this.draw = function(){
        ctx.beginPath();
        ctx.strokeStyle="#00AA00";
        ctx.globalAlpha = 0.7;
        ctx.lineWidth = 2.5;
        ctx.moveTo(startNode.x, startNode.y);
        ctx.lineTo(endNode.x, endNode.y);
        ctx.stroke();

        for(var i = 0; i < this.doors.length; i++){
            if(this.doors[i] != null){
                ctx.beginPath();
                ctx.globalAlpha = 0.6;
                ctx.arc(this.doors[i].NodeX, this.doors[i].NodeY, 4, 0, 2 * Math.PI, true);
                ctx.fillStyle = "#00AA00";
                ctx.fill();

                ctx.beginPath();
                ctx.lineWidth = 1;
                ctx.globalAlpha = 0.7;
                ctx.strokeStyle="#66BB00";
                ctx.moveTo(this.doors[i].NodeX,this.doors[i].NodeY);
                ctx.lineTo(this.doors[i].x,this.doors[i].y);
                ctx.stroke();
            }
        }

    }

    
}