//static variable for ID generation
paw.indexNumber = 0;

function paw(mouseX, mouseY){
    this.type = "paw";
  
    paw.indexNumber++;
    this.id = "paw_" + paw.indexNumber;

    this.pawNumber = "";
   

    this.isHighLighted = false;
    this.isSelected = false;

    this.x = mouseX;
    this.y = mouseY;

    this.isHighLighted = false;

    this.destinations = [];

    needToRecalculatePath = true;

    this.draw = function(){
       
        if(this.isHighLighted || this.isSelected){

            ctx.globalAlpha = 0.85;
            ctx.drawImage(pawImg, this.x - 25, this.y - 25);
          
            ctx.globalAlpha = 0.3;
            ctx.drawImage(pawImg, this.x - 26, this.y - 26, 52,52);
            ctx.globalAlpha = 0.3;
            ctx.drawImage(pawImg, this.x - 27, this.y - 27, 54,54);
            
        }else{
            ctx.globalAlpha = 0.65;
            ctx.drawImage(pawImg, this.x - 25, this.y - 25);
        }
		
		ctx.font = "12px Comic Sans MS";
		ctx.fillStyle = "black";
		ctx.textAlign = "center";
		ctx.globalAlpha = 1;
		ctx.fillText(this.pawNumber, this.x, this.y - 25); 
 
        this.isHighLighted = false;
    };

    //check if the current mouse cursor is on top of the paw object
    this.isSelectable = function(mouseX,mouseY){
       
        var distance = Math.sqrt((mouseX - this.x) * (mouseX - this.x) + (mouseY - this.y) * (mouseY - this.y));

        if(distance > 25)
            return false;
        
            return true;
    };

	this.createInfo = function(){
        var infoDiv = document.getElementById("object_info");
        while (infoDiv.firstChild) {
            infoDiv.removeChild(infoDiv.firstChild);
        }
        infoDiv.appendChild(createElementFromHTML('<p>Paw number:</p><br>'));
        var myInput = createElementFromHTML('<input id="pawNumberInput" onkeyup="paw.savepawNumber(this, '+ "'" + this.id +  "'" + ')" style="width: 100px" value="' + this.pawNumber +'"></input>');
        infoDiv.appendChild(myInput);
        myInput.focus();
    }	
	

    //clean up function
    this.cleanUp = function(objects){
    
    }

    //construct path object with other paws/exits/stairs/lifts
    this.constructPath = function(objects){

        //sort the path nodes by the distance to the paw
        pathNodes.sort(this.sortPathNode());
        
        for(var i = 0; i < pathNodes.length; i++){
            if(pathNodes[i].id != this.id){
                if(this.hasNoPathFrom(pathNodes[i]) && this.hasNoSimilarPath(objects, pathNodes[i]) && this.noWallsInBetween(objects, pathNodes[i])){
                 
                    //create path object
                    objects.push(new path(this, pathNodes[i]));

                    pathNodes[i].destinations.push(this); 
                    this.destinations.push(pathNodes[i]);   
                }else{
                    this.destinations.push(pathNodes[i]);   
                }
                
               
            }
        }
    }

    this.sortPathNode = function(){
        var currentNode = this;
        return function(node1, node2){
            var d1 = (node1.x - currentNode.x)*(node1.x - currentNode.x) + (node1.y - currentNode.y)*(node1.y - currentNode.y);
            var d2 = (node2.x - currentNode.x)*(node2.x - currentNode.x) + (node2.y - currentNode.y)*(node2.y - currentNode.y);
            return d1 - d2;
        }
    };

    this.hasNoPathFrom = function(object){
        for(var i = 0; i < object.destinations.length; i++){
            if(object.destinations[i] != null && object.destinations[i].id == this.id){
                
                return false;
            }    
        }
        return true;
    };

    this.hasNoSimilarPath = function(objects, desNode){
        for(var i = 0; i < objects.length; i++){
            if(objects[i] != null && objects[i].type == "path"){
                var sharedNode = null;
                var node1 = null;
                var node2 = null;
                if(objects[i].startNode === this){
                    sharedNode = this;
                    node1 = objects[i].endNode;
                    node2 = desNode;
                }else if(objects[i].endNode === this){
                    sharedNode = this;
                    node1 = objects[i].startNode;
                    node2 = desNode;
                }else if(objects[i].startNode === desNode){
                    sharedNode = desNode;
                    node1 = objects[i].endNode;
                    node2 = this;
                }else if(objects[i].endNode === desNode){
                    sharedNode = desNode;
                    node1 = objects[i].startNode;
                    node2 = this;
                }
                
                
                if(sharedNode != null){
                    var v1x = sharedNode.x - node1.x;
                    var v1y = sharedNode.y - node1.y;
                    var v2x = sharedNode.x - node2.x;
                    var v2y = sharedNode.y - node2.y;
                    
                    var angle = Math.abs(Math.atan2(v2y, v2x) - Math.atan2(v1y, v1x));
                    if(angle > Math.PI)
                        angle =  Math.PI*2-angle;
                    
                    if(angle < 0.3)
                       return false;
                }

            }
        }

        return true;
    };
    
    this.noWallsInBetween = function(objects, desNode){
        for(var i = 0; i < objects.length; i++){
            if(objects[i] != null && objects[i].type == "wall"){

                var m1 = (objects[i].y2 - objects[i].y1)/(objects[i].x2 - objects[i].x1);
                if(objects[i].x2 - objects[i].x1 == 0)
                    m1 = 10000000;

                var m2 = (desNode.y - this.y)/(desNode.x - this.x);
                if(desNode.x - this.x == 0)
                    m2 = 10000000;

                if(m1 == m2)
                    return true;

                var b1 = objects[i].y1 - m1*objects[i].x1;
                var b2 = this.y - m2*this.x;

                var intersectX = (b1 - b2)/(m2 - m1);
                var intersectY = b1 + m1*intersectX;
                 
                //check if the intersection is within boundary
                    
                var l1 = (objects[i].x2 - intersectX)*(objects[i].x1 - intersectX);
                var l2 = (objects[i].y2 - intersectY)*(objects[i].y1 - intersectY);
                var l3 = (this.x - intersectX)*(desNode.x - intersectX);
                var l4 = (this.y - intersectY)*(desNode.y - intersectY);
                var smallNumber = 0.000001;

                if(l1 <= smallNumber && l2 <= smallNumber && l3 <= smallNumber &&  l4 <= smallNumber){
                
                    //check for door intersection
                    var doorIntersection = false;
                    for(var j = 0; j < objects[i].doors.length; j++){
                        

                        if(objects[i].doors[j] != null){
                            
                            var doorX = objects[i].doors[j].x;
                            var doorY = objects[i].doors[j].y;
                            var doorLength = 25;
                           
                            if((doorX - intersectX)*(doorX - intersectX) + (doorY - intersectY)*(doorY - intersectY) < doorLength*doorLength){
                                doorIntersection = true;
                                break;
                            }
                        }
                    }
                
                    if(doorIntersection)
                        continue;

                    return false;
                }
            
            }
        }

        return true;
    }
    
};

//set paw number
paw.savepawNumber = function(myInput, pawID){
    for(var i = 0; i < objects.length; i++){
        if(objects[i].id == pawID){
            objects[i].pawNumber = myInput.value;
            break;
        }
    }
}

paw.handleCreation = function(){
    //check if the mouse cursor is on top of a wall object
    if(mouseClicked){
        var newpaw = new paw(mouseX, mouseY);
        objects.push(newpaw);
        newpaw.createInfo();
    }
}

paw.createJson = function(){
	var pawJson = "";
	for(var i = 0; i < objects.length; i++){
		if(objects[i] != null && objects[i].type == "paw"){
			pawJson+=('		{"id": "' + objects[i].id + '", ');
			pawJson+=('"x": ' + objects[i].x + ', ');
			pawJson+=('"y": ' + objects[i].y + ', ');
			pawJson+=('"pawNumber": "' + objects[i].pawNumber + '", ');
			
			var nearbyPortal = "[";
			for(var j = 0; j < objects.length; j++){
				if(objects[j] != null && objects[j].type == "path"){
					if(objects[j].startNode === objects[i])
						nearbyPortal+=('"' + objects[j].endNode.id + '", ');
					else if(objects[j].endNode === objects[i])
						nearbyPortal+=('"' + objects[j].startNode.id + '", ');
				}
			}
			if(nearbyPortal.length > 2)
				nearbyPortal = nearbyPortal.substring(0, nearbyPortal.length - 2);
			nearbyPortal+="]";
			pawJson+=('"nearbyPortal": ' + nearbyPortal);
			pawJson+="},\n";
		}
	}
	
	if(pawJson.length > 2)
		pawJson = pawJson.substring(0, pawJson.length - 2) + "\n";
	
	return pawJson;
}



