import java.awt.*;

public interface Actor{
	public void draw(Graphics g);
	public int getxPos();
	public int getyPos();
}