
public class WiperFilter {
	
	//width of the wiper in pixels
	public static int w = 32;
	
	//WiperfFilter wipes out image 1  and reveals image 2 as it moves from left to right
	public static void filterPixels(int position, int[] img1, int[] img2, int[] dest){
		if(position > 672)
			position = 672;
		
		int positionLeft = position - w;
		int positionRight = position + w;
		
		int index, color1, color2,r,g,b;
		for(int i = 0; i < 480; i++){
			for(int j = positionRight; j < 640; j++){
				index = j + 640*i;
				dest[index] = img1[index];
			}
			
			for(int j = 0; j < positionLeft; j++){
				index = j + 640*i;
				dest[index] = img2[index];
			}
			
			int deltaAlpha = 256/(2*w);
			for(int j = positionLeft, alpha = 0; j < positionRight; j++, alpha+=deltaAlpha){
				if(j < 0)
					continue;
				if(j >= 640)
					break;
				
				index = j + 640*i;
				color1 = img1[index];
				color2 = img2[index];
				r=(alpha*(((color1>>16)&255)-((color2>>16)&255))>>8)+((color2>>16)&255);
				g=(alpha*(((color1>>8)&255)-((color2>>8)&255))>>8)+((color2>>8)&255);
				b=(alpha*((color1&255)-(color2&255))>>8)+(color2&255);
				dest[index] = (r<<16)|(g<<8)|b;
			}
		}
		
	}
}
