
public class WaterFilter {
	public static short[] heightMap1 = new short[307200];
	public static short[] heightMap2 = new short[307200];
	public static int frameIndex;
	
	//Water filter will produce and animate water ripple effect on the image
	public static void filterPixels(int[] dest, int[] source, int index){
		frameIndex = index;
		if(frameIndex == 0)
			initHeightMap();
		
		createRipple();
		distortImage(dest, source);
		animateRipple();
		swapBuffer();
	}
	
	//swap height map buffers
	public static void swapBuffer(){
		short[] temp = heightMap1;
		heightMap1 = heightMap2;
		heightMap2 = temp;
	}
	
	//reset water state buffers 
	public static void initHeightMap(){
		for(int i = 0; i < 307200; i ++){
			heightMap1[i] = 0;
			heightMap2[i] = 0;
		}
	}
	
	//distort the image based on the ripple height map
	public static void distortImage(int[] dest, int[] source){
		int  Xoffset, Yoffset;
		short data;
		int i;
		for(i = 0; i < 640; i++)
			 dest[i]=source[i];
		for (int y=1;y<480 -1;y++) {
		        for (int x=0;x<640;x++) {
		        	data = (short)(1024-heightMap1[i]);
		        	Xoffset=(((x-320)*data)>>10)+320;
		        	Yoffset=(((y-240)*data)>>10)+240;
		        	
		        	//bounds check
			       
			          if (Xoffset>=640) Xoffset=640-1;
			          if (Xoffset<0) Xoffset=0;
			          if (Yoffset>=480) Yoffset=480-1;
			          if (Yoffset<0) Yoffset=0;
			  
			          
			          dest[i]=source[Xoffset+(Yoffset*640)];

			          i++;
		        }
		}
		for(i = 307200 - 640; i < 307200; i++)
			 dest[i]=source[i];
	}
	
	//create 2 ripples at different locations every frame
	public static void createRipple(){
		if(frameIndex ==0){disturb(479,402);}
		if(frameIndex ==0){disturb(348,224);}
		if(frameIndex ==2){disturb(209,250);}
		if(frameIndex ==2){disturb(542,126);}
		if(frameIndex ==4){disturb(383,368);}
		if(frameIndex ==4){disturb(419,125);}
		if(frameIndex ==6){disturb(257,400);}
		if(frameIndex ==6){disturb(330,169);}
		if(frameIndex ==8){disturb(234,347);}
		if(frameIndex ==8){disturb(512,133);}
		if(frameIndex ==10){disturb(552,94);}
		if(frameIndex ==10){disturb(96,303);}
		if(frameIndex ==12){disturb(361,151);}
		if(frameIndex ==12){disturb(529,68);}
		if(frameIndex ==14){disturb(275,255);}
		if(frameIndex ==14){disturb(164,79);}
		if(frameIndex ==16){disturb(512,233);}
		if(frameIndex ==16){disturb(318,104);}
		if(frameIndex ==18){disturb(294,368);}
		if(frameIndex ==18){disturb(259,246);}
		if(frameIndex ==20){disturb(446,404);}
		if(frameIndex ==20){disturb(378,148);}
		if(frameIndex ==22){disturb(60,241);}
		if(frameIndex ==22){disturb(344,334);}
		if(frameIndex ==24){disturb(76,300);}
		if(frameIndex ==24){disturb(442,188);}
		if(frameIndex ==26){disturb(536,124);}
		if(frameIndex ==26){disturb(156,293);}
		if(frameIndex ==28){disturb(497,203);}
		if(frameIndex ==28){disturb(249,201);}
		if(frameIndex ==30){disturb(257,51);}
		if(frameIndex ==30){disturb(186,394);}
		if(frameIndex ==32){disturb(501,146);}
		if(frameIndex ==32){disturb(544,196);}
		if(frameIndex ==34){disturb(378,72);}
		if(frameIndex ==34){disturb(136,366);}
		if(frameIndex ==36){disturb(243,294);}
		if(frameIndex ==36){disturb(406,283);}
		if(frameIndex ==38){disturb(242,231);}
		if(frameIndex ==38){disturb(524,314);}
		if(frameIndex ==40){disturb(256,171);}
		if(frameIndex ==40){disturb(340,300);}
		if(frameIndex ==42){disturb(121,275);}
		if(frameIndex ==42){disturb(320,100);}
		if(frameIndex ==46){disturb(325,286);}
		if(frameIndex ==46){disturb(320,296);}
		if(frameIndex ==46){disturb(335,362);}
		if(frameIndex ==46){disturb(320,240);}
		
	}
	
	
	//animate ripples
	public static void animateRipple(){
		int dampFactor = 6;
		if(frameIndex > 120)
			dampFactor = 5;
		if(frameIndex > 140)
			dampFactor = 4;
		if(frameIndex > 160)
			dampFactor = 3;
		if(frameIndex > 180)
			dampFactor = 2;
	
		
		for(int i = 640; i < 307200 - 640; i ++){
			int data = (((heightMap1[i-1]+
				    heightMap1[i+1]+
				    heightMap1[i-640]+
				    heightMap1[i+640])>>1));
			data -=heightMap2[i];
			data-=data>>dampFactor;
			heightMap2[i]=(short)data;
		}
	}
	
	//create a  ripple at given location
	public  static void disturb(int x, int y) {
		int disturbStr;
		if(frameIndex < 30)
			disturbStr = 512;
		else
			disturbStr = 512;
		for (int j=y-3;j<y+3;j++) {
	        for (int k=x-3;k<x+3;k++) {
	          if (j>=0 && j<480 && k>=0 && k<640) {
	        	  heightMap1[(j*640)+k] += disturbStr;            
	          } 
	        }
	      }
	    }


}


