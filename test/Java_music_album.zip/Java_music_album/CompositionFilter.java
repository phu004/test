
public class CompositionFilter {
	
	//Composition filter blend one image with another. The opacity of img2 is based on alpha value.
	public static void filterPixels(int alpha, int[] img2, int[] img1, int[] dest){
		int r,g,b, color1, color2;
		
		for(int i = 0; i < 307200; i++){
			color1 = img1[i];
			color2 = img2[i];
			r=(alpha*(((color1>>16)&255)-((color2>>16)&255))>>8)+((color2>>16)&255);
			g=(alpha*(((color1>>8)&255)-((color2>>8)&255))>>8)+((color2>>8)&255);
			b=(alpha*((color1&255)-(color2&255))>>8)+(color2&255);
			dest[i] = (r<<16)|(g<<8)|b;
		}
		
	}
		
	

}
