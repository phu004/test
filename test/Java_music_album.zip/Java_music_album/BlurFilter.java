
public class BlurFilter {
	static int windowSizeInverse;

	//Blur filter set the value of each pixel to the average value of its neighboring pixels.
    //the filter kernel used here has a cross shape instead of square.
    public static void filterPixels(int radius, int[] img, int[] offsSreenBuffer){
    	windowSizeInverse = 65536/(radius * 2 + 1); 
    	
        //blur image in horizontal direction then vertical direction
        horizontalBlur(radius, img, offsSreenBuffer);
        verticalBlur(radius, offsSreenBuffer, main.screen);
         
        //repeat for another time for better quality
        horizontalBlur(radius, main.screen, offsSreenBuffer);
        verticalBlur(radius, offsSreenBuffer, main.screen);
         
    }
     
    public static void horizontalBlur(int radius, int[] source, int[] dest){
        int i,j,sourcePositoin, destPosition,rgb1, rgb2, tr, tg, tb, windowSize;
        for(i = 0; i < 480; i++){
            sourcePositoin = i * 640;
            destPosition = i + 480 * 639;
             
            tr = 0; tg = 0; tb = 0;
            for(j = 0; j <= radius; j++){
                rgb1 = source[sourcePositoin + j];
                tr+=((rgb1 & 0xff0000) >> 16);
                tg+=((rgb1 & 0x00ff00) >> 8);
                tb+=(rgb1 & 0xff);
            }
            windowSize = radius + 1;
            dest[destPosition] = ((tr/windowSize)<<16)|((tg/windowSize)<<8)|(tb/windowSize);
            sourcePositoin++;
            destPosition-=480;
            windowSize++;
            for(j = 1; j <= radius; j++, sourcePositoin++, destPosition-=480, windowSize++){
                rgb1 = source[sourcePositoin + radius];
                tr+=((rgb1 & 0xff0000) >> 16);
                tg+=((rgb1 & 0x00ff00) >> 8);
                tb+=(rgb1 & 0xff);
                dest[destPosition] = ((tr/windowSize)<<16)|((tg/windowSize)<<8)|(tb/windowSize);
            }
            windowSize--;
            for(j = radius + 1; j < 640 - radius; j++, sourcePositoin++, destPosition-=480){
                rgb1 = source[sourcePositoin + radius];
                rgb2 = source[sourcePositoin - radius - 1];
                tr+=(((rgb1 & 0xff0000) - (rgb2 & 0xff0000)) >> 16);
                tg+=(((rgb1 & 0x00ff00) - (rgb2 & 0x00ff00)) >> 8);
                tb+=((rgb1 & 0xff) - (rgb2 & 0xff));
                dest[destPosition] = ((tr*windowSizeInverse)&0xff0000)|(((tg*windowSizeInverse)>>8)&0xff00)|((tb*windowSizeInverse)>>16);
               
            }
            windowSize--;
            for(j = 640 - radius; j < 640; j++, sourcePositoin++, destPosition-=480, windowSize--){
                rgb2 = source[sourcePositoin - radius - 1];
                tr-=((rgb2 & 0xff0000) >> 16);
                tg-=((rgb2 & 0x00ff00) >> 8);
                tb-=(rgb2 & 0xff);
                dest[destPosition] = ((tr/windowSize)<<16)|((tg/windowSize)<<8)|(tb/windowSize);
            }
        }
    }
     
    public static void verticalBlur(int radius, int[] source, int[] dest){
        int i,j,sourcePositoin, destPosition,rgb1, rgb2, tr, tg, tb, windowSize;
        for(i = 0; i < 640; i++){
            sourcePositoin = i * 480;
            destPosition = 639 -i;
             
            tr = 0; tg = 0; tb = 0;
            for(j = 0; j <= radius; j++){
                rgb1 = source[sourcePositoin + j];
                tr+=((rgb1 & 0xff0000) >> 16);
                tg+=((rgb1 & 0x00ff00) >> 8);
                tb+=(rgb1 & 0xff);
            }
            windowSize = radius + 1;
            dest[destPosition] = ((tr/windowSize)<<16)|((tg/windowSize)<<8)|(tb/windowSize);
            sourcePositoin++;
            destPosition+=640;
            windowSize++;
            for(j = 1; j <= radius; j++, sourcePositoin++, destPosition+=640, windowSize++){
                rgb1 = source[sourcePositoin + radius];
                tr+=((rgb1 & 0xff0000) >> 16);
                tg+=((rgb1 & 0x00ff00) >> 8);
                tb+=(rgb1 & 0xff);
                dest[destPosition] = ((tr/windowSize)<<16)|((tg/windowSize)<<8)|(tb/windowSize);
            }
            windowSize--;
            for(j = radius + 1; j < 480 - radius; j++, sourcePositoin++, destPosition+=640){
                rgb1 = source[sourcePositoin + radius];
                rgb2 = source[sourcePositoin - radius - 1];
                tr+=(((rgb1 & 0xff0000) - (rgb2 & 0xff0000)) >> 16);
                tg+=(((rgb1 & 0x00ff00) - (rgb2 & 0x00ff00)) >> 8);
                tb+=((rgb1 & 0xff) - (rgb2 & 0xff));
                dest[destPosition] = ((tr*windowSizeInverse)&0xff0000)|(((tg*windowSizeInverse)>>8)&0xff00)|((tb*windowSizeInverse)>>16);
             
            }
            windowSize--;
            for(j = 480 - radius; j < 480; j++, sourcePositoin++, destPosition+=640, windowSize--){
                rgb2 = source[sourcePositoin - radius - 1];
                tr-=((rgb2 & 0xff0000) >> 16);
                tg-=((rgb2 & 0x00ff00) >> 8);
                tb-=(rgb2 & 0xff);
                dest[destPosition] = ((tr/windowSize)<<16)|((tg/windowSize)<<8)|(tb/windowSize);
            }
        }
    }
 
}

