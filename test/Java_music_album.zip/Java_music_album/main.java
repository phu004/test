import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.awt.image.*;
import java.awt.event.ActionEvent;

public class main extends Applet implements ActionListener, MouseMotionListener, MouseListener{
	
	public Ticker t;
	public int frameInterval = 40;
	public int frameIndex;
	public int lastDelay;
	public long timer;
	public long startTime;
	public static int[] screen, offScreenBuffer1, offScreenBuffer2, offScreenBuffer3, replayButtonPic;
	public BufferedImage doubleBuffer;
	
	public static Image[] imgs;
	public static AudioClip ac;
	public boolean audioPlaying;
	public boolean slidesFinished;
	public boolean waitingMouseAction;
	public int buttonHightlight;

	public int currentFilter;
	public int currentImage;
	public int filterPassCount;
	public int filterPassSpeed;
	public int compositionFilter = 1;
	public int blurAndCompositionFilter = 2;
	public int waterAndCompositionFilter = 3;
	public int wiperFilter = 4;
	public int dissolveFilter = 5;
	public int blurFilter = 6;
	
	
	//start applet window, init variables, load pictures & sound files
	public void init(){
		//load images
		imgs = new Image[17];
		for(int i = 0; i < imgs.length; i++)
			imgs[i] = getImage(getDocumentBase(), i + ".jpg");
		
		//load audio
		ac = getAudioClip(getCodeBase(), "cavatina.au");
		
		//create main screen buffer
		doubleBuffer =  new BufferedImage(640, 480, BufferedImage.TYPE_INT_RGB);
		DataBuffer dest = doubleBuffer.getRaster().getDataBuffer();
		screen = ((DataBufferInt)dest).getData();
		
		//load reply button picture
		replayButtonPic = new int[157*52];
		grabPixels(imgs[16], replayButtonPic, 157, 52);
		
		
		//create off screen buffers
		offScreenBuffer1 = new int[307200];
		offScreenBuffer2 = new int[307200];
		offScreenBuffer3 = new int[307200];
		
		frameIndex = 0;
		timer = System.currentTimeMillis();
		startTime = timer;
		currentImage = -1;
		
		addMouseMotionListener(this);
		addMouseListener(this);
		requestFocus();
		
		//Add ticker, which will invoke actionPerformed() every few milliseconds
		t = new Ticker(frameInterval);
		t.addActionListener(this);
		t.start();
		
		
		//start a daemon thread which will sleep for the duration of the applet.
		Thread   dt   =   new   Thread(new   DaemonThread());
        dt.setDaemon(true);
        dt.start(); 
	}
	

	//release resources when browser is closed
	public void destroy(){
		ac.stop();
		t.stop();
		System.gc();
		
	}
	
	//animation loop
	public void actionPerformed(ActionEvent e){
		//cap frame rate to around 25.
		frameIndex++;
		timer+=frameInterval;	
		//compare predicted timer with the actual timer, 
		long actualTime = System.currentTimeMillis();
		int delay = (int)(Math.max(0, timer - actualTime));
		//if actual timer is lagging behind, then reduce the delay between frames to half
		if(delay == 0)
			delay = (int)(lastDelay*0.5);
		if(delay > frameInterval)
			delay = frameInterval;
		t.setDelay(delay);
		lastDelay = delay;
		
		//calculate the time elapsed since the start of the applet in seconds
		int timeElapsed = (int)((actualTime - startTime)/1000);
		if(currentImage == -1)
			filterPassSpeed = 2;
		else
			filterPassSpeed = 1;
		
		//set which picture to display and when to display
		switch (timeElapsed){
		    case 0: changePicture(0, compositionFilter); break;
		    case 3: changePicture(-1, compositionFilter); break;
		    case 5: changePicture(1, compositionFilter); break;
		    case 8: changePicture(-1, compositionFilter); break;
		
			case 10: changePicture(2,dissolveFilter); 
				if(!audioPlaying){		
					ac.play(); 
					audioPlaying = true;} 
				break;
			case 20: changePicture(3,blurAndCompositionFilter); break;
			case 30: changePicture(5,waterAndCompositionFilter); break;
			case 45: changePicture(4,wiperFilter); break;
			case 55: changePicture(6,compositionFilter); break;
			case 65: changePicture(8,dissolveFilter); break;
			case 75: changePicture(9,blurAndCompositionFilter); break;
			case 85: changePicture(10,waterAndCompositionFilter); break;
			case 100: changePicture(11,wiperFilter); break;
			case 110: changePicture(12, compositionFilter); break;
			case 120: changePicture(13, dissolveFilter); break;
			case 130: changePicture(14, blurAndCompositionFilter); break;
			case 140: changePicture(15, waterAndCompositionFilter); break;
			case 155: changePicture(7, wiperFilter); break;
			case 165: currentFilter = blurFilter;
					  filterPassCount = 0;
					  audioPlaying = false; 
					  break;
			case 168: slidesFinished = true;  break;
			
			
		}
		
		//apply filters during picture transitions.
		if(filterPassCount == -1){
			filterPassCount = 0;
		}else{
			applyFilter();
		}
		
		//draw replay button in the end of the slides show
		if(slidesFinished && filterPassCount > 64){
			if(!waitingMouseAction){
				System.arraycopy(screen, 0, offScreenBuffer2, 0, 307200);
				waitingMouseAction = true;
			}
			int pos = 250 +  210 * 640;
			int r, g, b;
			for(int i = 0; i < 52; i++){
				for(int j = 0; j < 157; j++){
					int color = replayButtonPic[j + i*157];
					r = (color & 0xff0000) >> 16;
			
					if(r > 128 ){
						if(j > 10 && j < 147 && i > 10 && i < 42 ){
							screen[pos + j + i * 640] = color;
						}
					}else{
						color = offScreenBuffer2[pos + j + i * 640];
						r = ((color & 0x00ff0000) >> 17) + buttonHightlight;
						g = ((color & 0x0000ff00) >> 9) + buttonHightlight;
						b = ((color & 0x000000ff) >> 1) + buttonHightlight;
						color = b+ (g << 8) + (r << 16);
						screen[pos + j + i * 640] = color;
					}
				}
			}
			
		}
		
		//draw Applet content 
		if(this.getGraphics() != null){
			Graphics2D g2 = (Graphics2D)this.getGraphics();
			g2.drawImage(doubleBuffer, null, 0, 0);
	
		}
		
	}
	
	//load next image and set filter type
	public void changePicture(int nextImage, int filter){
		if(currentImage == nextImage)
			return;
		System.arraycopy(screen, 0, offScreenBuffer1, 0, 307200);
		if(nextImage != -1)
			grabPixels(imgs[nextImage], offScreenBuffer2, 640, 480);
		else{
			fillBlackPixels(offScreenBuffer2);
		}
			
		currentImage = nextImage;
		currentFilter = filter;
		filterPassCount = -1;
	}
	
	//fill an image with only black pixels
	public  void fillBlackPixels(int[] img){
		img[0] = 0;
		int l = img.length;
		for(int i = 1; i < 307200; i+=i){
			System.arraycopy(img, 0, img, i, l - i >= i ? i : l - i);
		}
	}


	
	
	//convert Image to raw pixels
	public void grabPixels(Image img, int[] destination, int w, int h){
		PixelGrabber pg1 = new PixelGrabber(img, 0, 0, w, h, destination, 0, w);
		try {
			pg1.grabPixels();
		}catch(Exception e){ System.out.println(e);}
	}
	
	//apply a filter to current image
	public void applyFilter(){
		if(currentFilter == compositionFilter){
			applyCompositionFilter();	
		}
		if(currentFilter == blurAndCompositionFilter){
			applyBlurAndCompositionFilter();
		}
		
		if(currentFilter == waterAndCompositionFilter){
			applyWaterAndCompositionFilter();
		}
		
		if(currentFilter == wiperFilter){
			applyWiperFilter();
		}
		
		if(currentFilter == dissolveFilter){
			applyDissolveFilter();
		}
		
		if(currentFilter == blurFilter){
			applyBlurFilter();
		}
		
	}
	
	//apply transition filter
	public void applyCompositionFilter(){
		if(filterPassCount <= 64){
			int alpha = filterPassCount * 4;
			if(alpha == 256)
				alpha = 255;
			CompositionFilter.filterPixels(alpha, offScreenBuffer1, offScreenBuffer2, screen);
			filterPassCount+=filterPassSpeed;
		}
	}
	
	//apply blur filter
	public void applyBlurAndCompositionFilter(){
		if(filterPassCount <= 64){
			int alpha = filterPassCount * 4;
			if(alpha == 256)
				alpha = 255;
			CompositionFilter.filterPixels(alpha, offScreenBuffer1, offScreenBuffer2, screen);
			if(filterPassCount < 32)
				BlurFilter.filterPixels(filterPassCount, screen, offScreenBuffer3);
			else if(filterPassCount < 64) 
				BlurFilter.filterPixels(63-filterPassCount, screen, offScreenBuffer3);
			filterPassCount+=filterPassSpeed;
		}
	}
	
	//apply water filter
	public void applyWaterAndCompositionFilter(){
		if(filterPassCount < 312){
			if(filterPassCount < 32)
				CompositionFilter.filterPixels((int)(0)%256, offScreenBuffer1, offScreenBuffer2, offScreenBuffer3);
			if(filterPassCount >= 32 && filterPassCount < 160)
				CompositionFilter.filterPixels((int)((filterPassCount-32) * 2)%256, offScreenBuffer1, offScreenBuffer2, offScreenBuffer3);
			if(filterPassCount >= 160)
				CompositionFilter.filterPixels((int)(255)%256, offScreenBuffer1, offScreenBuffer2, offScreenBuffer3);
			if(filterPassCount == 311)
				CompositionFilter.filterPixels((int)(255)%256, offScreenBuffer1, offScreenBuffer2, screen);
			if(filterPassCount < 311)
				WaterFilter.filterPixels(screen, offScreenBuffer3, filterPassCount);
			filterPassCount+=filterPassSpeed;
		}
	}
	
	//apply wiperFilter
	public void applyWiperFilter(){
		if(filterPassCount < 64){
			WiperFilter.filterPixels(-32 + filterPassCount*20, offScreenBuffer1, offScreenBuffer2, screen);
			filterPassCount+=filterPassSpeed;
		}
		
	}
	
	//apply dissolveFilter(
	public void applyDissolveFilter(){
		if(filterPassCount < 64){
			DissolveFilter.filterPixels(filterPassCount, offScreenBuffer1, offScreenBuffer2, screen);
			filterPassCount+=filterPassSpeed;
		}
		
	}
	
	//apply blur filter
	public void applyBlurFilter(){
		if(filterPassCount < 64)
			BlurFilter.filterPixels(filterPassCount/2, offScreenBuffer2, offScreenBuffer3);
		filterPassCount+=filterPassSpeed;
	}


	public void mouseMoved(MouseEvent e) {
		int x = e.getX();
		int y = e.getY();
		
		if(x > 250 && x < 400 && y > 210 && y < 260){
			buttonHightlight = 50;
		}else{
			buttonHightlight = 0;
		}
	}
	
	public void mouseClicked(MouseEvent arg0) {
		if(buttonHightlight == 50 && slidesFinished){
			slidesFinished = false;
			startTime = System.currentTimeMillis() - 10000;
		}
	}

	public void mouseEntered(MouseEvent arg0) {}
	
	public void mouseExited(MouseEvent arg0) {}
		
	public void mousePressed(MouseEvent arg0) {}

	public void mouseReleased(MouseEvent arg0) {}

	public void mouseDragged(MouseEvent arg0) {}



	
}
