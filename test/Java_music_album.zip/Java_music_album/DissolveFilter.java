
public class DissolveFilter {
	
	public static byte[] randomNum = new byte[307200];
	
	//DissolveFilter "dissolves" img 1 by drawing random pixels of img 2 on to it.
	public static void filterPixels(int counter, int[] img1, int[] img2, int[] dest){
		if(counter == 0){
			creatRandomNum();
			return;
		}
		
		for(int i = 0; i < 307200; i ++){
			if(randomNum[i] <= counter)
				dest[i] = img2[i];
			else
				dest[i] = img1[i];
		}
	}
	
	public static void creatRandomNum(){
		for(int i = 0; i < 307200; i ++){
			randomNum[i] = (byte)(Math.random()*48);
		}
	}
}
