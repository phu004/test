class Triangle_MSAA {
    constructor(vertex1, vertex2, vertex3) {
        this.vertex1 = vertex1;
        this.vertex2 = vertex2;
        this.vertex3 = vertex3;

        this.outlineAlpha = 0.7;
        this.lowResPixels = [];
        for(let i = 0; i < 20; i++){
            for(let j = 0; j < 32; j++){
                this.lowResPixels.push(new Pixel(j*canvas.width/32, i* canvas.height/20, canvas.width/32, canvas.height/20));
            }
        }
        this.StartingIndex = 0;

        this.processedPixels = [];
        for(let i = 0; i < 20; i++){
            for(let j = 0; j < 32; j++){
                let myPixel = new Pixel(j*canvas.width/32, i* canvas.height/20, canvas.width/32, canvas.height/20);
                let colors = [];
                for(let k = 0; k < 4; k++){
                    if(isPointInside(myPixel.centers[k].x, myPixel.centers[k].y, this))
                        colors.push('#FF8000');
                    else
                        colors.push("#A3D8EF");
                }
                myPixel.pixelColor = averageColors(colors);
                this.processedPixels.push(myPixel);

            }
        }
    }

    drawProcessedPixels(){
        if(this.StartingIndex < this.processedPixels.length){
            this.StartingIndex++;
        }
        for(let i = 0; i < this.StartingIndex; i++){
            var intersect = false;
            var inside = false;

            if(doesRectangleIntersect(this.processedPixels[i].xPos, this.processedPixels[i].yPos, this.processedPixels[i].width, this.processedPixels[i].height, this)){
                intersect = true;
            }

            if(isPointInside(this.processedPixels[i].centerX, this.processedPixels[i].centerY, this)){
                inside = true;
            }else if(i == this.StartingIndex -1 && this.StartingIndex < this.processedPixels.length){
                this.StartingIndex++;
            }

            if(intersect || inside)
                this.processedPixels[i].draw();
            
        }    
    }

    drawPixelCenter(){
        
        for(let i = 0; i < this.lowResPixels.length; i++){
            var intersect = false;
            var inside = false;

            if(doesRectangleIntersect(this.lowResPixels[i].xPos, this.lowResPixels[i].yPos, this.lowResPixels[i].width, this.lowResPixels[i].height, this))
                intersect = true;

            if(isPointInside(this.lowResPixels[i].centerX, this.lowResPixels[i].centerY, this))
                inside = true;

            if(intersect || inside){
                this.lowResPixels[i].alpha = 1;
                this.lowResPixels[i].drawCenters();
            }
        }
    }

    fadeCenters(){
        for(let i = 0; i < this.lowResPixels.length; i++){
            this.lowResPixels[i].fadeCenters();
        }
    }

    intensifyCenters(){
        for(let i = 0; i < this.lowResPixels.length; i++){
            this.lowResPixels[i].intensifyCenters();
        }
    }


}