import core.main;

public class battleTank {
	
	public static void main(String[] args){
		new main();
	}
	
}