package core;
//3D model: floor_hallway
public class floor_hallway extends solidObject{
	
	public floor_hallway(vector centre){
		//centre point of the model (in world coordinate)
		start = centre.myClone();
		this.centre = start.myClone();
		tempCentre = start.myClone();
		
		
		//define reference axis (in world coordinate)
		iDirection = new vector(1,0,0);
		jDirection = new vector(0,1,0);
		kDirection = new vector(0,0,1);
		
		//create a rough 3D cuboid boundary for this model.
		makeBoundary(0.4f, 0.009f, 0.6f);
		
		//create polygons
		makePolygons();
		
		
		
	}
	
	//all the polygon vertices  are hard coded here
	public void makePolygons(){
		polygons = new polygon3D[3];
		vector[] t;
		
		t = new vector[]{put(-0.4, 0.01, 0.33), put(0.4, 0.01, 0.33), put(0.4, 0.01, -0.6), put(-0.4, 0.01, -0.6)};
		polygons[0] = new polygon3D(t, put(-0.4, 0.01, 0.6), put(0.4, 0.01, 0.6),put(-0.4, 0.01, -0.6), main.textures[6], 6,9, 5); 
		polygons[0].diffuse_I = 20;
		
		
		t = new vector[]{put(-0.4, 0.01, 0.6), put(-0.2, 0.01, 0.6), put(-0.2, 0.01, 0.328), put(-0.4, 0.01, 0.328)};
		polygons[1] = new polygon3D(t, put(-0.4, 0.01, 0.6), put(0.4, 0.01, 0.6),put(-0.4, 0.01, -0.6), main.textures[6], 6,9, 5); 
		polygons[1].diffuse_I = 20;
		
		
		t = new vector[]{put(0.4, 0.01, 0.328),put(0.2, 0.01, 0.328), put(0.2, 0.01, 0.6), put(0.4, 0.01, 0.6)};
		polygons[2] = new polygon3D(t, put(-0.4, 0.01, 0.6), put(0.4, 0.01, 0.6),put(-0.4, 0.01, -0.6), main.textures[6], 6,9, 5); 
		polygons[2].diffuse_I = 20;
		
	}
	
	public void drawReflection(){};
}
