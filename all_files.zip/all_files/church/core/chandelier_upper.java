package core;
//d model: chandelier
public class chandelier_upper extends solidObject{
	
	public chandelier_upper(vector centre){
		//centre point of the model (in world coordinate)
		start = centre.myClone();
		this.centre = start.myClone();
		tempCentre = start.myClone();
		
		//define reference axis (in world coordinate)
		iDirection = new vector(1,0,0);
		jDirection = new vector(0,1,0);
		kDirection = new vector(0,0,1);
		
		//create a rough 3D cuboid boundary for this model.
		makeBoundary(0.15f, 0.08f, 0.15f);
		
		
		
		makePolygons();
		
	}
	
	//all the polygon vertices  are hard coded here
	public void makePolygons(){
		polygons = new polygon3D[12];
		vector[] t;
		
		start.add(0,-0.102f, 0 );
	
		int index =0;
		
		t = new vector[]{put(-0.0005, 0.19, -0.0005), put(0.0005, 0.19, -0.0005), put(0.0005, 0.02, -0.0005), put(-0.0005, 0.02, -0.0005)};
		polygons[index] = new polygon3D(t, t[3], t[0], t[2], main.textures[25], 1,1, 3); 
		polygons[index].diffuse_I = 0;
		index++;
		
		t = new vector[]{put(-0.0005, 0.02, 0.0005), put(0.0005, 0.02, 0.0005), put(0.0005, 0.19, 0.0005), put(-0.0005, 0.19, 0.0005)};
		polygons[index] = new polygon3D(t, t[3], t[0], t[2], main.textures[25], 1,1, 3); 
		polygons[index].diffuse_I = 0;
		index++;
		
		t = new vector[]{put(0.0005, 0.19, -0.0005), put(0.0005, 0.19, 0.0005), put(0.0005, 0.02, 0.0005), put(0.0005, 0.02, -0.0005)};
		polygons[index] = new polygon3D(t, t[3], t[0], t[2], main.textures[25], 1,1, 3); 
		polygons[index].diffuse_I = 0;
		index++;
		
		t = new vector[]{put(-0.0005, 0.02, -0.0005), put(-0.0005, 0.02, 0.0005), put(-0.0005, 0.19, 0.0005), put(-0.0005, 0.19, -0.0005)};
		polygons[index] = new polygon3D(t, t[3], t[0], t[2], main.textures[25], 1,1, 3); 
		polygons[index].diffuse_I = 0;
		index++;
		
		double r1 = 0.01;
		double r2 = 0.02;
		double theta = Math.PI/3;
		
		t = new vector[6];
		
		for(int i = 1; i < 7; i++)
			t[6-i] = put(r1*Math.cos(i*theta), 0.0199, r1*Math.sin(i*theta));
		polygons[index] = new polygon3D(t, t[0], t[1], t[4], main.textures[25], 1,1, 3); 
		index++;
		
		for(int i = 0; i < 6; i ++){
			t = new vector[]{put(r1*Math.cos(i*theta), 0.0199, r1*Math.sin(i*theta)),
							 put(r1*Math.cos((i+1)*theta), 0.0199, r1*Math.sin((i+1)*theta)),
							 put(r1*Math.cos((i+1)*theta), 0.014, r1*Math.sin((i+1)*theta)),
							 put(r1*Math.cos(i*theta), 0.014, r1*Math.sin(i*theta))
							};
			polygons[index] = new polygon3D(t, t[0], t[1], t[3], main.textures[25], 1,1, 3); 
			
			index++;
		}
		
		t = new vector[6];
		for(int i = 1; i < 7; i++)
			t[6-i] = put(r2*Math.cos(i*theta), 0.01399, r2*Math.sin(i*theta));
		polygons[index] = new polygon3D(t, t[0], t[1], t[4], main.textures[25], 1,1, 3); 
		index++;
		
		sortedPolygons = false;
	}

	public void drawReflection(){}
}
