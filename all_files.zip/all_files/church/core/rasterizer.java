package core;
//The rasterizer class will draw any polygon into the screen buffer.
//The texture mapping methods will differ depends on the type of polygon,
//The universal formula for texture mapping is:
//               x = A dot W/C dot W
//               y = B dot W/C dot W
// where    A = V cross O  B = O cross U  C = U cross V,   
//          V, a vector representing the texture's y direction
//          U, a vector representing the texture's x direction
//          O, the origin of the texture 
//          W is the projection length of the texel on the clipping plane
//          x, y is the texture coordinate 
//
//                     Won't handle z-axis rotation.
//                     Doesn't save/compare z values as i am only using painter's method for sorting polygons. 




public class rasterizer {
	public static int screen_w = main.screen_w;
	public static int screen_h = main.screen_h;
	public static int half_screen_w = main.half_screen_w;
	public static int half_screen_h = main.half_screen_h;
	public static int screen_pixel_count = main.screen_pixel_count;
	
	//The 2 arrays will hold the scan lines of the polygon
	public static int[] xLow = new int[screen_h], xHigh = new int[screen_h];
	
	//init Texture coordinate vectors
	public static vector 
	W = new vector(0,0,0),
	O = new vector(0,0,0), 
	V = new vector(0,0,0), 
	U = new vector(0,0,0), 
	A = new vector(0,0,0), 
	B = new vector(0,0,0), 
	C = new vector(0,0,0);
	
	
	//A pool of vectors which will be used for vector arithmetic
	public static vector 
		tempVector1 = new vector(0,0,0),
		tempVector2 = new vector(0,0,0),
		tempVector3 = new vector(0,0,0),
		tempVector4 = new vector(0,0,0);
	
	//the polygon that rasterizer is working on
	public static polygon3D poly;
	
	//these variables will represent their equivalents in the polygon3D class during rasterization
	public static vector[] tempVertex, vertex2D;
	public static int L, widthMask, heightMask, widthBits, diffuse_I;
	public static double A_offset, B_offset, C_offset;
	
	//the transparency level of the polygon. 
	public static int alpha;
	
	//the amount of vertex after clipping
	public static int visibleCount;
	
	//temporary variables that will be used in texture mapping
	public static double aDotW, bDotW, cDotW, cDotWInverse;
	public static int BigX, BigY, d_x, d_y, k, X1, Y1, BigDx, BigDy, dx, dy, X, Y, textureIndex, temp, temp1, temp2, r,g,b, scale, yOffset, xOffset, textureHeight;
	public static short I, variation;
	
	
	
	//start rasterization
	public static void rasterize(polygon3D polygon){
		poly = polygon;
		L = poly.L;
		widthMask = poly.widthMask;
		heightMask = poly.heightMask;
		textureHeight = poly.textureHeight;
		widthBits = poly.widthBits;
		tempVertex = poly.tempVertex;
		vertex2D = poly.vertex2D;
		alpha = poly.alpha;
		
		//find the vectors which represent the texture coordinate
		if(poly.type != 7)
			findVectorOUV();
		
		//if the polygon is completely inside the screen then no need to do clipping
		if(poly.withinViewScreen){
			visibleCount = L;
			for(int i =0; i < L; i ++){
				vertex2D[i].set(tempVertex[i]);
				vertex2D[i].setScreenLocation(tempVertex[i]);
			}
		}else
			findClipping();
		
		//scan line conversion
		scanPolygon();
		
		//for different polygons, the texture mapping alogrithm will differ depend 
		//on the nature of the polygon in order to optimize rendering
		if(poly.type == 1)
			renderSkybox();
		if(poly.type == 2)
			renderDistortionImproved();
		if(poly.type == 3)
			renderBasic();
		else if(poly.type == 4)
			renderDistortion();
		else if(poly.type == 5)
			renderFloor();
		else if(poly.type == 6)
			renderMipmap();
		else if(poly.type == 7)
			renderSoildPolygon();
		else if(poly.type == 8){
			renderReflection();
		}
		
	}
	
	//calculate O,U and V
	public static void findVectorOUV(){
		O.set(poly.origin);
		O.subtract(camera.position);
		O.rotate_XZ(camera.XZ_angle);
		O.rotate_YZ(camera.YZ_angle);

		U.set(poly.rightEnd);
		U.subtract(camera.position);
		U.rotate_XZ(camera.XZ_angle);
		U.rotate_YZ(camera.YZ_angle);

		V.set(poly.bottomEnd);
		V.subtract(camera.position);
		V.rotate_XZ(camera.XZ_angle);
		V.rotate_YZ(camera.YZ_angle);
		
		U.subtract(O);
		U.unit();
		U.scale(poly.textureScaleX);

		V.subtract(O);
		V.unit();
		V.scale(poly.textureScaleY);

		A = V.cross(O);
		B = O.cross(U);
		C = U.cross(V);
	}
	
	//clipping
	public static void findClipping(){
		visibleCount = 0;
		//the clipping algorithm iterate through all the vertex of the polygons, if it finds
		//a vertex which is behind the clipping plane(z = 0.001), then generate 2 new vertex on the
		//clipping plane
		
		for(int i = 0; i < L; i++){
			if(tempVertex[i].z >= 0.001){
				vertex2D[visibleCount].set(tempVertex[i]);
				vertex2D[visibleCount].setScreenLocation(tempVertex[i]);
				visibleCount++;
			} else{
				int index = (i+L - 1)%L;
				if(tempVertex[index].z >= 0.001){
					approximatePoint(visibleCount, tempVertex[i], tempVertex[index]);
					visibleCount++;
				}
				index = (i+1)%L;
				if(tempVertex[index].z >= 0.001){
					approximatePoint(visibleCount, tempVertex[i], tempVertex[index]);
					visibleCount++;
				}
			}
		}
	}
	
	//find the approximate projection point on the clipping plane
	public static void approximatePoint(int index, vector behindPoint, vector frontPoint){
		tempVector1.set(frontPoint.x - behindPoint.x, frontPoint.y - behindPoint.y, frontPoint.z - behindPoint.z);
		tempVector1.scale(frontPoint.z/tempVector1.z);
		vertex2D[index].set(frontPoint.x, frontPoint.y, frontPoint.z);
		vertex2D[index].subtract(tempVector1);
		vertex2D[index].add(0,0,0.001f);
		vertex2D[index].updateLocation();
	}
	
	//convert a polygon to scan lines
	public static void scanPolygon(){
		int start = (screen_h-1);
		int end = 0;
		int temp_ = 0;
		int g = 0;

		for(int i = 0; i < visibleCount; i++){
			vector v1 = vertex2D[i];
			vector v2;
			
			if(i == visibleCount -1 ){
				v2 = vertex2D[0];
			}else{
				v2 = vertex2D[i+1];
			}

			boolean downwards = false;

			//ensure v1.y < v2.y;
			if (v1.screenY> v2.screenY) {
				downwards = true;
				vector temp = v1;
				v1 = v2;
				v2 = temp;
			}
			int dy = v2.screenY - v1.screenY;
			
			// ignore horizontal lines
			if (dy == 0) {
				continue;
			}
			
			
			
			if(poly.withinViewScreen){
				int startY = Math.max(v1.screenY, 0);
				int endY = Math.min(v2.screenY, (screen_h-1));
				if(startY < start )
					start = startY;
				if(endY > end)
					end = endY;
				
				double dx = v2.screenX - v1.screenX;
				g = (int)(dx / dy *0xff);
				temp_ = v1.screenX<<8;

				
				for (int y=startY; y<=endY; y++) {
					if(downwards)
						xLow[y] = temp_ >> 8;
					else
						xHigh[y] = (temp_ >> 8) + 1;
					temp_+=g;
				}
				
				continue;
			}

			int startY = Math.max(v1.screenY, 0);
			int endY = Math.min(v2.screenY, (screen_h-1));

			if(startY < start )
				start = startY;

			if(endY > end)
				end = endY;

			double dx = v2.screenX - v1.screenX;
			double gradient = dx / dy;

			int temp_x, x;
			temp_ = (int)(v1.screenX + (startY - v1.screenY) * gradient) <<8;
			// scan-convert this edge (line equation)
			g = (int)(gradient*0xff);

			for (int y=startY; y<=endY; y++) {
				temp_x = temp_>>8;
				temp_+=g;
				// ensure x within view bounds
				x = Math.min((screen_w-1)+1, Math.max(temp_x, 0));
				if(downwards){
					xLow[y] = x;
				}else{
					if(x < (screen_w-1))
						x++;
					xHigh[y] = x ;
				}
			}
		}
		poly.start = start;
		poly.end = end;
	}
	
	//Texture mapper for rendering basic polygons 
	public static void renderBasic(){
		int[] screen = main.screen;
		short[] Texture = poly.myTexture.Texture; 
		diffuse_I = poly.diffuse_I;
		int[]colorTable = gameData.colorTable[diffuse_I];
	
		A_offset = A.x*16;
		B_offset = B.x*16;
		C_offset = C.x*16;
		
		double Aoffset,Boffset,Coffset;
		
		int start = poly.start;
		int end = poly.end;
		
		for(int i = start; i <= end; i++){
			W.set(xLow[i]-half_screen_w, -i + half_screen_h, vector.Z_length);
			aDotW = A.dot(W);
			bDotW = B.dot(W);
			cDotW = C.dot(W);
			
			//find the texture coordinate for the start pixel of the scanline
			cDotWInverse = 1/cDotW;
			X = (int)(aDotW*cDotWInverse);
			Y = (int)(bDotW*cDotWInverse);
			X1 = X;
			Y1 = Y;
			
			int temp = gameData.screenTable[i];
			int index;
			for(int j = xLow[i]; j < xHigh[i]; j+=16){
				X = X1;
				Y = Y1;
				
				index = j + temp;
				if(xHigh[i] - j > 15){
					//find the correct texture coordinate every 16 pixels.
					//Use the interpolation values for  pixels in between.
					aDotW+=A_offset;
					bDotW+=B_offset;
					cDotW+=C_offset;
					cDotWInverse = 1/cDotW;
					X1 = (int)(aDotW*cDotWInverse);
					Y1 = (int)(bDotW*cDotWInverse);
					dx = X1 - X;
					dy = Y1 - Y;
					
					
					for( k = 16, d_x = 0, d_y = 0; k >0; k--, d_x+=dx, d_y+=dy, index++){
						textureIndex = (((d_x>>4) + X)&widthMask) + ((((d_y>>4) + Y)&heightMask)<<widthBits);
						screen[index] = colorTable[Texture[textureIndex]];
					}
					
					continue;
				}
				
				int offset = xHigh[i] - j;
				Aoffset = A.x*offset;
				Boffset = B.x*offset;
				Coffset = C.x*offset;
	
				aDotW+=Aoffset;
				bDotW+=Boffset;
				cDotW+=Coffset;
				cDotWInverse = 1/cDotW;
				X1 = (int)(aDotW*cDotWInverse);
				Y1 = (int)(bDotW*cDotWInverse);
				dx = X1 - X;
				dy = Y1 - Y;
				

				for( k = offset, d_x = 0, d_y = 0; k >0; k--, d_x+=dx, d_y+=dy, index++){
					textureIndex = (((d_x/offset) + X)&widthMask) + ((((d_y/offset) + Y)&heightMask)<<widthBits);
					
					screen[index] = colorTable[Texture[textureIndex]];
				}
				
				break;
			}
		}
	}
	
	//Texture mapper for rendering  polygons with mipmaping enabled 
	public static void renderMipmap(){
		int[] screen = main.screen;
		short[][] mipmap = poly.myTexture.mipmap; 
		diffuse_I = poly.diffuse_I;
		int[]colorTable = gameData.colorTable[diffuse_I];
		float z_texel;
		int mipmapIndex = 0;
		int widthBitsMipmap;
		int widthMaskMipmap;
		int heightMaskMipmap;
		
		//The level of mipmap depends on how far away the texel is  from the view point,
		//The z value of each texel is interpolated  between vertices. 
		tempVector1.set(poly.origin);
		tempVector1.subtract(camera.position);
		tempVector1.rotate_XZ(camera.XZ_angle);
		tempVector1.rotate_YZ(camera.YZ_angle);

		tempVector2.set(poly.rightEnd);
		tempVector2.subtract(camera.position);
		tempVector2.rotate_XZ(camera.XZ_angle);
		tempVector2.rotate_YZ(camera.YZ_angle);

		tempVector3.set(poly.bottomEnd);
		tempVector3.subtract(camera.position);
		tempVector3.rotate_XZ(camera.XZ_angle);
		tempVector3.rotate_YZ(camera.YZ_angle);
		
		float z_origin = tempVector1.z;
		float dz_x =  (tempVector2.z - z_origin)/(poly.scaleX * poly.myTexture.width);
		float dz_y =  (tempVector3.z - z_origin)/(poly.scaleY * poly.myTexture.height);
		
		
	
		A_offset = A.x*16;
		B_offset = B.x*16;
		C_offset = C.x*16;
		
		double Aoffset,Boffset,Coffset;
		
		int start = poly.start;
		int end = poly.end;
		
		for(int i = start; i <= end; i++){
			W.set(xLow[i]-half_screen_w, -i + half_screen_h, vector.Z_length);
			aDotW = A.dot(W);
			bDotW = B.dot(W);
			cDotW = C.dot(W);
			
			//find the texture coordinate for the start pixel of the scanline
			cDotWInverse = 1/cDotW;
			X = (int)(aDotW*cDotWInverse);
			Y = (int)(bDotW*cDotWInverse);
			X1 = X;
			Y1 = Y;
			
			int temp = gameData.screenTable[i];
			int index;
			for(int j = xLow[i]; j < xHigh[i]; j+=16){
				X = X1;
				Y = Y1;
				
				index = j + temp;
				if(xHigh[i] - j > 15){
					//find the correct texture coordinate every 16 pixels.
					//Use the interpolation values for the  pixels in between.
					aDotW+=A_offset;
					bDotW+=B_offset;
					cDotW+=C_offset;
					cDotWInverse = 1/cDotW;
					X1 = (int)(aDotW*cDotWInverse);
					Y1 = (int)(bDotW*cDotWInverse);
					dx = X1 - X;
					dy = Y1 - Y;
					
					
					z_texel = z_origin + dz_x*X + dz_y*Y;
					if(z_texel < 0.3)
						mipmapIndex = 0;
					else if(z_texel < 0.6)
						mipmapIndex = 1;
					else if(z_texel < 1.1)
						mipmapIndex = 2;
					else if(z_texel < 1.8)
						mipmapIndex = 3;
					else
						mipmapIndex = 4;
					
					widthBitsMipmap = widthBits - mipmapIndex;
					widthMaskMipmap = ((widthMask + 1) >> mipmapIndex) - 1;
					heightMaskMipmap = ((heightMask + 1) >> mipmapIndex) - 1;
					
					
					
					for( k = 16, d_x = 0, d_y = 0; k >0; k--, d_x+=dx, d_y+=dy, index++){
						textureIndex = ((((d_x>>4) + X)>>mipmapIndex)&widthMaskMipmap) + (((((d_y>>4) + Y)>>mipmapIndex)&heightMaskMipmap)<<widthBitsMipmap);
						screen[index] = colorTable[mipmap[mipmapIndex][textureIndex]];
					}
					
					continue;
				}
				
				int offset = xHigh[i] - j;
				Aoffset = A.x*offset;
				Boffset = B.x*offset;
				Coffset = C.x*offset;
	
				aDotW+=Aoffset;
				bDotW+=Boffset;
				cDotW+=Coffset;
				cDotWInverse = 1/cDotW;
				X1 = (int)(aDotW*cDotWInverse);
				Y1 = (int)(bDotW*cDotWInverse);
				dx = X1 - X;
				dy = Y1 - Y;
				

				z_texel = z_origin + dz_x*X + dz_y*Y;
				if(z_texel < 0.2)
					mipmapIndex = 0;
				else if(z_texel < 0.5)
					mipmapIndex = 1;
				else if(z_texel < 1)
					mipmapIndex = 2;
				else if(z_texel < 1.7)
					mipmapIndex = 3;
				else
					mipmapIndex = 4;
				
				widthBitsMipmap = widthBits - mipmapIndex;
				widthMaskMipmap = ((widthMask + 1) >> mipmapIndex) - 1;
				heightMaskMipmap = ((heightMask + 1) >> mipmapIndex) - 1;
				
				for( k = offset, d_x = 0, d_y = 0; k >0; k--, d_x+=dx, d_y+=dy, index++){
					textureIndex = ((((d_x/offset) + X)>>mipmapIndex)&widthMaskMipmap) + (((((d_y/offset) + Y)>>mipmapIndex)&heightMaskMipmap)<<widthBitsMipmap);
					screen[index] = colorTable[mipmap[mipmapIndex][textureIndex]];
				}
				
				break;
			}
		}
	}
	
	//Texture mapper for rendering polygons that distort the image behind it.
	public static void renderDistortion(){
		int[] screen = main.screen;
		short[] Texture = poly.myTexture.Texture; 
		diffuse_I = poly.diffuse_I;
		int[] colorTable = gameData.colorTable[diffuse_I];
		byte[][] distortionMap =  poly.myTexture.distortionMap;
		int[] stencilBuffer = main.stencilBuffer;
		int distortedIndex = 0;
		int pixel = 0;
		int overflow = 0;
	
		A_offset = A.x*16;
		B_offset = B.x*16;
		C_offset = C.x*16;
		
		double Aoffset,Boffset,Coffset;
		
		int start = poly.start;
		int end = poly.end;
		
		for(int i = start; i <= end; i++){
			W.set(xLow[i]-half_screen_w, -i + half_screen_h, vector.Z_length);
			aDotW = A.dot(W);
			bDotW = B.dot(W);
			cDotW = C.dot(W);
			
			//find the texture coordinate for the start pixel of the scanline
			cDotWInverse = 1/cDotW;
			X = (int)(aDotW*cDotWInverse);
			Y = (int)(bDotW*cDotWInverse);
			X1 = X;
			Y1 = Y;
			
			int temp = gameData.screenTable[i];
			int index;
			for(int j = xLow[i]; j < xHigh[i]; j+=16){
				X = X1;
				Y = Y1;
				
				index = j + temp;
				if(xHigh[i] - j > 15){
					//find the correct texture coordinate every 16 pixels.
					//Use the interpolation values for the rest pixels.
					aDotW+=A_offset;
					bDotW+=B_offset;
					cDotW+=C_offset;
					cDotWInverse = 1/cDotW;
					X1 = (int)(aDotW*cDotWInverse);
					Y1 = (int)(bDotW*cDotWInverse);
					dx = X1 - X;
					dy = Y1 - Y;
					
				
					for( k = 16, d_x = 0, d_y = 0; k >0; k--, d_x+=dx, d_y+=dy, index++){
						
						
						textureIndex = (((d_x>>4) + X)&widthMask) + ((((d_y>>4) + Y)&heightMask)<<widthBits);
						
						distortedIndex = index + distortionMap[textureIndex][0] + screen_w*distortionMap[textureIndex][1];
						if(distortedIndex < 0 || distortedIndex >= screen_pixel_count)
							distortedIndex = index;
						
						temp1 = (screen[distortedIndex]&0xFEFEFE)>>1;
						temp2= colorTable[Texture[textureIndex]];
						
						pixel=(temp2&0xFEFEFF)+(temp1&0xFEFEFF);
						overflow=pixel&0x1010100;
						overflow=overflow-(overflow>>8);
						
						//draw the pixel on to a stencil buffer
						stencilBuffer[index] = overflow|pixel;;
						
					}
				
					continue;
				}
				
				int offset = xHigh[i] - j;
				Aoffset = A.x*offset;
				Boffset = B.x*offset;
				Coffset = C.x*offset;
	
				aDotW+=Aoffset;
				bDotW+=Boffset;
				cDotW+=Coffset;
				cDotWInverse = 1/cDotW;
				X1 = (int)(aDotW*cDotWInverse);
				Y1 = (int)(bDotW*cDotWInverse);
				dx = X1 - X;
				dy = Y1 - Y;
				
				
				
				for( k = offset, d_x = 0, d_y = 0; k >0; k--, d_x+=dx, d_y+=dy, index++){
					textureIndex = (((d_x/offset) + X)&widthMask) + ((((d_y/offset) + Y)&heightMask)<<widthBits);
					
					distortedIndex = index + distortionMap[textureIndex][0] + screen_w*distortionMap[textureIndex][1];
					if(distortedIndex < 0 || distortedIndex >= screen_pixel_count)
						distortedIndex = index;
					
					temp1 = (screen[distortedIndex]&0xFEFEFE)>>1;
					temp2= colorTable[Texture[textureIndex]];
					
					pixel=(temp2&0xFEFEFF)+(temp1&0xFEFEFF);
					overflow=pixel&0x1010100;
					overflow=overflow-(overflow>>8);
					
					//draw the pixel on to a stencil buffer
					stencilBuffer[index] = overflow|pixel;;
				}
				
				break;
			}
		}
		//copy the content of the stencil buffer to screen buffer.
		for(int i = start; i <= end; i++){
			int offset = xHigh[i] - xLow[i];
			temp = gameData.screenTable[i];
			int index = xLow[i] + temp;
			for(k = offset; k >0; k--, index++){
				
				screen[index] = stencilBuffer[index];
				
			}
		}
	}
	
	//An improved version of previous distortion shader
	//the level of distortion now depends on the distance from the view point
	public static void renderDistortionImproved(){
		int[] screen = main.screen;
		short[] Texture = poly.myTexture.Texture; 
		diffuse_I = poly.diffuse_I;
		int[] colorTable = gameData.colorTable[diffuse_I];
		byte[][] distortionMap =  poly.myTexture.distortionMap;
		int[] stencilBuffer = main.stencilBuffer;
		int distortedIndex = 0;
		int color = colorTable[Texture[0]];
	
		A_offset = A.x*16;
		B_offset = B.x*16;
		C_offset = C.x*16;
		
		double Aoffset,Boffset,Coffset;
		
		int start = poly.start;
		int end = poly.end;
		vector c = poly.centre;
		float distance = c.getLength();
		int displacement = 1;
		
		if(distance < 0.2)
			displacement = 1;
		if(distance < 0.4 && distance >=0.2)
			displacement = 2;
		if(distance < 0.6 && distance >=0.4)
			displacement = 3;
		if(distance < 0.8 && distance >=0.6)
			displacement = 4;
		if(distance < 1.0 && distance >= 0.8)
			displacement = 5;
		if(distance >= 1.0)
			displacement = 6;
		
		for(int i = start; i <= end; i++){
			W.set(xLow[i]-half_screen_w, -i + half_screen_h, vector.Z_length);
			aDotW = A.dot(W);
			bDotW = B.dot(W);
			cDotW = C.dot(W);
			
			//find the texture coordinate for the start pixel of the scanline
			cDotWInverse = 1/cDotW;
			X = (int)(aDotW*cDotWInverse);
			Y = (int)(bDotW*cDotWInverse);
			X1 = X;
			Y1 = Y;
			
			int temp = gameData.screenTable[i];
			int index;
			for(int j = xLow[i]; j < xHigh[i]; j+=16){
				X = X1;
				Y = Y1;
				
				index = j + temp;
				if(xHigh[i] - j > 15){
					//find the correct texture coordinate every 16 pixels.
					//Use the interpolation values for the rest pixels.
					aDotW+=A_offset;
					bDotW+=B_offset;
					cDotW+=C_offset;
					cDotWInverse = 1/cDotW;
					X1 = (int)(aDotW*cDotWInverse);
					Y1 = (int)(bDotW*cDotWInverse);
					dx = X1 - X;
					dy = Y1 - Y;
					
				
					if(displacement != 1){
						for( k = 16, d_x = 0, d_y = 0; k >0; k--, d_x+=dx, d_y+=dy, index++){
							
							
							textureIndex = (((d_x>>4) + X)&widthMask) + ((((d_y>>4) + Y)&heightMask)<<widthBits);
							
							distortedIndex = index + distortionMap[textureIndex][0]/displacement + screen_w*(distortionMap[textureIndex][1]/displacement);
							if(distortedIndex < 0 || distortedIndex >= screen_pixel_count)
								distortedIndex = index;
							
							
							//draw the pixel on to a stencil buffer
							stencilBuffer[index] = ((screen[distortedIndex]&0xFEFEFE)>>1) + color;
							
						}
					}else{
							for( k = 16, d_x = 0, d_y = 0; k >0; k--, d_x+=dx, d_y+=dy, index++){
							
							
							textureIndex = (((d_x>>4) + X)&widthMask) + ((((d_y>>4) + Y)&heightMask)<<widthBits);
							
							distortedIndex = index + distortionMap[textureIndex][0] + screen_w*(distortionMap[textureIndex][1]);
							if(distortedIndex < 0 || distortedIndex >= screen_pixel_count)
								distortedIndex = index;
							
							
							stencilBuffer[index] = ((screen[distortedIndex]&0xFEFEFE)>>1) + color;
							
						}
					}
				
					continue;
				}
				
				int offset = xHigh[i] - j;
				Aoffset = A.x*offset;
				Boffset = B.x*offset;
				Coffset = C.x*offset;
	
				aDotW+=Aoffset;
				bDotW+=Boffset;
				cDotW+=Coffset;
				cDotWInverse = 1/cDotW;
				X1 = (int)(aDotW*cDotWInverse);
				Y1 = (int)(bDotW*cDotWInverse);
				dx = X1 - X;
				dy = Y1 - Y;
				
				
				
				if(displacement != 1){
					for( k = offset, d_x = 0, d_y = 0; k >0; k--, d_x+=dx, d_y+=dy, index++){
						textureIndex = (((d_x/offset) + X)&widthMask) + ((((d_y/offset) + Y)&heightMask)<<widthBits);
						
						distortedIndex = index + (distortionMap[textureIndex][0]/displacement) + screen_w*(distortionMap[textureIndex][1]/displacement);
						if(distortedIndex < 0 || distortedIndex >= screen_pixel_count)
							distortedIndex = index;
						
						
						stencilBuffer[index] = ((screen[distortedIndex]&0xFEFEFE)>>1) + color;
					}
				}else{
					for( k = offset, d_x = 0, d_y = 0; k >0; k--, d_x+=dx, d_y+=dy, index++){
						textureIndex = (((d_x/offset) + X)&widthMask) + ((((d_y/offset) + Y)&heightMask)<<widthBits);
						
						distortedIndex = index + (distortionMap[textureIndex][0]) + screen_w*(distortionMap[textureIndex][1]);
						if(distortedIndex < 0 || distortedIndex >= screen_pixel_count)
							distortedIndex = index;
						
						
						
						stencilBuffer[index] = ((screen[distortedIndex]&0xFEFEFE)>>1) + color;
					}
				}
				
				break;
			}
		}
		//copy the content of the stencil buffer to screen buffer.
		for(int i = start; i <= end; i++){
			int offset = xHigh[i] - xLow[i];
			temp = gameData.screenTable[i];
			int index = xLow[i] + temp;
			for(k = offset; k >0; k--, index++){
				
				screen[index] = stencilBuffer[index];
				
			}
		}
	}
	
	//floor polygon acts like reflector for everything above it. Since the reflected objects 
	//and the floor share the same coordinate system , we just need to blend the floor
	//texture with reflected scene which was  drawn to the reflection buffer. 
	public static void renderFloor(){
		int[] screen = main.screen;
		int[] reflectionBuffer = main.reflectionBuffer;
		diffuse_I = poly.diffuse_I;
		int[]colorTable = gameData.colorTable[diffuse_I]; 
		short[] Texture = poly.myTexture.Texture; 
		
		//some variables for color arithmetic
		int pixel = 0;
		int ALPHA=0xFF000000;
		int MASK7Bit=0xFEFEFF;
		int overflow = 0;
		
		A_offset = A.x*16;
		B_offset = B.x*16;
		C_offset = C.x*16;
		
		double Aoffset,Boffset,Coffset;
		
		int start = poly.start;
		int end = poly.end;
		
		for(int i = start; i <= end; i++){
			W.set(xLow[i]-half_screen_w, -i + half_screen_h, vector.Z_length);
			aDotW = A.dot(W);
			bDotW = B.dot(W);
			cDotW = C.dot(W);
			
			//find the texture coordinate for the start pixel of the scanline
			cDotWInverse = 1/cDotW;
			X = (int)(aDotW*cDotWInverse);
			Y = (int)(bDotW*cDotWInverse);
			X1 = X;
			Y1 = Y;
			
			int temp = gameData.screenTable[i];
			int index;
			for(int j = xLow[i]; j < xHigh[i]; j+=16){
				X = X1;
				Y = Y1;
				
				index = j + temp;
				if(xHigh[i] - j > 15){
					//find the correct texture coordinate every 16 pixels.
					//Use the interpolation values for the  pixels in between.
					aDotW+=A_offset;
					bDotW+=B_offset;
					cDotW+=C_offset;
					cDotWInverse = 1/cDotW;
					X1 = (int)(aDotW*cDotWInverse);
					Y1 = (int)(bDotW*cDotWInverse);
					dx = X1 - X;
					dy = Y1 - Y;
					
				
				
					
					
					for( k = 16, d_x = 0, d_y = 0; k >0; k--, d_x+=dx, d_y+=dy, index++){
						textureIndex = (((d_x>>4) + X)&widthMask) + ((((d_y>>4) + Y)&heightMask)<<widthBits);	
						temp1 = colorTable[Texture[textureIndex]];
						temp2 = reflectionBuffer[index];
						if(temp2 != 0){
							temp2= (temp2&0xFEFEFE)>>1;
							pixel=(temp1&MASK7Bit)+(temp2&MASK7Bit);
							overflow=pixel&0x1010100;
							overflow=overflow-(overflow>>8);
							screen[index] = ALPHA|overflow|pixel;
							
							//reset reflection buffer at current pixel location
							reflectionBuffer[index] = 0;
						}else{
							screen[index] = temp1;
						}
							
						
						
						
					}
					
					continue;
				}
				
				int offset = xHigh[i] - j;
				Aoffset = A.x*offset;
				Boffset = B.x*offset;
				Coffset = C.x*offset;
	
				aDotW+=Aoffset;
				bDotW+=Boffset;
				cDotW+=Coffset;
				cDotWInverse = 1/cDotW;
				X1 = (int)(aDotW*cDotWInverse);
				Y1 = (int)(bDotW*cDotWInverse);
				dx = X1 - X;
				dy = Y1 - Y;
		
				
			
				
				for( k = offset, d_x = 0, d_y = 0; k >0; k--, d_x+=dx, d_y+=dy, index++){
					textureIndex = (((d_x/offset) + X)&widthMask) + ((((d_y/offset) + Y)&heightMask)<<widthBits);
					temp1 = colorTable[Texture[textureIndex]];
					temp2 = reflectionBuffer[index];
					if(temp2 != 0){
						temp2= (temp2&0xFEFEFE)>>1;
						pixel=(temp1&MASK7Bit)+(temp2&MASK7Bit);
						overflow=pixel&0x1010100;
						overflow=overflow-(overflow>>8);
						screen[index] = ALPHA|overflow|pixel;
						reflectionBuffer[index] = 0;
					}else
						screen[index]= temp1;
				}
				
				break;
			}
		}
	}
	
	//Texture mapper for rendering sky maps.
	public static void renderSkybox(){
		int[] screen = main.screen;
		int[] Texture = poly.myTexture.texture_24bits; 
		diffuse_I = poly.diffuse_I;
	
		A_offset = A.x*16;
		B_offset = B.x*16;
		C_offset = C.x*16;
		
		double Aoffset,Boffset,Coffset;
		
		int start = poly.start;
		int end = poly.end;
		
		for(int i = start; i <= end; i++){
			W.set(xLow[i]-half_screen_w, -i + half_screen_h, vector.Z_length);
			aDotW = A.dot(W);
			bDotW = B.dot(W);
			cDotW = C.dot(W);
			
			//find the texture coordinate for the start pixel of the scanline
			cDotWInverse = 1/cDotW;
			X = (int)(aDotW*cDotWInverse);
			Y = (int)(bDotW*cDotWInverse);
			X1 = X;
			Y1 = Y;
			
			int temp = gameData.screenTable[i];
			int index;
			for(int j = xLow[i]; j < xHigh[i]; j+=16){
				X = X1;
				Y = Y1;
				
				index = j + temp;
				if(xHigh[i] - j > 15){
					//find the correct texture coordinate every 16 pixels.
					//Use the interpolation values for the rest pixels.
					aDotW+=A_offset;
					bDotW+=B_offset;
					cDotW+=C_offset;
					cDotWInverse = 1/cDotW;
					X1 = (int)(aDotW*cDotWInverse);
					Y1 = (int)(bDotW*cDotWInverse);
					dx = X1 - X;
					dy = Y1 - Y;
					
					
					for( k = 16, d_x = 0, d_y = 0; k >0; k--, d_x+=dx, d_y+=dy, index++){
						textureIndex = (((d_x>>4) + X)&widthMask) + ((((d_y>>4) + Y)&heightMask)<<widthBits);
						screen[index] = Texture[textureIndex];
					}
					
					continue;
				}
				
				int offset = xHigh[i] - j;
				Aoffset = A.x*offset;
				Boffset = B.x*offset;
				Coffset = C.x*offset;
	
				aDotW+=Aoffset;
				bDotW+=Boffset;
				cDotW+=Coffset;
				cDotWInverse = 1/cDotW;
				X1 = (int)(aDotW*cDotWInverse);
				Y1 = (int)(bDotW*cDotWInverse);
				dx = X1 - X;
				dy = Y1 - Y;
				
				for( k = offset, d_x = 0, d_y = 0; k >0; k--, d_x+=dx, d_y+=dy, index++){
					textureIndex = (((d_x/offset) + X)&widthMask) + ((((d_y/offset) + Y)&heightMask)<<widthBits);
					screen[index] = Texture[textureIndex];
				}
				break;
			}
		}
	}
	
	//rendering polygon that has a soild color
	public static void renderSoildPolygon(){
		int soildColor = poly.color;
		short color15Bits;
		r = (soildColor & 0x00ff0000)>>16;
		g = (soildColor & 0x0000ff00)>>8;
		b = (soildColor & 0x000000ff);
		r = r/8;
		g = g/8;
		b = b/8;
		color15Bits = (short)((int)r <<10 | (int)g << 5 | (int)b);
		soildColor = gameData.colorTable[poly.diffuse_I][color15Bits];
		
		int[] screen = main.screen;
		
		int start = poly.start;
		int end = poly.end;
		
		for(int i = start; i <= end; i++){
			int temp = gameData.screenTable[i];
			int index;
			for(int j = xLow[i]; j < xHigh[i]; j++){
				index = j + temp;
				temp1 = screen[index];
				temp2= soildColor;
				r=(alpha*(((temp1>>16)&255)-((temp2>>16)&255))>>8)+((temp2>>16)&255);
				g=(alpha*(((temp1>>8)&255)-((temp2>>8)&255))>>8)+((temp2>>8)&255);
				b=(alpha*((temp1&255)-(temp2&255))>>8)+(temp2&255);
				screen[index] = (r<<16)|(g<<8)|b;
			}
		}
	}
	
	
	//The reflected 3D objects are just mirror images of real 3d objects.  So when drawing a polygon from 
	//a reflected 3D object, the texture will be rendered upside down. Reflected 3D objects are drawn to 
    //the reflection buffer instead of  screen buffer.
	public static void renderReflection(){
		int[] screen = main.reflectionBuffer;
		short[] Texture = poly.myTexture.Texture; 
		diffuse_I = poly.diffuse_I;
		int[]colorTable = gameData.colorTable[diffuse_I];
		int h = textureHeight;
	
		A_offset = A.x*16;
		B_offset = B.x*16;
		C_offset = C.x*16;
		
		double Aoffset,Boffset,Coffset;
		
		int start = poly.start;
		int end = poly.end;
		
		if(diffuse_I == 0){
			for(int i = start; i <= end; i++){
				int temp = gameData.screenTable[i];
				int index;
				for(int j = xLow[i]; j < xHigh[i]; j++){
					index = j + temp;
					screen[index] = 1;
				}
			}
			return;
		}
		
		for(int i = start; i <= end; i++){
			W.set(xLow[i]-half_screen_w, -i + half_screen_h, vector.Z_length);
			aDotW = A.dot(W);
			bDotW = B.dot(W);
			cDotW = C.dot(W);
			
			//find the texture coordinate for the start pixel of the scanline
			cDotWInverse = 1/cDotW;
			X = (int)(aDotW*cDotWInverse);
			Y = (int)(bDotW*cDotWInverse);
			X1 = X;
			Y1 = Y;
			
			int temp = gameData.screenTable[i];
			int index;
			for(int j = xLow[i]; j < xHigh[i]; j+=16){
				X = X1;
				Y = Y1;
				
				index = j + temp;
				if(xHigh[i] - j > 15){
					//find the correct texture coordinate every 16 pixels.
					//Use the interpolation values for  pixels in between.
					aDotW+=A_offset;
					bDotW+=B_offset;
					cDotW+=C_offset;
					cDotWInverse = 1/cDotW;
					X1 = (int)(aDotW*cDotWInverse);
					Y1 = (int)(bDotW*cDotWInverse);
					dx = X1 - X;
					dy = Y1 - Y;
					
					
					for( k = 16, d_x = 0, d_y = 0; k >0; k--, d_x+=dx, d_y+=dy, index++){
						
						textureIndex = (((d_x>>4) + X)&widthMask) + (((h-((d_y>>4) + Y))&heightMask)<<widthBits);
						screen[index] = colorTable[Texture[textureIndex]];
					}
					
					continue;
				}
				
				int offset = xHigh[i] - j;
				Aoffset = A.x*offset;
				Boffset = B.x*offset;
				Coffset = C.x*offset;
	
				aDotW+=Aoffset;
				bDotW+=Boffset;
				cDotW+=Coffset;
				cDotWInverse = 1/cDotW;
				X1 = (int)(aDotW*cDotWInverse);
				Y1 = (int)(bDotW*cDotWInverse);
				dx = X1 - X;
				dy = Y1 - Y;
				

				for( k = offset, d_x = 0, d_y = 0; k >0; k--, d_x+=dx, d_y+=dy, index++){
					textureIndex = (((d_x/offset) + X)&widthMask) + (((h-((d_y/offset) + Y))&heightMask)<<widthBits);
					
					screen[index] = colorTable[Texture[textureIndex]];
				}
				
				break;
			}
		}
	}
	

}
