package core;
//3d model: lower part of chandelier 
public class chandelier_lower extends solidObject{
	public chandelier_lower(vector centre){
		//centre point of the model (in world coordinate)
		start = centre.myClone();
		this.centre = start.myClone();
		tempCentre = start.myClone();
		
		//define reference axis (in world coordinate)
		iDirection = new vector(1,0,0);
		jDirection = new vector(0,1,0);
		kDirection = new vector(0,0,1);
		
		//create a rough 3D cuboid boundary for this model.
		makeBoundary(0.05f, 0.05f, 0.05f);
		
		makePolygons();
		
	}
	
	public void makePolygons(){
		polygons = new polygon3D[122];
		vector[] t;
	
		start.add(0, 0.036f,0);
		
		int index =0;
		double r2 = 0.02;
		double r3 = 0.017;
		double r4 = 0.001;
		double theta = Math.PI/3;
		
		t = new vector[6];
		for(int i = 1; i < 7; i++)
			t[i-1] = put(r2*Math.cos(i*theta), 0.01399, r2*Math.sin(i*theta));
		polygons[index] = new polygon3D(t, t[0], t[1], t[4], main.textures[25], 1,1, 3); 
		index++;
		
		//inner
		for(int i = 0; i < 6; i ++){
			
			
			t = new vector[]{put(r2*Math.cos(i*theta), 0.009, r2*Math.sin(i*theta)),
						put(r2*Math.cos((i+1)*theta), 0.009, r2*Math.sin((i+1)*theta)),
						put(r2*Math.cos((i+1)*theta), 0.01399, r2*Math.sin((i+1)*theta)),
						put(r2*Math.cos(i*theta), 0.01399, r2*Math.sin(i*theta))
					};
			polygons[index] = new polygon3D(t, t[0], t[1], t[3], main.textures[25], 1,1, 3); 
			polygons[index].diffuse_I+=10;
			index++;
			
			vector temp1 = put(r2*Math.cos(i*theta), 0.009, r2*Math.sin(i*theta));
			vector temp2 = put(r2*Math.cos((i+1)*theta), 0.009, r2*Math.sin((i+1)*theta));
			vector temp4 = put(r2*Math.cos(i*theta), -0.04, r2*Math.sin(i*theta));
			vector temp3 = put(r2*Math.cos((i+1)*theta), -0.04, r2*Math.sin((i+1)*theta));
			vector d = temp2.myClone();
			d.subtract(temp1);
			d.scale(0.1f);
			temp2.add(d, -9);
			temp3.add(d, -9);
			
			
			
			t = new vector[]{temp4, temp3, temp2, temp1};
			polygons[index] = new polygon3D(t, t[0], t[1], t[3], main.textures[25], 0.2f,5, 3); 
			polygons[index].diffuse_I+=10;
			index++;
			
			temp1 = temp1.myClone();
			temp2 = temp2.myClone();
			temp3 = temp3.myClone();
			temp4 = temp4.myClone();
			temp1.add(d, 9);
			temp2.add(d, 9);
			temp3.add(d, 9);
			temp4.add(d, 9);
			
			
			
			t = new vector[]{temp4, temp3, temp2, temp1};
			polygons[index] = new polygon3D(t, t[0], t[1], t[3], main.textures[25], 0.2f,5, 3); 
			polygons[index].diffuse_I+=10;
			index++;
			
			temp1 = temp1.myClone();
			temp2 = temp2.myClone();
			temp3 = temp3.myClone();
			temp4 = temp4.myClone();
			temp1.add(d, -8);
			temp2.add(d, -1);
			temp3.add(d, -1);
			temp4.add(d, -8);
			
			t = new vector[]{temp4, temp3,temp2,temp1};
			polygons[index] = new polygon3D(t, t[0], t[1], t[3], main.textures[24], 1,1, 2); 
			polygons[index].diffuse_I=15;
			index++;
			

			t = new vector[]{put(r2*Math.cos(i*theta), -0.045, r2*Math.sin(i*theta)),
					 put(r2*Math.cos((i+1)*theta), -0.045, r2*Math.sin((i+1)*theta)),
					 put(r2*Math.cos((i+1)*theta), -0.04, r2*Math.sin((i+1)*theta)),
					 put(r2*Math.cos(i*theta), -0.04, r2*Math.sin(i*theta))
					
					
					 
					};
			polygons[index] = new polygon3D(t, t[0], t[1], t[3], main.textures[25], 1,0.5f, 3); 
			polygons[index].diffuse_I+=10;
			index++;
			
			t = new vector[]{ put(r3*Math.cos(i*theta), -0.045, r3*Math.sin(i*theta)),
					 put(r3*Math.cos((i+1)*theta), -0.045, r3*Math.sin((i+1)*theta)),	
					 put(r2*Math.cos((i+1)*theta), -0.045, r2*Math.sin((i+1)*theta)),
					 put(r2*Math.cos(i*theta), -0.045, r2*Math.sin(i*theta)), 
					
					
					 
			};
				polygons[index] = new polygon3D(t, t[0], t[1], t[3], main.textures[25], 1,0.2f, 3); 
				
				index++;
		}
		
		for(int i = 0; i < 48; i ++){
			t = new vector[]{put(r4*Math.cos(i*theta/8), 0.009, r4*Math.sin(i*theta/8)),
							 put(r4*Math.cos((i+1)*theta/8), 0.009, r4*Math.sin((i+1)*theta/8)),
							 put(r4*Math.cos((i+1)*theta/8), -0.025, r4*Math.sin((i+1)*theta/8)),
							 put(r4*Math.cos(i*theta/8), -0.025, r4*Math.sin(i*theta/8))
							};
			polygons[index] = new polygon3D(t, t[0], t[1], t[3], null, 1,1, 7); 
			polygons[index].color = 0x00888888;
			
			//polygons[index].findDiffuse();
			index++;
		}
		
		t = new vector[48];
		for(int i = 1; i < 49; i++)
			t[i-1] = put(r4*Math.cos(i*theta/8), -0.025, r4*Math.sin(i*theta/8));
		polygons[index] = new polygon3D(t, t[0], t[1], t[4], null, 1,1, 7); 
		polygons[index].color = 0x00888888;
		index++;
		
		
		
		
		//outer
		for(int i = 0; i < 6; i ++){
			t = new vector[]{put(r2*Math.cos(i*theta), 0.01399, r2*Math.sin(i*theta)),
							 put(r2*Math.cos((i+1)*theta), 0.01399, r2*Math.sin((i+1)*theta)),
							 put(r2*Math.cos((i+1)*theta), 0.009, r2*Math.sin((i+1)*theta)),
							 put(r2*Math.cos(i*theta), 0.009, r2*Math.sin(i*theta))
							};
			polygons[index] = new polygon3D(t, t[0], t[1], t[3], main.textures[25], 1,1, 3); 
			polygons[index].diffuse_I+=10;
			index++;
			
			
			
			vector temp1 = put(r2*Math.cos(i*theta), 0.009, r2*Math.sin(i*theta));
			vector temp2 = put(r2*Math.cos((i+1)*theta), 0.009, r2*Math.sin((i+1)*theta));
			vector temp4 = put(r2*Math.cos(i*theta), -0.04, r2*Math.sin(i*theta));
			vector temp3 = put(r2*Math.cos((i+1)*theta), -0.04, r2*Math.sin((i+1)*theta));
			vector d = temp2.myClone();
			d.subtract(temp1);
			d.scale(0.1f);
			temp2.add(d, -9);
			temp3.add(d, -9);
			
			t = new vector[]{temp1, temp2, temp3, temp4};
			polygons[index] = new polygon3D(t, t[0], t[1], t[3], main.textures[25], 0.2f,5, 3); 
			polygons[index].diffuse_I+=10;
			index++;
			
			
			temp1 = temp1.myClone();
			temp2 = temp2.myClone();
			temp3 = temp3.myClone();
			temp4 = temp4.myClone();
			temp1.add(d, 9);
			temp2.add(d, 9);
			temp3.add(d, 9);
			temp4.add(d, 9);
			
			t = new vector[]{temp1, temp2, temp3, temp4};
			polygons[index] = new polygon3D(t, t[0], t[1], t[3], main.textures[25], 0.2f,5, 3); 
			polygons[index].diffuse_I+=10;
			index++;
			
			
			
			temp1 = temp1.myClone();
			temp2 = temp2.myClone();
			temp3 = temp3.myClone();
			temp4 = temp4.myClone();
			temp1.add(d, -8);
			temp2.add(d, -1);
			temp3.add(d, -1);
			temp4.add(d, -8);
			
			t = new vector[]{temp1,temp2, temp3,temp4};
			polygons[index] = new polygon3D(t, t[0], t[1], t[3], main.textures[24], 1,1, 2); 
			polygons[index].diffuse_I=10;
			index++;
			
			t = new vector[]{put(r2*Math.cos(i*theta), -0.04, r2*Math.sin(i*theta)),
					 put(r2*Math.cos((i+1)*theta), -0.04, r2*Math.sin((i+1)*theta)),
					 put(r2*Math.cos((i+1)*theta), -0.045, r2*Math.sin((i+1)*theta)),
					 put(r2*Math.cos(i*theta), -0.045, r2*Math.sin(i*theta))
					};
			polygons[index] = new polygon3D(t, t[0], t[1], t[3], main.textures[25], 1,0.5f, 3); 
			polygons[index].diffuse_I+=10;
			index++;
			
			t = new vector[]{put(r2*Math.cos(i*theta), -0.045, r2*Math.sin(i*theta)), 
							 put(r2*Math.cos((i+1)*theta), -0.045, r2*Math.sin((i+1)*theta)),
							 put(r3*Math.cos((i+1)*theta), -0.045, r3*Math.sin((i+1)*theta)),
							 put(r3*Math.cos(i*theta), -0.045, r3*Math.sin(i*theta)), 
			};
			polygons[index] = new polygon3D(t, t[0], t[1], t[3], main.textures[25], 1,0.5f, 3); 
			polygons[index].diffuse_I+=10;
			index++;
			
		}
	}
	
	public void drawReflection(){}
}
