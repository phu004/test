package core;
//this is the class for storing geometry information of a 3D model
public abstract class solidObject implements model{
	
	//reference point of the model (in world coordinate)
	public vector start;
	
	//the reference axis of the model  (in world coordinate)
	public vector iDirection, jDirection, kDirection;
	 
	//A rough  boundary of this model, contains 6 polygons
	public polygon3D[] boundary;
	
	//whether this model need to be sent to drawing pipeline
	public boolean visible;
	
	//the 3D polygons of the model
	public polygon3D[] polygons;
	
	//the reflection of the model
	public polygon3D[] reflection;
	
	//the centre of the model in world coordinate
	public vector centre;
	
	//the centre of the model in camera coordinate
	public vector tempCentre = new vector(0,0,0);
	
	
	//get a rough 3D boundary of the model in camera coordinate
	public  polygon3D[] getBoundary(){
		return boundary;
	}
	
	//a flag which indicates if the polygons need to be sorted
	public boolean sortedPolygons = true;
	public int sortIndexStart;

	//get centre of this model in camera coordinate
	public  vector getCentre(){
		return tempCentre;
	}
	
	//return centre in world coordinate
	public  vector getRealCentre(){
		return centre;
	}

	//return visibility
	public boolean getVisibility(){
		return visible;
	}
	
	//Create a rough 3D cuboid boundary for this model.
	public void makeBoundary(float l, float h, float w){
		boundary = new polygon3D[6];
		vector[] front = new vector[]{put(l, h, w), put(-l, h, w), put(-l, -h, w), put(l, -h, w)};
		boundary[0] = new polygon3D(front, null, null, null, null, 0,0,0);
		vector[] right = new vector[]{put(l, h, -w), put(l, h, w), put(l, -h, w), put(l, -h, -w)};
		boundary[1] = new polygon3D(right, null, null, null, null, 0,0,0);
		vector[] back = new vector[]{put(-l, h, -w), put(l, h, -w), put(l, -h, -w), put(-l, -h, -w)};
		boundary[2] = new polygon3D(back, null, null, null, null, 0,0,0);
		vector[] left = new vector[]{put(-l, h, w), put(-l, h, -w), put(-l, -h, -w), put(-l, -h, w)};
		boundary[3] = new polygon3D(left, null, null, null, null, 0,0,0);
		vector[] top = new vector[]{put(-l, h, w), put(l, h, w), put(l, h, -w), put(-l, h, -w)};
		boundary[4] = new polygon3D(top, null, null, null, null, 0,0,0);
		vector[] buttom = new vector[]{put(-l, -h, -w), put(l, -h, -w), put(l, -h, w), put(-l, -h, w)};
		boundary[5] = new polygon3D(buttom, null, null, null, null, 0,0,0);
	}

	//if all the boundary polygons are not visible, and the view point is not inside the model,
	//the model will not be drawn
	public  boolean testVisibility(){
		boolean inside = true;
		vector origin = new vector(0,0,0);

		for(int i = 0; i < 6; i++){
			if(boundary[i].visible)
				return true;
			origin.reset();
			origin.subtract(boundary[i].centre);
			if(origin.dot(boundary[i].normal) > 0){
				inside = false;
			}
		}
		return inside;
	}
	
	//update the 3D model
	public void update(){
		
		
		//update boundary for this model
		for(int i = 0; i < boundary.length; i++){
			//update center in camera coordinate
			boundary[i].centre.set(boundary[i].realCentre);
			boundary[i].centre.subtract(camera.position);
			boundary[i].centre.rotate_XZ(camera.XZ_angle);
			boundary[i].centre.rotate_YZ(camera.YZ_angle);
		
			boundary[i].normal.set(boundary[i].realNormal);
			boundary[i].normal.rotate_XZ(camera.XZ_angle);
			boundary[i].normal.rotate_YZ(camera.YZ_angle);
			
			boundary[i].update();
		}
		
		//test if the model is visible, 
		visible = testVisibility();
		
		if(!visible)
			return;
		
	
	
		
		//update center in camera coordinate
		tempCentre.set(centre);
		tempCentre.subtract(camera.position);
		tempCentre.rotate_XZ(camera.XZ_angle);
		tempCentre.rotate_YZ(camera.YZ_angle);
		tempCentre.updateLocation();
		
		//update polygons
		for(int i = 0; i < polygons.length; i++){
			polygons[i].update();
		}
		
		//sort polygons 
		if(!sortedPolygons && ((main.timer <= 1) || camera.updating)){
			int length = polygons.length;// - backGroundModelCount;
			for(int i = 1; i < length; i++){
				for(int j = sortIndexStart; j <length - i; j++){
					if(geometry.comparePolygons(polygons[j], polygons[j+1])){
						polygon3D temp = polygons[j+1];
						polygons[j+1] = polygons[j];
						polygons[j] = temp;
					}
				}
			}
		}
		
		
		
		
		
	}
	
	//draw  the model
	public void draw(){
		
		if(visible){
			for(int i = 0; i < polygons.length; i++){
				polygons[i].draw();
			}
		}
	}
	
	//the centre of the model is calculated by averaging the centres
	//of the first 4 polygons from the boundary
	public final void findCentre(){
		centre = new vector(0,0,0);
		for(int i = 0; i < 4; i++)
			centre.add(boundary[i].centre);
		centre.scale(1.0f/4);
		tempCentre.set(centre);
	}
	
	//create a arbitrary vertex
	public  vector put(double i, double j, double k){
		vector temp = start.myClone();
		temp.add(iDirection, (float)i);
		temp.add(jDirection, (float)j);
		temp.add(kDirection, (float)k);
		return temp;
	}
	
	//change the 3d geometry of a vertex
	public final void change(float i, float j, float k, vector v){
		v.set(start);
		v.add(iDirection, i);
		v.add(jDirection, j);
		v.add(kDirection, k);
	}	
	

}
