package core;
//3d model: window on the side of main hall
public class window_north extends solidObject{
	
	public int glassIndex;   
	
	public window_north(vector centre, int glassIndex){
		//centre point of the model (in world coordinate)
		start = centre.myClone();
		this.centre = start.myClone();
		tempCentre = start.myClone();
		this.glassIndex = glassIndex;
		
		//define reference axis (in world coordinate)
		iDirection = new vector(1,0,0);
		jDirection = new vector(0,1,0);
		kDirection = new vector(0,0,1.1538461f);
		
		//change orientation
		iDirection.rotate_XZ(270);
		kDirection.rotate_XZ(270);
		
		
		//create a rough 3D cuboid boundary for this model.
		makeBoundary(0.09f, 0.35f, 0.099f);
		
		//create polygons
		makePolygons();
	}
	
	//all the polygon vertices  are hard coded here
	public void makePolygons(){
		polygons = new polygon3D[15];
		vector[] t;
		
		int index = 0;
		
		t = new vector[]{put(0.06, -0.05, -0.065), put(0.06, -0.05, 0.065), put(0.06, -0.35, 0.065),  put(0.06, -0.35, -0.065)};
		polygons[index] = new polygon3D(t, t[0], t[1], t[3], main.textures[16], 1f,1f, 4); 
		polygons[index].diffuse_I = 10;
		
		index++;
		
		t = new vector[]{put(0.06, 0.05,-0.065), put(0.06, 0.05,0.065),put(0.06, -0.05,0.065), put(0.06, -0.05,-0.065)};
		polygons[index] = new polygon3D(t, put(0.06, 0.04,-0.065), put(0.06, 0.04,0.065), put(0.06, -0.07,-0.065), main.textures[18], 1,1.2f, 4);
		polygons[index].diffuse_I = 10;
		index++;
		
		t = new vector[]{put(0.06, -0.35, 0.065), put(0.1, -0.35, 0.065), put(0.1, -0.35, -0.065), put(0.06, -0.35, -0.065)};
		polygons[index] = new polygon3D(t, t[1], t[0], t[2], main.textures[7], 0.3f,1f, 6); 
		polygons[index].diffuse_I = 53;
		
		index++;
		
		t = new vector[]{put(0.06, -0.05, 0.065), put(0.1, -0.05, 0.065), put(0.1, -0.35, 0.065), put(0.06, -0.35, 0.065)};
		polygons[index] = new polygon3D(t, t[1], t[0], t[2], main.textures[7], 0.2f,2f, 6); 
		polygons[index].diffuse_I = 50;
		
		index++;
		
		t = new vector[]{put(0.06, -0.35, -0.065), put(0.1, -0.35, -0.065), put(0.1, -0.05, -0.065), put(0.06, -0.05, -0.065)};
		polygons[index] = new polygon3D(t, t[1], t[0], t[2], main.textures[7], 0.2f,2f, 6); 
		polygons[index].diffuse_I = 50;
		
		index++;
		
		float[] heights = new float[]{0.f, 0.04f, 0.06f, 0.075f, 0.088f, 0.093f, 0.088f, 0.075f, 0.06f, 0.04f, 0.f};
		for(int i = 0; i < heights.length; i++)
			heights[i]-=0.05;
		
		for(int i = 0; i < 10; i ++){
			t = new vector[]{put(0.1, heights[i+1], -0.065+ 0.013*(i+1)), put(0.06, heights[i+1], -0.065+ 0.013*(i+1)), put(0.06, heights[i], -0.065+ 0.013*(i)), put(0.1, heights[i], -0.065+ 0.013*(i))};
			polygons[index] = new polygon3D(t, t[0], t[1], t[3], main.textures[7], 0.2f,0.2f, 6); 
			if(i == 0 || i == 9)
				polygons[index].diffuse_I = 45;
			if(i == 1 || i == 8)
				polygons[index].diffuse_I = 43;
			if(i == 2 || i == 7)
				polygons[index].diffuse_I = 41;
			if(i == 3 || i == 6)
				polygons[index].diffuse_I = 39;
			if(i == 4 || i == 5)
				polygons[index].diffuse_I = 37;
			index++;
		}
		
		for(int i = 0; i < polygons.length; i++){
			if(polygons[i].type == 6){
				polygons[i].diffuse_I -=25;
			}
		}
		
		
	}
	
	public void drawReflection(){}

}
