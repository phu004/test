package core;
//3D Java church  

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.awt.image.*;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class main extends JFrame implements KeyListener, ActionListener{
	
	private static final long serialVersionUID = 1L;
	public Ticker t;
	public int sleepTime;
	public static int[] screen;
	public static texture[] textures;
	public static int[] stencilBuffer;
	public static int[] reflectionBuffer;
	public static BufferedImage doubleBuffer;
	
	
	public static int timer;
	public static long lastTime;
	public static long tm;
	public static int polyCount;
	public static JPanel panel;
	
	public camera Camera;
	public skybox Skybox;
	public floorReflection reflection;
	
	public static int screen_w = 1024;
	public static int screen_h = 682;
	public static int half_screen_w = screen_w/2;
	public static int half_screen_h = screen_h/2;
	public static int screen_pixel_count = screen_w * screen_h;
	
	
	
	public static void main(String[] args){
		new main();
	}
	
	
	public main(){
		setTitle("Church Demo");
		panel= (JPanel) this.getContentPane();
		panel.setPreferredSize(new Dimension(screen_w, screen_h));
		panel.setMinimumSize(new Dimension(screen_w,screen_h));
		panel.setLayout(null);     
		
		setResizable(false); 
		pack();
		setVisible(true);
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		screen = null;
		System.gc();
		

		
		//create an array of int which holds screen pixels data
		doubleBuffer =  new BufferedImage(screen_w, screen_h, BufferedImage.TYPE_INT_RGB);
		DataBuffer dest = doubleBuffer.getRaster().getDataBuffer();
		screen = ((DataBufferInt)dest).getData();
		

		//create an array which will  hold a proportion of the screen buffer
		stencilBuffer = new int[screen_w*screen_h];
		
		//create an  array of short which will hole pixels from reflected objects
		reflectionBuffer = new int[screen_w*screen_h];
		
		
		//Initialise light sources
		lightSources.init();
		
		//Create look up tables
		gameData.makeData();
	
		//Load textures
		String imageFolder = "../images/";
		if(textures == null){
			textures = new texture[31];
			try {
			//skybox 
			textures[0] = new texture(ImageIO.read(getClass().getResource(imageFolder + "sky1.jpg")), 9, 9, "skybox");
			textures[1] = new texture(ImageIO.read(getClass().getResource(imageFolder + "sky2.jpg")), 9, 9, "skybox");
			textures[2] = new texture(ImageIO.read(getClass().getResource(imageFolder + "sky3.jpg")), 9, 9, "skybox");
			textures[3] = new texture(ImageIO.read(getClass().getResource(imageFolder + "sky4.jpg")), 9, 9, "skybox");
			textures[4] = new texture(ImageIO.read(getClass().getResource(imageFolder + "sky5.jpg")), 9, 9, "skybox");
			textures[5] = new texture(ImageIO.read(getClass().getResource(imageFolder + "sky6.jpg")), 9, 9, "skybox");
			
			//floor texture
			textures[6] = new texture(ImageIO.read(getClass().getResource(imageFolder + "1.jpg")), 8,8, "normal");
			
			
			//west wall and its bump map
			textures[7] = new texture(8, ImageIO.read(getClass().getResource(imageFolder + "2.jpg")), 8, 8, "mipmap");
			
			//stained glass textures for side windows
			textures[8] = new texture(ImageIO.read(getClass().getResource(imageFolder + "3.jpg")), ImageIO.read(getClass().getResource(imageFolder + "distortion3.jpg")), 8, 9, 4,"distortion");
			textures[9] = new texture(ImageIO.read(getClass().getResource(imageFolder + "4.jpg")), ImageIO.read(getClass().getResource(imageFolder + "distortion4.jpg")), 8, 9, 4,"distortion");
			textures[10] = new texture(ImageIO.read(getClass().getResource(imageFolder + "5.jpg")), ImageIO.read(getClass().getResource(imageFolder + "distortion5.jpg")), 8, 9, 4, "distortion");
			textures[11] = new texture(ImageIO.read(getClass().getResource(imageFolder + "6.jpg")), ImageIO.read(getClass().getResource(imageFolder + "distortion6.jpg")), 8, 9, 4, "distortion");
			textures[12] = new texture(ImageIO.read(getClass().getResource(imageFolder + "7.jpg")), ImageIO.read(getClass().getResource(imageFolder + "distortion7.jpg")), 8, 9, 4, "distortion");
			textures[13] = new texture(ImageIO.read(getClass().getResource(imageFolder + "8.jpg")), ImageIO.read(getClass().getResource(imageFolder + "distortion8.jpg")), 8, 9, 4, "distortion");
	
			//glass texture for side windows
			textures[30] = new texture(new int[]{0xcc6437, 0xc6437, 0xcc6437, 0xcc6437}, 1,1, "customized");
			
			
			//stained glass textures for front windows
			textures[16] = new texture(ImageIO.read(getClass().getResource(imageFolder + "10.jpg")), ImageIO.read(getClass().getResource(imageFolder + "distortion10.jpg")), 8, 9, 3, "distortion");
			
			//textures[17] = new texture(getImage(getDocumentBase(), imageFolder + "9.jpg"), getImage(getDocumentBase(), imageFolder + "distortion9.jpg"), 8, 9, "distortion");
			textures[18] = new texture(ImageIO.read(getClass().getResource(imageFolder + "11.jpg")), ImageIO.read(getClass().getResource(imageFolder + "distortion11.jpg")), 8, 8, 3, "distortion");

			//wood texture for the back door
			textures[19] = new texture(ImageIO.read(getClass().getResource(imageFolder + "12.jpg")), 7, 7, "normal");
			
			//stained glass texture for door
			textures[20] = new texture(ImageIO.read(getClass().getResource(imageFolder + "13.jpg")), ImageIO.read(getClass().getResource(imageFolder + "distortion12.jpg")), 8, 9, 2, "distortion");

			//texture for   door handle
			textures[21] = new texture(ImageIO.read(getClass().getResource(imageFolder + "14.jpg")), 7, 7, "normal");
			
			//ceiling texture	
			textures[22] = new texture(8, ImageIO.read(getClass().getResource(imageFolder + "15.jpg")),  7, 7, "mipmap");
			
			//texture for beams that support the roof
			textures[23] = new texture(ImageIO.read(getClass().getResource(imageFolder + "16.jpg")), 7, 7, "normal");
			
			//chandelier light glass
			textures[24] = new texture(ImageIO.read(getClass().getResource(imageFolder + "17.jpg")), ImageIO.read(getClass().getResource(imageFolder + "distortion17.jpg")), 7, 8, 1, "distortion");

			///chandelier frame 
			textures[25] = new texture(ImageIO.read(getClass().getResource(imageFolder + "18.jpg")), 7, 7, "normal");
			
			//dado texture
			textures[26] = new texture(ImageIO.read(getClass().getResource(imageFolder + "19.jpg")), 8, 4, "normal");
			
			//wood chair texture
			textures[27] = new texture(ImageIO.read(getClass().getResource(imageFolder + "20.jpg")), 8, 8, "normal");
			
			//wood rostrum texture
			textures[28] = new texture(ImageIO.read(getClass().getResource(imageFolder + "21.jpg")), 8, 8, "normal");
			
			//pew texture
			textures[29] = new texture(ImageIO.read(getClass().getResource(imageFolder + "22.jpg")), 9, 9, "normal");
			}catch(Exception e) {}
		
		}
		
		
		//position camera at 0,0,0
		Camera = new camera(new vector(0,0.15f,-0.05f));
		
	
		
		//create skybox 
		Skybox = new skybox();
		reflection = new floorReflection();
		
		//create scene
		sceneGraph.createScene();
		
		//Add key handler
		addKeyListener(this);
		requestFocus();

		//Add ticker
		timer = 0;
		sleepTime = 30;
		tm = System.currentTimeMillis();
		t = new Ticker(sleepTime);
		t.addActionListener(this);
		
		t.start();
		
		System.out.println("Started!");
		System.gc();
		
		//audioClip.loop();

	}
	

	
	//This method is called every time the ticker ticks (game loop)
	public final void actionPerformed(ActionEvent e){	
		
		if(timer ==2)
			requestFocus();
		
		polyCount = 0;
		
		//cap frame rate to around 30
		timer++;
		tm+=sleepTime;	
		long temp = Math.max(0, tm - System.currentTimeMillis());
		if(temp == 0)
			temp = (long)(lastTime*0.5);
		if(temp > 30)
			temp = 30;
		t.setDelay((int)temp);
		lastTime = temp;
		
		//update camera
		camera.update();
		
		//update skyBox
		Skybox.update();
		
		//update reflected objects on the floor surface
		reflection.update();
		
		//update scene graph
		sceneGraph.update();
		
		//draw skybox
		Skybox.draw();
		
		//draw reflection objects on the floor surface
		reflection.draw();
		
		//draw scene
		sceneGraph.draw();
	
		
		//copy the screen buffer to video memory
		if(this.getGraphics() != null)
			paintComponent(panel.getGraphics());
	
	}
	
	public final void paintComponent(Graphics g){		
		
		
		//copy the pixel information to the video memory
		
		g.drawImage(doubleBuffer, 0, 0, this);
	}
	
	
	
	
	//read keyboard inputs
	public final void keyPressed(KeyEvent e){
		if(e.getKeyChar() == 'w' || e.getKeyChar() == 'W')
			camera.MOVE_FORWARD = true;
		else if(e.getKeyChar() == 's' || e.getKeyChar() == 'S')
			camera.MOVE_BACKWARD = true;
		else if(e.getKeyChar() == 'a' || e.getKeyChar() == 'A')
			camera.SLIDE_LEFT = true;
		else if(e.getKeyChar() == 'd' || e.getKeyChar() == 'D')
			camera.SLIDE_RIGHT = true;


		if(e.getKeyCode() == KeyEvent.VK_UP)
			camera.UP_TYPED= true;
		else if(e.getKeyCode() == KeyEvent.VK_DOWN)
			camera.DOWN_TYPED = true;
		else if(e.getKeyCode() == KeyEvent.VK_LEFT)
			camera.LEFT_TYPED = true;
		else if(e.getKeyCode() == KeyEvent.VK_RIGHT)
			camera.RIGHT_TYPED = true;
		
	}
	
	public final void keyReleased(KeyEvent e){
		if(e.getKeyChar() == 'w' || e.getKeyChar() == 'W')
			camera.MOVE_FORWARD = false;
		else if(e.getKeyChar() == 's' || e.getKeyChar() == 'S')
			camera.MOVE_BACKWARD = false;
		else if(e.getKeyChar() == 'a' || e.getKeyChar() == 'A')
			camera.SLIDE_LEFT = false;
		else if(e.getKeyChar() == 'd' || e.getKeyChar() == 'D')
			camera.SLIDE_RIGHT = false;

		if(e.getKeyCode() == KeyEvent.VK_UP)
			camera.UP_TYPED= false;
		else if(e.getKeyCode() == KeyEvent.VK_DOWN)
			camera.DOWN_TYPED = false;
		else if(e.getKeyCode() == KeyEvent.VK_LEFT)
			camera.LEFT_TYPED = false;
		else if(e.getKeyCode() == KeyEvent.VK_RIGHT)
			camera.RIGHT_TYPED = false;

	}
	

	//unused method
	public final void keyTyped(KeyEvent e){}
	public final void update(Graphics g){}
   
  
    
  
}