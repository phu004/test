package core;
//3d model: window on the side of main hall
public class window_side extends solidObject{
	
	public int glassIndex;   
	
	public window_side(vector centre, int glassIndex, int orientation){
		//centre point of the model (in world coordinate)
		start = centre.myClone();
		this.centre = start.myClone();
		tempCentre = start.myClone();
		this.glassIndex = glassIndex;
		
		//define reference axis (in world coordinate)
		iDirection = new vector(1,0,0);
		jDirection = new vector(0,1,0);
		kDirection = new vector(0,0,1);
		
		//change orientation
		iDirection.rotate_XZ(orientation);
		kDirection.rotate_XZ(orientation);
		
		//create a rough 3D cuboid boundary for this model.
		makeBoundary(0.098f, 0.2f, 0.1f);
		
		//create polygons
		makePolygons();
	}
	
	//all the polygon vertices  are hard coded here
	public void makePolygons(){
		polygons = new polygon3D[23];
		vector[] t;
		
		int index = 0;
		
		t = new vector[]{put(0.06, -0.004, -0.048), put(0.06, -0.004, 0.048), put(0.06, -0.2, 0.048),  put(0.06, -0.2, -0.048)};
		polygons[index] = new polygon3D(t, t[0], t[1], t[3], main.textures[glassIndex], 1f,1f, 4); 
		polygons[index].diffuse_I = 15;
		
		index++;
		
		t = new vector[]{put(0.06, 0.05,-0.07), put(0.06, 0.05,0.07),put(0.06, -0.005,0.07), put(0.06, -0.005,-0.07)};
		polygons[index] = new polygon3D(t, t[0], t[1], t[3], null, 1f,1f, 7); 
		polygons[index].color = 0xff6437;
		polygons[index].alpha = 148;
		index++;
		
		t = new vector[]{put(0.06, -0.004, -0.07), put(0.06, -0.004, -0.047),  put(0.06, -0.2, -0.047),  put(0.06, -0.2, -0.07)};
		polygons[index] = new polygon3D(t, t[0], t[1], t[3], null, 1f,1f, 7); 
		polygons[index].color = 0xff6437;
		polygons[index].alpha = 148;
		index++;
		
		t = new vector[]{put(0.06, -0.2, 0.07),  put(0.06, -0.2, 0.047), put(0.06, -0.004, 0.047), put(0.06, -0.004, 0.07) };
		polygons[index] = new polygon3D(t, t[0], t[1], t[3], null, 1f,1f, 7); 
		polygons[index].color = 0xff6437;
		polygons[index].alpha = 148;
		index++;
		
		t = new vector[]{put(0.06,-0.058, -0.065), put(0.06,-0.058, -0.048), put(0.06,-0.06, -0.048), put(0.06,-0.06, -0.065)};
		polygons[index] = new polygon3D(t, t[0], t[1], t[3], main.textures[glassIndex], 0.0001f,0.0001f, 3); 
		
		index++;
		

		t = new vector[]{put(0.06,-0.058, 0.048), put(0.06,-0.058, 0.065), put(0.06,-0.06, 0.065), put(0.06,-0.06, 0.048)};
		polygons[index] = new polygon3D(t, t[0], t[1], t[3], main.textures[glassIndex], 0.0001f,0.0001f, 3); 
		
		index++;
		
		t = new vector[]{put(0.06,-0.101, -0.065), put(0.06,-0.101, -0.048), put(0.06,-0.103, -0.048), put(0.06,-0.103, -0.065)};
		polygons[index] = new polygon3D(t, t[0], t[1], t[3], main.textures[glassIndex], 0.0001f,0.0001f, 3); 
		
		index++;
		

		t = new vector[]{put(0.06,-0.101, 0.048), put(0.06,-0.101, 0.065), put(0.06,-0.103, 0.065), put(0.06,-0.103, 0.048)};
		polygons[index] = new polygon3D(t, t[0], t[1], t[3], main.textures[glassIndex], 0.0001f,0.0001f, 3); 
		
		index++;
		
		t = new vector[]{put(0.06,-0.145, -0.065), put(0.06,-0.145, -0.048), put(0.06,-0.147, -0.048), put(0.06,-0.147, -0.065)};
		polygons[index] = new polygon3D(t, t[0], t[1], t[3], main.textures[glassIndex], 0.0001f,0.0001f, 3); 
		
		index++;
		

		t = new vector[]{put(0.06,-0.145, 0.048), put(0.06,-0.145, 0.065), put(0.06,-0.147, 0.065), put(0.06,-0.147, 0.048)};
		polygons[index] = new polygon3D(t, t[0], t[1], t[3], main.textures[glassIndex], 0.0001f,0.0001f, 3); 
		
		index++;
		
	
		
		
		t = new vector[]{put(0.06, -0.2, 0.065), put(0.1, -0.2, 0.065), put(0.1, -0.2, -0.065), put(0.06, -0.2, -0.065)};
		polygons[index] = new polygon3D(t, t[1], t[0], t[2], main.textures[7], 0.3f,1f, 6); 
		polygons[index].diffuse_I = 53;
		
		index++;
		
		t = new vector[]{put(0.06, -0.05, 0.065), put(0.1, -0.05, 0.065), put(0.1, -0.2, 0.065), put(0.06, -0.2, 0.065)};
		polygons[index] = new polygon3D(t, t[1], t[0], t[2], main.textures[7], 0.2f,1f, 6); 
		polygons[index].diffuse_I = 50;
		
		index++;
		
		t = new vector[]{put(0.06, -0.2, -0.065), put(0.1, -0.2, -0.065), put(0.1, -0.05, -0.065), put(0.06, -0.05, -0.065)};
		polygons[index] = new polygon3D(t, t[1], t[0], t[2], main.textures[7], 0.2f,1f, 6); 
		polygons[index].diffuse_I = 50;
		
		index++;
		
		float[] heights = new float[]{0.f, 0.04f, 0.06f, 0.075f, 0.088f, 0.093f, 0.088f, 0.075f, 0.06f, 0.04f, 0.f};
		for(int i = 0; i < heights.length; i++)
			heights[i]-=0.05;
		
		for(int i = 0; i < 10; i ++){
			t = new vector[]{put(0.1, heights[i+1], -0.065+ 0.013*(i+1)), put(0.06, heights[i+1], -0.065+ 0.013*(i+1)), put(0.06, heights[i], -0.065+ 0.013*(i)), put(0.1, heights[i], -0.065+ 0.013*(i))};
			polygons[index] = new polygon3D(t, t[0], t[1], t[3], main.textures[7], 0.2f,0.2f, 6); 
			if(i == 0 || i == 9)
				polygons[index].diffuse_I = 44;
			if(i == 1 || i == 8)
				polygons[index].diffuse_I = 42;
			if(i == 2 || i == 7)
				polygons[index].diffuse_I = 40;
			if(i == 3 || i == 6)
				polygons[index].diffuse_I = 38;
			if(i == 4 || i == 5)
				polygons[index].diffuse_I = 36;
			index++;
		}
		
		for(int i = 0; i < polygons.length; i++){
			if(polygons[i].type == 6){
				polygons[i].diffuse_I -=25;
			}
		}
	}
	
	public void drawReflection(){
	}

}
