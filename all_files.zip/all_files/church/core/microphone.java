package core;

public class microphone extends solidObject{
	
	public microphone(vector centre){
		//centre point of the model (in world coordinate)
		start = centre.myClone();
		this.centre = start.myClone();
		tempCentre = start.myClone();
		
		//define reference axis (in world coordinate)
		iDirection = new vector(1f,0,0);
		jDirection = new vector(0,1,0);
		kDirection = new vector(0,0,1f);
		
		//create a rough 3D cuboid boundary for this model.
		makeBoundary(0.03f, 0.0299f, 0.03f);
		
		//create polygons
		makePolygons();
	}
	
	public void makePolygons(){
		polygons = new polygon3D[131];
		vector[] t;
		
		
		
		double r1 = 0.0005;
		double r2 = 0.004;
		
		double theta = Math.PI/16;
		
		for(int i = 0; i < 32; i++){
			t = new vector[]{put(r1*Math.cos(i*theta), -0.029, r1*Math.sin(i*theta)),
							 put(r1*Math.cos((i+1)*theta), -0.029, r1*Math.sin((i+1)*theta)),
							 put(r2*Math.cos((i+1)*theta), -0.03, r2*Math.sin((i+1)*theta)),
							 put(r2*Math.cos(i*theta), -0.03, r2*Math.sin(i*theta)),
							};
			
			for(int j = 0; j < t.length; j++)
				t[j].add(-0.025f, 0, -0.01f);
			
			polygons[i] = new polygon3D(t, t[0], t[1], t[3], null, 1f, 1f, 7);
			polygons[i].color = 0x444444;
			
		}
		
		for(int i = 0; i < 32; i++){
			t = new vector[]{put(r1*Math.cos(i*theta), 0, r1*Math.sin(i*theta)),
							 put(r1*Math.cos((i+1)*theta), 0, r1*Math.sin((i+1)*theta)),
							 put(r1*Math.cos((i+1)*theta), -0.029, r1*Math.sin((i+1)*theta)),
							 put(r1*Math.cos(i*theta), -0.029, r1*Math.sin(i*theta)),
							};
			
			for(int j = 0; j < t.length; j++)
				t[j].add(-0.025f, 0, -0.01f);
			
			polygons[i + 32] = new polygon3D(t, t[0], t[1], t[3], null, 1f, 1f, 7);
			polygons[i + 32].color = 0x444444;
			
		}
		
		kDirection.rotate_YZ(290);
		jDirection.rotate_YZ(290);
		
		iDirection.rotate_XZ(155);
		jDirection.rotate_XZ(155);
		kDirection.rotate_XZ(155);
		
		for(int i = 0; i < 32; i++){
			t = new vector[]{put(r1*Math.cos(i*theta), 0, r1*Math.sin(i*theta)),
							 put(r1*Math.cos((i+1)*theta), 0, r1*Math.sin((i+1)*theta)),
							 put(r1*Math.cos((i+1)*theta), -0.039, r1*Math.sin((i+1)*theta)),
							 put(r1*Math.cos(i*theta), -0.039, r1*Math.sin(i*theta)),
							};
			
			for(int j = 0; j < t.length; j++)
				t[j].add(-0.0158f, 0.0085f, 0.01f);
			
			polygons[i + 64] = new polygon3D(t, t[0], t[1], t[3], null, 1f, 1f, 7);
			polygons[i + 64].color = 0x444444;
			
		}
		
		t = new vector[32];
		for(int i = 1; i < 33; i++){
			t[i-1] = put(r1*Math.cos(i*theta), -0.039, r1*Math.sin(i*theta));
			t[i-1].add(-0.0158f, 0.0085f, 0.01f);
		}
		polygons[96] = new polygon3D(t, t[0], t[1], t[3], null, 1f, 1f, 7);
		polygons[96].color = 0x444444;
		
		double r3 = 0.001;
		for(int i = 0; i < 32; i++){
			t = new vector[]{put(r3*Math.cos(i*theta), 0.005, r3*Math.sin(i*theta)),
							 put(r3*Math.cos((i+1)*theta), 0.005, r3*Math.sin((i+1)*theta)),
							 put(r3*Math.cos((i+1)*theta), 0, r3*Math.sin((i+1)*theta)),
							 put(r3*Math.cos(i*theta), 0, r3*Math.sin(i*theta)),
							};
			
			for(int j = 0; j < t.length; j++)
				t[j].add(-0.0158f, 0.0085f, 0.01f);
			
			polygons[i + 97] = new polygon3D(t, t[0], t[1], t[3], null, 1f, 1f, 7);
			polygons[i + 97].color = 0x222222;
			
		}
		
		t = new vector[32];
		for(int i = 1; i < 33; i++){
			t[i-1] = put(r3*Math.cos(i*theta), 0, r3*Math.sin(i*theta));
			t[i-1].add(-0.0158f, 0.0085f, 0.01f);
		}
		polygons[129] = new polygon3D(t, t[0], t[1], t[3], null, 1f, 1f, 7);
		polygons[129].color = 0x222222;
		
		t = new vector[32];
		for(int i = 1; i < 33; i++){
			t[32 - i] = put(r3*Math.cos(i*theta), 0.005, r3*Math.sin(i*theta));
			t[32 - i].add(-0.0158f, 0.0085f, 0.01f);
		}
		polygons[130] = new polygon3D(t, t[0], t[1], t[3], null, 1f, 1f, 7);
		polygons[130].color = 0x222222;
		
		
		sortedPolygons = false;
		
		
	
	}
	
	public void drawReflection(){}
	
	

}
