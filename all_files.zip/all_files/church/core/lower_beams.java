package core;
//3d model: lower part of beams
public class lower_beams extends solidObject{
	public int type;
	
	public lower_beams(vector centre, int type){
		//centre point of the model (in world coordinate)
		start = centre.myClone();
		this.centre = start.myClone();
		tempCentre = start.myClone();
		
		//define reference axis (in world coordinate)
		iDirection = new vector(1,0,0);
		jDirection = new vector(0,1,0);
		kDirection = new vector(0,0,1);
		
		//create a rough 3D cuboid boundary for this model.
		makeBoundary(0.02f, 0.05f, 0.01f);
		
		this.type = type;
	
		makePolygons();
		
	}
	
	//all the polygon vertices  are hard coded here
	public void makePolygons(){
		polygons = new polygon3D[3];
		vector[] t;
		
		if(type == 0){
			t = new vector[]{put(-0.02, 0.05, -0.01), put(0.02, 0.05, -0.01), put(-0.02, -0.05, -0.01)};
			polygons[0] = new polygon3D(t, put(-0.02, -0.05, -0.01), put(-0.02, 0.05, -0.01), put(0.02, -0.05, -0.01), main.textures[23], 2,1, 3); 
			polygons[0].diffuse_I = 40;
		
			t = new vector[]{put(-0.02, -0.05, 0.01), put(0.02, 0.05, 0.01), put(-0.02, 0.05, 0.01)};
			polygons[1] = new polygon3D(t, put(-0.02, -0.05, 0.01), put(-0.02, 0.05, 0.01), put(0.02, -0.05, 0.01), main.textures[23], 2,1, 3); 
			polygons[1].diffuse_I = 63;
			
			t = new vector[]{put(0.02, 0.05, -0.01), put(0.02, 0.05, 0.01),  put(-0.02, -0.05, 0.01), put(-0.02, -0.05, -0.01)};
			polygons[2] = new polygon3D(t, t[1], t[2], t[0], main.textures[23], 2,1, 3); 
			polygons[2].diffuse_I = 60;	
		}
		if(type ==1){
			t = new vector[]{put(-0.021, 0.052, -0.01), put(0.02, 0.05, -0.01), put(0.02, -0.05, -0.01)};
			polygons[0] = new polygon3D(t, put(-0.02, -0.05, -0.01), put(-0.02, 0.05, -0.01), put(0.02, -0.05, -0.01), main.textures[23], 2,1, 3); 
			polygons[0].diffuse_I = 40;
			
			t = new vector[]{put(0.02, -0.05, 0.01), put(0.02, 0.05, 0.01), put(-0.021, 0.052, 0.01)};
			polygons[1] = new polygon3D(t, put(-0.02, -0.05, 0.01), put(-0.02, 0.05, 0.01), put(0.02, -0.05, 0.01), main.textures[23], 2,1, 3); 
			polygons[1].diffuse_I = 63;
			
			t = new vector[]{put(0.02, -0.05, -0.01),put(0.02, -0.05, 0.01), put(-0.021, 0.052, 0.01), put(-0.021, 0.052, -0.01) };
			polygons[2] = new polygon3D(t, t[1], t[2], t[0], main.textures[23], 2,1, 3); 
			polygons[2].diffuse_I = 60;	
			
			
		}
		
		 for(int i = 0; i < polygons.length; i++){
				if(polygons[i].diffuse_I > 5)
					polygons[i].diffuse_I-=10;
			 }
	}
	
	public void drawReflection(){}
	
}
