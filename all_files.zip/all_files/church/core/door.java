package core;
//3d model: door in the wall to the back of the main hall
public class door extends solidObject{
	
	public door(vector centre){
		//centre point of the model (in world coordinate)
		start = centre.myClone();
		this.centre = start.myClone();
		tempCentre = start.myClone();
		
		
		//define reference axis (in world coordinate)
		iDirection = new vector(1,0,0);
		jDirection = new vector(0,1,0);
		kDirection = new vector(0,0,1);
		
		//create a rough 3D cuboid boundary for this model.
		makeBoundary(0.1f, 0.125f, 0.098f);
		
		//create polygons
		makePolygons();
	}
	
	//all the polygon vertices  are hard coded here
	public void makePolygons(){
		polygons = new polygon3D[58];
		vector[] t;
		
		t = new vector[]{put(0.1, 0.125, 0.1), put(0.1, 0.125, 0.085), put(0.1, -0.125, 0.085), put(0.1, -0.125, 0.1)};
		polygons[4] = new polygon3D(t, put(0.1, 0.175, 0.1), put(0.1, 0.175, 0.085), put(0.1, -0.075, 0.1), main.textures[7], 0.1f,1.41f, 6); 
		polygons[4].diffuse_I = 40;
		
		t = new vector[]{put(-0.1, -0.125, 0.1), put(-0.1, -0.125, 0.085), put(-0.1, 0.125, 0.085), put(-0.1, 0.125, 0.1)};
		polygons[13] = new polygon3D(t, put(-0.1, 0.175, 0.095), put(-0.1, 0.175, 0.085), put(-0.1, -0.075, 0.095), main.textures[7], 0.09f,1.41f, 6); 
		polygons[13].diffuse_I = 40;
		
		t = new vector[]{put(0.1, 0.125, 0.1), put(-0.1, 0.125, 0.1), put(-0.1, 0.125, 0.085), put(0.1, 0.125, 0.085)};
		polygons[2] = new polygon3D(t, t[0], t[1], t[3], main.textures[7], 1.3f,0.1f, 6); 
		polygons[2].diffuse_I = 35;
		
		t = new vector[]{put(0.1, -0.125, 0.085), put(-0.1, -0.125, 0.085), put(-0.1, -0.125, 0.101), put(0.1, -0.125, 0.101)};
		polygons[3] = new polygon3D(t, put(-0.4, -0.125, 0.6), put(0.4,-0.125, 0.6), put(-0.4, -0.125, -0.6), main.textures[6], 6f,9f, 5); 
		polygons[3].diffuse_I = 20;
		
		start.add(0, 0,-0.015f);
		
		t = new vector[]{put(0.0851, 0.11, 0.095), put(0.0149, 0.11, 0.095), put(0.0149, -0.05, 0.095), put(0.0851, -0.05, 0.095)};
		polygons[0] = new polygon3D(t, t[0], t[1], t[3], main.textures[20], 1f,1f, 4); 
		polygons[0].diffuse_I = 4;
		
		t = new vector[]{put(0.085, -0.05, 0.095), put(0.015, -0.05, 0.095), put(0.015, -0.05, 0.101), put(0.085, -0.05, 0.101)};
		polygons[5] = new polygon3D(t, t[0], t[1], t[3], main.textures[19], 4f,1f, 3); 
		polygons[5].diffuse_I = 40;
		
		t = new vector[]{put(0.085, 0.11, 0.101), put(0.085, 0.11, 0.095), put(0.085, -0.05, 0.095), put(0.085, -0.05, 0.101)};
		polygons[6] = new polygon3D(t, t[0], t[1], t[3], main.textures[19], 0.2f,6f, 3); 
		polygons[6].diffuse_I = 35;
		
		t = new vector[]{put(0.015, 0.11, 0.095), put(0.015, 0.11, 0.101), put(0.015, -0.05, 0.101), put(0.015, -0.05, 0.095)};
		polygons[7] = new polygon3D(t, t[0], t[1], t[3], main.textures[19], 0.2f,6f, 3); 
		polygons[7].diffuse_I = 35;
		
		t = new vector[]{put(0.085, 0.11, 0.101), put(0.015, 0.11, 0.101), put(0.015, 0.11, 0.095), put(0.085, 0.11, 0.095)};
		polygons[8] = new polygon3D(t, t[0], t[1], t[3], main.textures[19], 4f,1f, 3); 
		polygons[8].diffuse_I = 30;
		
		t = new vector[]{put(0.101, 0.126, 0.1), put(0.085, 0.126, 0.1), put(0.085, -0.126, 0.1), put(0.101, -0.126,0.1)};
		polygons[9] = new polygon3D(t, t[0], t[1], t[3], main.textures[19], 1f,10f, 3); 
		polygons[9].diffuse_I = 20;
		
		t = new vector[]{put(0.015, 0.126, 0.1), put(0, 0.126, 0.1), put(0, -0.126, 0.1), put(0.015, -0.126,0.1)};
		polygons[10] = new polygon3D(t, t[0], t[1], t[3], main.textures[19], 1f,10f, 3); 
		polygons[10].diffuse_I = 20;
		
		t = new vector[]{put(0.086, 0.126, 0.1), put(0.014, 0.126, 0.1), put(0.014, 0.11, 0.1), put(0.086, 0.11, 0.1)};
		polygons[11] = new polygon3D(t, t[0], t[1], t[3], main.textures[19], 5f,1f, 3); 
		polygons[11].diffuse_I = 20;
		
		t = new vector[]{put(0.086, -0.05, 0.1), put(0.014, -0.05, 0.1), put(0.014, -0.126, 0.1), put(0.086, -0.126, 0.1)};
		polygons[12] = new polygon3D(t, t[0], t[1], t[3], main.textures[19], 4f,3f, 3); 
		polygons[12].diffuse_I = 20;
		
		start.add(-0.1f, 0,0);
		
		t = new vector[]{put(0.085, 0.11, 0.095), put(0.015, 0.11, 0.095), put(0.015, -0.05, 0.095), put(0.085, -0.05, 0.095)};
		polygons[1] = new polygon3D(t, t[0], t[1], t[3], main.textures[20], 1f,1f, 4); 
		polygons[1].diffuse_I = 4;
		
		t = new vector[]{put(0.085, -0.05, 0.095), put(0.015, -0.05, 0.095), put(0.015, -0.05, 0.101), put(0.085, -0.05, 0.101)};
		polygons[14] = new polygon3D(t, t[0], t[1], t[3], main.textures[19], 4f,1f, 3); 
		polygons[14].diffuse_I = 40;
		
		t = new vector[]{put(0.085, 0.11, 0.101), put(0.085, 0.11, 0.095), put(0.085, -0.05, 0.095), put(0.085, -0.05, 0.101)};
		polygons[15] = new polygon3D(t, t[0], t[1], t[3], main.textures[19], 0.2f,6f, 3); 
		polygons[15].diffuse_I = 35;
		
		t = new vector[]{put(0.015, 0.11, 0.095), put(0.015, 0.11, 0.101), put(0.015, -0.05, 0.101), put(0.015, -0.05, 0.095)};
		polygons[16] = new polygon3D(t, t[0], t[1], t[3], main.textures[19], 0.2f,6f, 3); 
		polygons[16].diffuse_I = 35;
		
		t = new vector[]{put(0.085, 0.11, 0.101), put(0.015, 0.11, 0.101), put(0.015, 0.11, 0.095), put(0.085, 0.11, 0.095)};
		polygons[17] = new polygon3D(t, t[0], t[1], t[3], main.textures[19], 4f,1f, 3); 
		polygons[17].diffuse_I = 30;
		
		t = new vector[]{put(0.101, 0.126, 0.1), put(0.085, 0.126, 0.1), put(0.085, -0.126, 0.1), put(0.101, -0.126,0.1)};
		polygons[18] = new polygon3D(t, t[0], t[1], t[3], main.textures[19], 1f,10f, 3); 
		polygons[18].diffuse_I = 20;
		
		t = new vector[]{put(0.015, 0.126, 0.1), put(0, 0.126, 0.1), put(0, -0.126, 0.1), put(0.015, -0.126,0.1)};
		polygons[19] = new polygon3D(t, t[0], t[1], t[3], main.textures[19], 1f,10f, 3); 
		polygons[19].diffuse_I = 20;
		
		t = new vector[]{put(0.086, 0.126, 0.1), put(0.014, 0.126, 0.1), put(0.014, 0.11, 0.1), put(0.086, 0.11, 0.1)};
		polygons[20] = new polygon3D(t, t[0], t[1], t[3], main.textures[19], 5f,1f, 3); 
		polygons[20].diffuse_I = 20;
		
		t = new vector[]{put(0.086, -0.05, 0.1), put(0.014, -0.05, 0.1), put(0.014, -0.126, 0.1), put(0.086, -0.126, 0.1)};
		polygons[21] = new polygon3D(t, t[0], t[1], t[3], main.textures[19], 4f,3f, 3); 
		polygons[21].diffuse_I = 20;
		
		
		start.add(0, 0.01f,0.0002f);
		start.add(0.102f, 0,0);
		
		t = new vector[]{put(0.01, 0.015, 0.1011), put(0.004, 0.015, 0.1011), put(0.004, 0.015, 0.105), put(0.01, 0.015, 0.105)};
		polygons[22] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[22].diffuse_I = 20;
		
		t = new vector[]{put(0.01, 0.015, 0.1011), put(0.01, 0.015, 0.105), put(0.01, 0.012, 0.105), put(0.01, 0.012, 0.1011)};
		polygons[23] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[23].diffuse_I = 18;
		
		t = new vector[]{put(0.004, 0.015, 0.105), put(0.004, 0.015, 0.1011), put(0.004, 0.012, 0.1011), put(0.004, 0.012, 0.105)};
		polygons[24] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[24].diffuse_I = 18;
		
		t = new vector[]{put(0.01, 0.012, 0.105), put(0.004, 0.012, 0.105), put(0.004, 0.012, 0.1011), put(0.01, 0.012, 0.1011)};
		polygons[25] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[25].diffuse_I = 16;
		
		start.add(0, -0.04f,0);
		
		t = new vector[]{put(0.01, 0.015, 0.1011), put(0.004, 0.015, 0.1011), put(0.004, 0.015, 0.105), put(0.01, 0.015, 0.105)};
		polygons[26] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[26].diffuse_I = 20;
		
		t = new vector[]{put(0.01, 0.015, 0.1011), put(0.01, 0.015, 0.105), put(0.01, 0.012, 0.105), put(0.01, 0.012, 0.1011)};
		polygons[27] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[27].diffuse_I = 18;
		
		t = new vector[]{put(0.004, 0.015, 0.105), put(0.004, 0.015, 0.1011), put(0.004, 0.012, 0.1011), put(0.004, 0.012, 0.105)};
		polygons[28] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[28].diffuse_I = 18;
		
		t = new vector[]{put(0.01, 0.012, 0.105), put(0.004, 0.012, 0.105), put(0.004, 0.012, 0.1011), put(0.01, 0.012, 0.1011)};
		polygons[29] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[29].diffuse_I = 16;
		
		start.add(0, 0.04f,0);
		
		double z = 0.107;
		double z2 = 0.105;
		double y1 = 0.025;
		double y2 = 0.017;
		double y3 = -0.029;
		double y4 = -0.037;
		double x1 = 0.01;
		double x2 = 0.009;
		double x3 = 0.005;
		double x4 = 0.004;
		t = new vector[]{put(x2, y1, z), put(x3, y1, z), put(x4, y2, z), put(x4, y3, z), put(x3, y4, z), put(x2, y4,z), put(x1, y3,z), put(x1,y2,z)};
		polygons[30] = new polygon3D(t, t[0], t[1], t[5], main.textures[21], 1f,1f, 3); 
		polygons[30].diffuse_I = 20;
		
		t = new vector[]{put(x1,y2,z2), put(x1, y3,z2), put(x2, y4,z2), put(x3, y4, z2), put(x4, y3, z2), put(x4, y2, z2), put(x3, y1, z2), put(x2, y1, z2)};
		polygons[31] = new polygon3D(t, t[0], t[1], t[5], main.textures[21], 1f,1f, 3); 
		polygons[31].diffuse_I = 20;
		
		t = new vector[]{ put(x3, y1, z), put(x2, y1, z), put(x2, y1, z2), put(x3, y1, z2)};
		polygons[32] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[32].diffuse_I = 16;
		
		t = new vector[]{ put(x4, y2, z), put(x3, y1, z), put(x3, y1, z2), put(x4, y2, z2)};
		polygons[33] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[33].diffuse_I = 16;
		
		t = new vector[]{ put(x4, y3, z), put(x4, y2, z), put(x4, y2, z2), put(x4, y3, z2)};
		polygons[34] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[34].diffuse_I = 14;
		
		t = new vector[]{ put(x3, y4, z), put(x4, y3, z), put(x4, y3, z2), put(x3, y4, z2)};
		polygons[35] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[35].diffuse_I = 14;
		
		t = new vector[]{ put(x2, y4,z), put(x3, y4, z), put(x3, y4, z2), put(x2, y4,z2)};
		polygons[36] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[36].diffuse_I = 12;
		
		t = new vector[]{ put(x1, y3,z), put(x2, y4,z), put(x2, y4,z2), put(x1, y3,z2)};
		polygons[37] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[37].diffuse_I = 14;
		
		t = new vector[]{ put(x1,y2,z), put(x1, y3,z), put(x1, y3,z2), put(x1,y2,z2)};
		polygons[38] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[38].diffuse_I = 14;
		
		t = new vector[]{ put(x2, y1, z), put(x1,y2,z), put(x1,y2,z2), put(x2, y1, z2)};
		polygons[39] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[39].diffuse_I = 14;
		
		start.add(-0.017f,0,0);
		
		t = new vector[]{put(0.01, 0.015, 0.1011), put(0.004, 0.015, 0.1011), put(0.004, 0.015, 0.105), put(0.01, 0.015, 0.105)};
		polygons[40] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[40].diffuse_I = 20;
		
		t = new vector[]{put(0.01, 0.015, 0.1011), put(0.01, 0.015, 0.105), put(0.01, 0.012, 0.105), put(0.01, 0.012, 0.1011)};
		polygons[41] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[41].diffuse_I = 18;
		
		t = new vector[]{put(0.004, 0.015, 0.105), put(0.004, 0.015, 0.1011), put(0.004, 0.012, 0.1011), put(0.004, 0.012, 0.105)};
		polygons[42] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[42].diffuse_I = 18;
		
		t = new vector[]{put(0.01, 0.012, 0.105), put(0.004, 0.012, 0.105), put(0.004, 0.012, 0.1011), put(0.01, 0.012, 0.1011)};
		polygons[43] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[43].diffuse_I = 16;
		
		start.add(0, -0.04f,0);
		
		t = new vector[]{put(0.01, 0.015, 0.1011), put(0.004, 0.015, 0.1011), put(0.004, 0.015, 0.105), put(0.01, 0.015, 0.105)};
		polygons[44] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[44].diffuse_I = 20;
		
		t = new vector[]{put(0.01, 0.015, 0.1011), put(0.01, 0.015, 0.105), put(0.01, 0.012, 0.105), put(0.01, 0.012, 0.1011)};
		polygons[45] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[45].diffuse_I = 18;
		
		t = new vector[]{put(0.004, 0.015, 0.105), put(0.004, 0.015, 0.1011), put(0.004, 0.012, 0.1011), put(0.004, 0.012, 0.105)};
		polygons[46] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[46].diffuse_I = 18;
		
		t = new vector[]{put(0.01, 0.012, 0.105), put(0.004, 0.012, 0.105), put(0.004, 0.012, 0.1011), put(0.01, 0.012, 0.1011)};
		polygons[47] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[47].diffuse_I = 16;
		
		start.add(0, 0.04f,0);
		
		t = new vector[]{put(x2, y1, z), put(x3, y1, z), put(x4, y2, z), put(x4, y3, z), put(x3, y4, z), put(x2, y4,z), put(x1, y3,z), put(x1,y2,z)};
		polygons[48] = new polygon3D(t, t[0], t[1], t[5], main.textures[21], 1f,1f, 3); 
		polygons[48].diffuse_I = 20;
		
		t = new vector[]{put(x1,y2,z2), put(x1, y3,z2), put(x2, y4,z2), put(x3, y4, z2), put(x4, y3, z2), put(x4, y2, z2), put(x3, y1, z2), put(x2, y1, z2)};
		polygons[49] = new polygon3D(t, t[0], t[1], t[5], main.textures[21], 1f,1f, 3); 
		polygons[49].diffuse_I = 20;
		
		t = new vector[]{ put(x3, y1, z), put(x2, y1, z), put(x2, y1, z2), put(x3, y1, z2)};
		polygons[50] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[50].diffuse_I = 16;
		
		t = new vector[]{ put(x4, y2, z), put(x3, y1, z), put(x3, y1, z2), put(x4, y2, z2)};
		polygons[51] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[51].diffuse_I = 16;
		
		t = new vector[]{ put(x4, y3, z), put(x4, y2, z), put(x4, y2, z2), put(x4, y3, z2)};
		polygons[52] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[52].diffuse_I = 14;
		
		t = new vector[]{ put(x3, y4, z), put(x4, y3, z), put(x4, y3, z2), put(x3, y4, z2)};
		polygons[53] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[53].diffuse_I = 14;
		
		t = new vector[]{ put(x2, y4,z), put(x3, y4, z), put(x3, y4, z2), put(x2, y4,z2)};
		polygons[54] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[54].diffuse_I = 12;
		
		t = new vector[]{ put(x1, y3,z), put(x2, y4,z), put(x2, y4,z2), put(x1, y3,z2)};
		polygons[55] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[55].diffuse_I = 14;
		
		t = new vector[]{ put(x1,y2,z), put(x1, y3,z), put(x1, y3,z2), put(x1,y2,z2)};
		polygons[56] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[56].diffuse_I = 14;
		
		t = new vector[]{ put(x2, y1, z), put(x1,y2,z), put(x1,y2,z2), put(x2, y1, z2)};
		polygons[57] = new polygon3D(t, t[0], t[1], t[3], main.textures[21], 1f,1f, 3); 
		polygons[57].diffuse_I = 14;
		
		for(int i = 22; i < 58; i++)
			polygons[i].diffuse_I -=10;
		
		sortedPolygons = false;
		sortIndexStart = 2;
	
	
		for(int i = 0; i < polygons.length; i++){
			if(polygons[i].type == 6){
				polygons[i].diffuse_I -=15;
			}
		}
		
		//define reflection polygons
		reflection = new polygon3D[polygons.length];
		vector temp = new vector(0,0,0);
		
		start=centre.myClone();
		start.add(0, -0.31f,-0.015f);
		
		t = new vector[]{put(0.0851, 0.11, 0.095), put(0.0149, 0.11, 0.095), put(0.0149, -0.05, 0.095), put(0.0851, -0.05, 0.095)};
		reflection[0] = new polygon3D(t, t[0], t[1], t[3], main.textures[20], 1f,1f, 8); 
		reflection[0].diffuse_I = 5;
		
		start.add(-0.1f, 0,0);
		
		t = new vector[]{put(0.085, 0.11, 0.095), put(0.015, 0.11, 0.095), put(0.015, -0.05, 0.095), put(0.085, -0.05, 0.095)};
		reflection[1] = new polygon3D(t, t[0], t[1], t[3], main.textures[20], 1f,1f, 8); 
		reflection[1].diffuse_I = 5;
		
		
		for(int i = 2; i < polygons.length; i++){
			t = new vector[polygons[i].vertex3D.length];
			for(int j = 0; j < t.length; j++){
				temp.set(polygons[i].vertex3D[j]); 
				temp.y = (float)(-0.1 - (temp.y - (-0.1)));
				t[t.length - 1 - j] = temp.myClone();
			}
			
			vector origin = polygons[i].origin.myClone();
			origin.y = (float)(-0.1 - (origin.y - (-0.1)));
			vector rightEnd = polygons[i].rightEnd.myClone();
			rightEnd.y = (float)(-0.1 - (rightEnd.y - (-0.1)));
			vector bottomEnd = polygons[i].bottomEnd.myClone();
			bottomEnd.y = (float)(-0.1 - (bottomEnd.y - (-0.1)));
			texture theTexture = polygons[i].myTexture;
			float scaleX = polygons[i].scaleX;
			float scaleY = polygons[i].scaleY;
			
			reflection[i] = new polygon3D(t,origin, rightEnd, bottomEnd,theTexture, scaleX, scaleY,  8);
			reflection[i].diffuse_I = polygons[i].diffuse_I - 15;
			if(reflection[i].diffuse_I < 1)
				reflection[i].diffuse_I = 1;
			if(reflection[i].diffuse_I > 5)
				reflection[i].diffuse_I = 5;
		}
		
	}
	
	public void drawReflection(){
		for(int i = 0; i < reflection.length; i++){
			reflection[i].update();
			reflection[i].draw();
		}
		
	}

}
