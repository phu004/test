package core;
//Scene graph  is a tree of bounding boxes(container). Each bounding box can contain  3D models or
//other bounding boxes.  In the process of  hidden surface removal, the polygons that are enclosed
//by different bounding boxes will never compare against one another.


public class sceneGraph {
	
	//root node of the graph
	public static container world;
	
	//child nodes of the graph
	public static rostrum_lower rostrumLower;
	public static rostrum_middle rostrumMiddle;
	public static rostrum_upper rostrumUpper;
	public static rostrum_partA rostrumPartA1;
	public static rostrum_partA rostrumPartA2;
	public static rostrum_partB rostrumPartB;
	public static microphone microphone;
	public static woodChairLower woodchairLower1, woodchairLower2, woodchairLower3 ;
	public static woodChairUpper woodchairUpper1, woodchairUpper2, woodchairUpper3; 
		
	public static void createScene(){
		if(world != null)
			return;
		
		//define world 
		world = new container(new vector(0,0,0), 10,10,10);
		
		//floor in main hall
		floor_hallway floorHallway = new floor_hallway(new vector(0,-0.11f,0.4f));
		world.addModel(floorHallway);
		
		//volume to the west of the main hall
		container hallWest =  new container(new vector(-0.5f, 0.2f, 0.4f), 0.1f, 0.3f, 0.6f);
		world.addModel(hallWest);
		
		//wall to the west 
		wall_west wallWest = new wall_west(new vector(-0.4f, 0.2f, 0.4f));
		hallWest.addModel(wallWest);
		
		//windows on the west wall
		window_side windowSide1 = new window_side(new vector(-0.5f, 0.25f, 0.015f), 11,0);
		hallWest.addModel(windowSide1);
		
		window_side windowSide2 = new window_side(new vector(-0.5f, 0.25f, 0.365f), 9,0);
		hallWest.addModel(windowSide2);
		
		window_side windowSide3 = new window_side(new vector(-0.5f, 0.25f, 0.715f), 10,0);
		hallWest.addModel(windowSide3);
		
		//volume to the east of the main hall
		container hallEast =  new container(new vector(0.5f, 0.2f, 0.4f), 0.1f, 0.3f, 0.6f);
		world.addModel(hallEast);
		
		//wall to the east 
		wall_east wallEast = new wall_east(new vector(0.4f, 0.2f, 0.4f));
		hallEast.addModel(wallEast);
		
		//windows on the east wall
		window_side windowSide4 = new window_side(new vector(0.5f, 0.25f, 0.015f), 12,180);
		hallEast.addModel(windowSide4);
		
		window_side windowSide5 = new window_side(new vector(0.5f, 0.25f, 0.365f), 13,180);
		hallEast.addModel(windowSide5);
		
		window_side windowSide6 = new window_side(new vector(0.5f, 0.25f, 0.715f), 8,180);
		hallEast.addModel(windowSide6);
		
		//volume to the north of the main hall
		container hallNorth =  new container(new vector(0, 0.2f, 1.1f), 0.4001f, 0.6f, 0.099f);
		world.addModel(hallNorth);
		
		//wall to the east 
		wall_north wallNorth = new wall_north(new vector(0, 0.2f, 1f));
		hallNorth.addModel(wallNorth);
		
		//windows on the north wall
		window_north windowNorth1 = new window_north(new vector(-0.175f, 0.4f, 1.1f), 16);
		hallNorth.addModel(windowNorth1);
		
		window_north windowNorth2 = new window_north(new vector(0.175f, 0.4f, 1.1f), 16);
		hallNorth.addModel(windowNorth2);
		
		//volume to the south of the main hall
		container hallSouth = new container(new vector(0, 0.2f, -0.3f), 0.4001f, 0.6f, 0.099f);
		world.addModel(hallSouth);
		
		//wall to the south
		wall_south wallSouth = new wall_south(new vector(0, 0.2f, -0.2f));
		hallSouth.addModel(wallSouth);
		
		//door in wall_south
		door doorSouth = new door(new vector(0, 0.025f, -0.3f));
		hallSouth.addModel(doorSouth);
		
		//roof
		roof roofTop = new roof(new vector(0,0.72f,0.4f));
		world.addModel(roofTop);
		
		//volume of the main hall
		container hall = new container(new vector(0, 0.05f, 0.4f), 0.399f, 0.1499f, 0.5999f);
		world.addModel(hall);
		
		
		
		

		//upper volume of the main hall
		container hall_upper = new container(new vector(0, 0.3f, 0.4f), 0.399f, 0.0999f, 0.5999f);
		world.addModel(hall_upper);
		
		//chandeliers
		float z = 1f - 0.147f*2 - 0.01f + 0.0005f;
		
		for(int i = 0; i < 3 ; i ++){
			chandelier_upper chandelierUpper = new chandelier_upper(new vector(-0.1605f, 0.3f + 0.102f, z));
			hall_upper.addModel(chandelierUpper);
			
			chandelierUpper = new chandelier_upper(new vector(0.1605f, 0.3f + 0.102f, z));
			hall_upper.addModel(chandelierUpper);
			
			chandelier_lower chandelierLower = new chandelier_lower(new vector(-0.1605f, 0.264f, z));
			hall_upper.addModel(chandelierLower);
			
			chandelierLower = new chandelier_lower(new vector(0.1605f, 0.264f, z));
			hall_upper.addModel(chandelierLower);
			
			z-=0.147f;
			z-=0.147f;
		}
		
		//lower portion of the wood beams along the edge of the roof
		z = 0.99f;
		for(int i = 0; i < 8; i++){
			lower_beams lowerBeams = new lower_beams(new vector(-0.38f, 0.35f, z), 0);
			hall_upper.addModel(lowerBeams);
			
			lowerBeams = new lower_beams(new vector(0.38f, 0.35f, z), 1);
			hall_upper.addModel(lowerBeams);
			
			z-=0.147f;
		}
		
		lower_beams lowerBeams = new lower_beams(new vector(-0.38f, 0.35f, -0.2f + 0.01f), 0);
		hall_upper.addModel(lowerBeams);
		
		lowerBeams = new lower_beams(new vector(0.38f, 0.35f, -0.2f + 0.01f), 1);
		hall_upper.addModel(lowerBeams);
		
		//dados on the button of the wall
		hall.addMisc(new dado_hall());
		
		//stair at the front of the hall
		stair stair_ = new stair(new vector(0, -0.083f, 0.864f));
		hall.addModel(stair_);
		
		//wood charis on the platform
		woodchairLower1 = new woodChairLower(new vector(-0.095f,-0.066f,0.97f), 210);
		hall.addModel(woodchairLower1);
		
		woodchairUpper1 = new woodChairUpper(new vector(-0.095f,-0.011f, 0.97f), 210);
		hall.addModel(woodchairUpper1);
		
		woodchairLower2 = new woodChairLower(new vector(0.03f,-0.066f,0.99f), 180);
		hall.addModel(woodchairLower2);
		
		woodchairUpper2 = new woodChairUpper(new vector(0.03f,-0.011f, 0.99f), 180);
		hall.addModel(woodchairUpper2);
		
		woodchairLower3 = new woodChairLower(new vector(0.155f,-0.066f,0.97f), 150);
		hall.addModel(woodchairLower3);
		
		woodchairUpper3 = new woodChairUpper(new vector(0.155f,-0.011f, 0.97f), 150);
		hall.addModel(woodchairUpper3);
		
		//rostrum on the platform
		rostrumLower = new rostrum_lower(new vector(0, -0.0585f, 0.782f));
		hall.addModel(rostrumLower);
		
		rostrumMiddle = new rostrum_middle(new vector(0, -0.011f, 0.782f));
		hall.addModel(rostrumMiddle);
		
		rostrumUpper = new rostrum_upper(new vector(0, 0.0355f, 0.782f));
		hall.addModel(rostrumUpper);
		
		rostrumPartA1 = new rostrum_partA(new vector((0.05f - 0.0015f)*0.8f, 0.048f, 0.782f));
		hall.addModel(rostrumPartA1);
		
		rostrumPartA2  = new rostrum_partA(new vector((-0.05f + 0.0015f)*0.8f, 0.048f, 0.782f));
		hall.addModel(rostrumPartA2);
		
		rostrumPartB= new rostrum_partB(new vector(0,0.048f, 0.782f - (0.05f - 0.0015f)*0.65f));
		hall.addModel(rostrumPartB);
		
		//microphone on the rostrum surface
		microphone microphone_ = new microphone(new vector(0,0.072f, 0.782f));
		hall.addModel(microphone_);
		
		//church pews
		for(int i = 0; i < 5; i++){
			chair chair1 = new chair(new vector(-0.25f, -0.032f, -0.14f + 0.15f*i), 2*(5-i));
			hall.addModel(chair1);
			
			chair chair2 = new chair(new vector(0.25f, -0.032f, -0.14f + 0.15f*i), 2*(5-i));
			hall.addModel(chair2);
		}
	
	}
	
	//update scene graph
	public static void update(){
		world.update();
	}
	
	//draw scene graph
	public static void draw(){
		world.draw();
		
	}
	
	
}
