package core;
//3D model: dado on main hall walls
public class dado_hall extends solidObject{
	public dado_hall(){
		start = new vector(0,0,0);
		this.centre = start.myClone();
		tempCentre = start.myClone();
		
		//define reference axis (in world coordinate)
		iDirection = new vector(1,0,0);
		jDirection = new vector(0,1,0);
		kDirection = new vector(0,0,1);
		
		//create a rough 3D cuboid boundary for this model.
		makeBoundary(2f, 2f, 2f);
		
		//create polygons
		makePolygons();
	}
	
	public void makePolygons(){
		polygons = new polygon3D[14];
		vector[] t;
		
		t = new vector[]{put(-0.1, -0.083, -0.195), put(-0.395, -0.083, -0.195), put(-0.395, -0.1, -0.195), put(-0.1, -0.1, -0.195)};
		polygons[0] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 1.5f,1,3); 
		polygons[0].diffuse_I = 20;
		
		t = new vector[]{put(-0.1, -0.083, -0.2),put(-0.1, -0.083, -0.195), put(-0.1, -0.1, -0.195), put(-0.1, -0.1, -0.2)};
		polygons[1] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 0.2f,1,3); 
		polygons[1].diffuse_I = 15;
		
		t = new vector[]{put(-0.395, -0.083, -0.195), put(-0.395, -0.083, 0.995), put(-0.395, -0.1, 0.995), put(-0.395, -0.1, -0.195)};
		polygons[2] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 5f,1,3); 
		polygons[2].diffuse_I = 15;
		
		t = new vector[]{ put(-0.395, -0.083, 0.995),  put(-0.2, -0.083, 0.995), put(-0.2, -0.1, 0.995), put(-0.395, -0.1, 0.995)};
		polygons[3] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 1.5f,1,3); 
		polygons[3].diffuse_I = 15;
		
		
		
		t = new vector[]{ put(-0.4, -0.083, -0.195),  put(-0.4, -0.083, 1), put(-0.395, -0.083, 1), put(-0.395, -0.083, -0.195)};
		polygons[4] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 5f,1,3); 
		polygons[4].diffuse_I = 23;
	
		t = new vector[]{put(-0.1, -0.083, -0.2), put(-0.4, -0.083, -0.2), put(-0.4, -0.083, -0.195), put(-0.1, -0.083, -0.195)};
		polygons[5] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 1.5f,1,3); 
		polygons[5].diffuse_I = 23;
	
		
		t = new vector[]{put(-0.395, -0.083, 1), put(-0.2, -0.083, 1), put(-0.2, -0.083, 0.995), put(-0.395, -0.083, 0.995)};
		polygons[6] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 1.5f,1,3); 
		polygons[6].diffuse_I = 23;
		
		
		
		t = new vector[]{put(0.1, -0.1, -0.195), put(0.395, -0.1, -0.195), put(0.395, -0.083, -0.195), put(0.1, -0.083, -0.195)};
		polygons[7] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 1.5f,1,3); 
		polygons[7].diffuse_I = 20;
		
		t = new vector[]{put(0.1, -0.1, -0.2), put(0.1, -0.1, -0.195),put(0.1, -0.083, -0.195), put(0.1, -0.083, -0.2)};
		polygons[8] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 0.2f,1,3); 
		polygons[8].diffuse_I = 15;
		
		t = new vector[]{put(0.395, -0.1, -0.195), put(0.395, -0.1, 0.995), put(0.395, -0.083, 0.995), put(0.395, -0.083, -0.195)};
		polygons[9] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 5f,1,3); 
		polygons[9].diffuse_I = 15;
		
		t = new vector[]{put(0.395, -0.1, 0.995), put(0.2, -0.1, 0.995),  put(0.2, -0.083, 0.995),  put(0.395, -0.083, 0.995)};
		polygons[10] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 1.5f,1,3); 
		polygons[10].diffuse_I = 15;
		
		t = new vector[]{ put(0.395, -0.083, -0.195), put(0.395, -0.083, 1),  put(0.4, -0.083, 1), put(0.4, -0.083, -0.195)};
		polygons[11] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 5f,1,3); 
		polygons[11].diffuse_I = 23;
	
		t = new vector[]{put(0.1, -0.083, -0.195), put(0.4, -0.083, -0.195), put(0.4, -0.083, -0.2), put(0.1, -0.083, -0.2)};
		polygons[12] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 1.5f,1,3); 
		polygons[12].diffuse_I = 23;
		
		
		t = new vector[]{put(0.395, -0.083, 0.995), put(0.2, -0.083, 0.995), put(0.2, -0.083, 1), put(0.395, -0.083, 1)};
		polygons[13] = new polygon3D(t, t[0], t[1], t[3], main.textures[26], 1.5f,1,3); 
		polygons[13].diffuse_I = 23;
	}
	
	public void drawReflection(){};
}
