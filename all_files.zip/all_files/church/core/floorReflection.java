package core;
//reflection of the scene on the floor surface
public class floorReflection {
	
private  polygon3D[] polygons; 
	
	//3D axis 
	public vector iDirection, jDirection, kDirection;
	
	//centre of the local coordinate system
	public vector centre;
	
	public floorReflection(){
		//define axis 
		iDirection = new vector(1,0,0);
		jDirection = new vector(0,1,0);
		kDirection = new vector(0,0,1);
		
		centre= new vector(0,0,0);
		
		polygons = new polygon3D[240];
		vector[] t;
		int index = 0;
		
		//reflection of front windows on the floor surface
		double[] x = new double[]{-0.065, 0.065, 0.065, 0.055, 0.04, 0.02, 0, -0.02, -0.04, -0.055, -0.065};
		double[] y = new double[]{-0.15, -0.15, -0.17, -0.2, -0.22, -0.235, -0.245, -0.235, -0.22, -0.2, -0.17};
		
		
		centre.set(-0.175f,-0.4f,1.04f);
		iDirection = new vector(1.1538461f,0,0);
		
		t = new vector[]{put(-0.065, 0.15, 0), put(0.065, 0.15, 0), put(0.065, -0.15, 0), put(-0.065, -0.15, 0)};
		polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[16], 1,1, 8); 
		polygons[index].diffuse_I = 8;
		index++;
	
		t = new vector[]{put(x[0], y[0], 0), 
				         put(x[1], y[1], 0), 
				         put(x[2], y[2], 0), 
				         put(x[3], y[3], 0), 
				         put(x[4], y[4], 0), 
				         put(x[5], y[5], 0), 
				         put(x[6], y[6], 0), 
				         put(x[7], y[7], 0), 
				         put(x[8], y[8], 0), 
				         put(x[9], y[9], 0), 
				         put(x[10], y[10], 0), 
				        };
		polygons[index] = new polygon3D(t, t[0],t[1], put(-0.065, -0.25, 0), main.textures[18], 1,1, 8); 
		polygons[index].diffuse_I = 8;
		index++;
		
		for(int i = 1; i < 11; i++){
			t = new vector[]{put(x[i], y[i], 0), put(x[i], y[i], -0.04), put(x[(i+1)%11], y[(i+1)%11], -0.04), put(x[(i+1)%11], y[(i+1)%11], 0)};
			polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[7], 0.2f,0.2f, 8); 
			polygons[index].diffuse_I = 5;
			index++;
		}
		
		for(int i = 1; i < 11; i++){
			t = new vector[]{put(x[(i+1)%11], y[(i+1)%11], 0),put(x[(i+1)%11], y[(i+1)%11], -0.04), put(x[i], y[i], -0.04), put(x[i], y[i], 0)};
			polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[7], 0.2f,0.1f, 8); 
			polygons[index].diffuse_I = 0;
			index++;
		}
		
		t = new vector[]{put(-0.065, 0.15, -0.04f), put(-0.065, 0.15, 0), put(-0.065, -0.15, 0), put(-0.065, -0.15, -0.04f)};
		polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[7], 0.2f,2f, 8); 
		polygons[index].diffuse_I = 6;
		index++;
		
		t = new vector[]{put(-0.065, -0.15, -0.04f), put(-0.065, -0.15, 0), put(-0.065, 0.15, 0), put(-0.065, 0.15, -0.04f)};
		polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[7], 0.2f,2f, 8); 
		polygons[index].diffuse_I = 0;
		index++;
		
		
		t = new vector[]{put(0.065, 0.15, 0), put(0.065, 0.15, -0.04), put(0.065, -0.15, -0.04), put(0.065, -0.15, 0)};
		polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[7], 0.2f,2f, 8); 
		polygons[index].diffuse_I = 6;
		index++;
		
		t = new vector[]{put(0.065, -0.15, 0), put(0.065, -0.15, -0.04), put(0.065, 0.15, -0.04), put(0.065, 0.15, 0)};
		polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[7], 0.2f,2f, 8); 
		polygons[index].diffuse_I = 0;
		index++;
		
		t = new vector[]{put(0.065, 0.15, 0), put(0.065, 0.15, -0.04), put(-0.065, 0.15, -0.04), put(-0.065, 0.15, 0)};
		polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[7], 0.2f,2f, 8); 
		polygons[index].diffuse_I = 0;
		index++;
		
		
		centre.set(0.175f,-0.4f,1.04f);
		
		t = new vector[]{put(-0.065, 0.15, 0), put(0.065, 0.15, 0), put(0.065, -0.15, 0), put(-0.065, -0.15, 0)};
		polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[16], 1,1, 8); 
		polygons[index].diffuse_I = 8;
		index++;
		
		t = new vector[]{put(x[0], y[0], 0), 
		         put(x[1], y[1], 0), 
		         put(x[2], y[2], 0), 
		         put(x[3], y[3], 0), 
		         put(x[4], y[4], 0), 
		         put(x[5], y[5], 0), 
		         put(x[6], y[6], 0), 
		         put(x[7], y[7], 0), 
		         put(x[8], y[8], 0), 
		         put(x[9], y[9], 0), 
		         put(x[10], y[10], 0), 
		        };
		polygons[index] = new polygon3D(t, t[0],t[1], put(-0.065, -0.25, 0), main.textures[18], 1,1, 8); 
		polygons[index].diffuse_I = 8;
		index++;
		
		for(int i = 1; i < 11; i++){
			t = new vector[]{put(x[i], y[i], 0), put(x[i], y[i], -0.04), put(x[(i+1)%11], y[(i+1)%11], -0.04), put(x[(i+1)%11], y[(i+1)%11], 0)};
			polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[7], 0.2f,0.2f, 8); 
			polygons[index].diffuse_I = 5;
			index++;
			
			
		}
		for(int i = 1; i < 11; i++){
			t = new vector[]{put(x[(i+1)%11], y[(i+1)%11], 0),put(x[(i+1)%11], y[(i+1)%11], -0.04), put(x[i], y[i], -0.04), put(x[i], y[i], 0)};
			polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[7], 0.2f,0.1f, 8); 
			polygons[index].diffuse_I = 0;
			index++;
		}
		
		t = new vector[]{put(-0.065, 0.15, -0.04f), put(-0.065, 0.15, 0), put(-0.065, -0.15, 0), put(-0.065, -0.15, -0.04f)};
		polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[7], 0.2f,2f, 8); 
		polygons[index].diffuse_I = 5;
		index++;
		
		t = new vector[]{put(-0.065, -0.15, -0.04f), put(-0.065, -0.15, 0), put(-0.065, 0.15, 0), put(-0.065, 0.15, -0.04f)};
		polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[7], 0.2f,2f, 8); 
		polygons[index].diffuse_I = 0;
		index++;
		
		
		t = new vector[]{put(0.065, 0.15, 0), put(0.065, 0.15, -0.04), put(0.065, -0.15, -0.04), put(0.065, -0.15, 0)};
		polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[7], 0.2f,2f, 8); 
		polygons[index].diffuse_I = 2;
		index++;
		
		t = new vector[]{put(0.065, -0.15, 0), put(0.065, -0.15, -0.04), put(0.065, 0.15, -0.04), put(0.065, 0.15, 0)};
		polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[7], 0.2f,2f, 8); 
		polygons[index].diffuse_I = 0;
		index++;
		
		t = new vector[]{put(0.065, 0.15, 0), put(0.065, 0.15, -0.04), put(-0.065, 0.15, -0.04), put(-0.065, 0.15, 0)};
		polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[7], 0.2f,2f, 8); 
		polygons[index].diffuse_I = 0;
		index++;
		
		
		//reflection of side windows on the floor surface
		centre.set(0.5f, -0.25f, 0.715f);
		
		iDirection = new vector(1,0,0);
		jDirection = new vector(0,1,0);
		kDirection = new vector(0,0,1);
		
		iDirection.rotate_XZ(180);
		kDirection.rotate_XZ(180);
		
		for(int i = 0; i < 6; i++){
			int textureIndex = 8;
			if(i == 1)
				textureIndex = 13;
			if(i == 2)
				textureIndex = 12;
			if(i == 3){
				textureIndex = 10;
				iDirection.rotate_XZ(180);
				kDirection.rotate_XZ(180);
				centre.set(-0.5f, -0.2f, 0.715f);
			}
			if(i == 4)
				textureIndex = 9;
			if(i == 5)
				textureIndex = 11;
			
			t = new vector[]{put(0.06, -0.004, -0.065), put(0.06, -0.004, 0.065), put(0.06, -0.15, 0.065),  put(0.06, -0.15, -0.065)};
			polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[30], 1,1, 8); 
			polygons[index].diffuse_I = 6;
			index++;
			
			t = new vector[]{put(0.06, -0.146, -0.065), put(0.06, -0.146, 0.065), put(0.06, -0.148, 0.065),  put(0.06, -0.148, -0.065)};
			polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[30], 1,1, 8); 
			polygons[index].diffuse_I = 0;
			index++;
			
			t = new vector[]{put(0.06, -0.101, -0.065), put(0.06, -0.101, 0.065), put(0.06, -0.103, 0.065),  put(0.06, -0.103, -0.065)};
			polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[30], 1,1, 8); 
			polygons[index].diffuse_I = 0;
			index++;
			
			t = new vector[]{put(0.06, -0.057, -0.065), put(0.06, -0.057, 0.065), put(0.06, -0.059, 0.065),  put(0.06, -0.059, -0.065)};
			polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[30], 1,1, 8); 
			polygons[index].diffuse_I = 0;
			index++;
			
			double[] z = new double[]{0.065, 0.052,  0.039, 0.026, 0.013, 0, -0.013, -0.026, -0.039, -0.052, -0.065};
			y = new double[]{-0.f, -0.04f, -0.06f, -0.075f, -0.088f, -0.093f, -0.088f, -0.075f, -0.06f, -0.04f, -0.f};
			for(int j  = 0; j < y.length; j++)
				y[j]-=0.15;
			
			t = new vector[]{put(0.06, y[0], z[0]), 
							 put(0.06, y[1], z[1]), 
							 put(0.06, y[2], z[2]), 
							 put(0.06, y[3], z[3]), 
							 put(0.06, y[4], z[4]), 
							 put(0.06, y[5], z[5]), 
							 put(0.06, y[6], z[6]), 
							 put(0.06, y[7], z[7]), 
							 put(0.06, y[8], z[8]), 
							 put(0.06, y[9], z[9]), 
							 put(0.06, y[10], z[10]), 
			        };
			
			polygons[index] = new polygon3D(t, put(0.06, -0.146, -0.065), put(0.06, -0.146, 0.065),put(0.06, -0.148, -0.065), main.textures[30], 1,1, 8); 
			polygons[index].diffuse_I = 6;
			index++;
			
			for(int j = 0; j < 10; j++){
				t = new vector[]{put(0.06, y[j], z[j]), put(0.1, y[j], z[j]), put(0.1, y[j+1], z[j+1]), put(0.06, y[j+1], z[j+1])};
				polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[7], 0.2f,0.2f, 8); 
				polygons[index].diffuse_I = 7;
				index++;
			}
			
			t = new vector[]{put(0.06, -0.004, 0.065), put(0.1, -0.004, 0.065), put(0.1, -0.15, 0.065), put(0.06, -0.15, 0.065)};
			polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[7], 0.2f,2f, 8); 
			polygons[index].diffuse_I = 8;
			index++;
			
			t = new vector[]{put(0.06, -0.15, -0.065), put(0.1, -0.15, -0.065), put(0.1, -0.004, -0.065), put(0.06, -0.004, -0.065)};
			polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[7], 0.2f,2f, 8); 
			polygons[index].diffuse_I = 8;
			index++;
			
			
			t = new vector[]{put(0.06, -0.004, -0.048), put(0.06, -0.004, 0.048), put(0.06, -0.2, 0.048),  put(0.06, -0.2, -0.048)};
			polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[textureIndex], 1,1, 8); 
			polygons[index].diffuse_I = 6;
			index++;
			
			for(int j = 0; j < 10; j++){
				t = new vector[]{put(0.06, y[j+1], z[j+1]), put(0.1, y[j+1], z[j+1]), put(0.1, y[j], z[j]), put(0.06, y[j], z[j])};
				polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[7], 0.2f,0.2f, 8); 
				polygons[index].diffuse_I = 0;
				index++;
			}
			
			t = new vector[]{ put(0.06, -0.15, 0.065), put(0.1, -0.15, 0.065), put(0.1, -0.004, 0.065),put(0.06, -0.004, 0.065)};
			polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[7], 0.2f,2f, 8); 
			polygons[index].diffuse_I = 0;
			index++;
			
			t = new vector[]{put(0.06, -0.004, -0.065), put(0.1, -0.004, -0.065), put(0.1, -0.15, -0.065) ,put(0.06, -0.15, -0.065)};
			polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[7], 0.2f,2f, 8); 
			polygons[index].diffuse_I = 0;
			index++;
			
			t = new vector[]{put(0.06,-0.004, 0.065),put(0.1,-0.004, 0.065), put(0.1,-0.004, -0.065), put(0.06,-0.004, -0.065)};
			polygons[index] = new polygon3D(t, t[0],t[1], t[3], main.textures[7], 0.2f,2f, 8); 
			polygons[index].diffuse_I = 0;
			index++;
			
			
			centre.add(0,0,-0.35f);
		}
		
	}
	
	public void update(){
		
		for(int i = 0; i < polygons.length; i ++){
			polygons[i].update();
		}
		
		
	}
	
	public void draw(){
		for(int i = 0; i < polygons.length; i ++){
			polygons[i].draw();
		}
		
		sceneGraph.world.drawReflection();
		sceneGraph.woodchairUpper1.drawReflections();
		sceneGraph.woodchairUpper2.drawReflections();
		sceneGraph.woodchairUpper3.drawReflections();
		sceneGraph.woodchairLower1.drawReflections();
		sceneGraph.woodchairLower2.drawReflections();
		sceneGraph.woodchairLower3.drawReflections();
		
		sceneGraph.rostrumPartA1.drawReflections();
		sceneGraph.rostrumPartA2.drawReflections();
		sceneGraph.rostrumPartB.drawReflections();
		sceneGraph.rostrumUpper.drawReflections();
		sceneGraph.rostrumMiddle.drawReflections();
		sceneGraph.rostrumLower.drawReflections();
		
		
	}
	
	public vector put(double i, double j, double k){
		vector temp = new vector(0,0,0);
		temp.set(centre);
		temp.add(iDirection, (float)i);
		temp.add(jDirection, (float)j);
		temp.add(kDirection, (float)k);
		return temp;
	}

}
