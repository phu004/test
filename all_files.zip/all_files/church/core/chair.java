package core;
public class chair extends solidObject{
	int diffuseFactor;
	
	public chair(vector centre, int diffuseFactor){
		//centre point of the model (in world coordinate)
		start = centre.myClone();
		this.centre = start.myClone();
		tempCentre = start.myClone();
		this.diffuseFactor = diffuseFactor;
		
		//define reference axis (in world coordinate)
		iDirection = new vector(1,0,0);
		jDirection = new vector(0,0.9f,0);
		kDirection = new vector(0,0,0.8f);
		
		//create a rough 3D cuboid boundary for this model.
		makeBoundary(0.13f, 0.07499f, 0.05f);
		
		makePolygons();
	}
	
	public void makePolygons(){
		polygons = new polygon3D[56];
		vector[] t;	
		vector[] edge1, edge2, edge3, edge4;
		int index = 0;
		
		//really mess up here...
		
		edge1 = new vector[]{
				put(0.13, 0.04, -0.05),
				put(0.13, 0.045, -0.0475),
				put(0.13, 0.048, -0.045),
				put(0.13, 0.05, -0.0425),
				put(0.13, 0.051, -0.04),
				put(0.13, 0.0515, -0.0375),
				
				put(0.13, 0.0515, -0.02),
				put(0.13, 0.051, -0.0175),
				put(0.13, 0.05, -0.015),
				put(0.13, 0.048, -0.0125),
				put(0.13, 0.045, -0.01),
				put(0.13, 0.04, -0.0075),
				put(0.13, -0.0032, -0.0075),
				
				put(0.13, -0.0032, 0.0275),
				put(0.13, -0.0037, 0.03),
				put(0.13, -0.0047, 0.0325),
				put(0.13, -0.0067, 0.035),
				put(0.13, -0.0097, 0.0375),
				put(0.13, -0.0157, 0.04),
				
				put(0.13, -0.075, 0.04),
				put(0.13, -0.075, -0.05),
		};
		
		edge2 = new vector[edge1.length];
		edge3 = new vector[edge1.length];
		edge4 = new vector[edge1.length];
		
		for(int i = 0; i < edge1.length; i++){
			edge2[i] = edge1[i].myClone();
			edge2[i].add(-0.005f,0,0);
			
			edge3[i] = edge1[i].myClone();
			edge3[i].add(-0.255f,0,0);
			
			edge4[i] = edge1[i].myClone();
			edge4[i].add(-0.26f,0,0);
		}
		
		

		t =  new vector[]{edge1[0], edge1[1], edge1[2], edge1[3], edge1[4], edge1[5], edge1[6], edge1[7], edge1[8], edge1[9], edge1[10], edge1[11], put(0.13, -0.0132, -0.0075),put(0.13, -0.0132, -0.05)};
		for(int i = 0; i < t.length; i++){
			t[i] = t[i].myClone();
			t[i].add(-0.255f,0,0);
		}
		polygons[index] =  new polygon3D(t, put(-0.125, 0.075, 0.05), put(-0.125, -0.075, 0.05), put(-0.125, 0.075, -0.05), main.textures[29], 1f,1f, 3); 
		index++;
		
		vector[] temp3 = new vector[t.length];
		for(int i = 0; i < t.length; i++){
			temp3[i] = t[t.length - 1 - i].myClone();
			temp3[i].add(0.25f,0,0);
		}
		
		t = new vector[]{put(0.13, -0.0132, -0.05), edge1[12], edge1[13], edge1[14], edge1[15], edge1[16], edge1[17], edge1[18], edge1[19], edge1[20]};
		for(int i = 0; i < t.length; i++){
			t[i] = t[i].myClone();
			t[i].add(-0.255f,0,0);
		}
		polygons[index] =  new polygon3D(t, put(-0.125, 0.075, 0.05), put(-0.125, -0.075, 0.05), put(-0.125, 0.075, -0.05), main.textures[29], 1f,1f, 3); 
		index++;
		
		//crate  mirror vertices 
		vector[] temp4 = new vector[t.length];
		for(int i = 0; i < t.length; i++){
			temp4[i] = t[t.length - 1 - i].myClone();
			temp4[i].add(0.25f,0,0);
		}
		
		
		polygons[index] =  new polygon3D(temp3, put(0.125, 0.075, 0.05), put(0.125, -0.075, 0.05), put(0.125, 0.075, -0.05), main.textures[29], 1f,1f, 3); 
		index++;
		
		polygons[index] =  new polygon3D(temp4, put(0.125, 0.075, 0.05), put(0.125, -0.075, 0.05), put(0.125, 0.075, -0.05), main.textures[29], 1f,1f, 3); 
		index++;
		
		
		t = new vector[]{put(-0.125, -0.02, 0.035), put(0.125, -0.02, 0.035), put(0.125, -0.025, -0.03), put(-0.125, -0.025, -0.03)};
		polygons[index] =  new polygon3D(t, t[0], t[1], t[3], main.textures[29], 2f,1f, 3); 
		index++;
		
		t = new vector[]{put(0.125, 0.039, -0.042), put(-0.125, 0.039, -0.042), put(-0.125, -0.025, -0.03), put(0.125, -0.025, -0.03)};
		polygons[index] =  new polygon3D(t, t[0], t[1], t[3], main.textures[29], 2f,1f, 3); 
		index++;
		
		for(int i = 7; i < 14; i++){
			t = new vector[]{edge1[i], edge2[i], edge2[i+1], edge1[i+1]};
			polygons[index] =  new polygon3D(t, t[0], t[1], t[3], main.textures[29], 0.2f,0.02f, 3); 
			index++;
			
			t = new vector[]{edge3[i], edge4[i], edge4[i+1], edge3[i+1]};
			polygons[index] =  new polygon3D(t, t[0], t[1], t[3], main.textures[29], 0.2f,0.02f, 3); 
			index++;
		}
		
		
		t = new vector[]{put(-0.125, 0.039, -0.042), put(0.125, 0.039, -0.042), put(0.125, 0.039, -0.047), put(-0.125, 0.039, -0.047)};
		polygons[index] =  new polygon3D(t, t[0], t[1], t[3], main.textures[29], 2f,0.2f, 3); 
		polygons[index].diffuse_I = 35;
		index++;
		
		t = new vector[]{put(0.125, -0.02, 0.035), put(-0.125, -0.02, 0.035), put(-0.125, -0.025, 0.035), put(0.125, -0.025, 0.035)};
		polygons[index] =  new polygon3D(t, t[0], t[1], t[3], main.textures[29], 2f,0.2f, 3); 
		polygons[index].diffuse_I = 50;
		index++;
		
		
		
		t = new vector[]{put(0.125, -0.025, 0.035), put(-0.125, -0.025, 0.035), put(-0.125, -0.03, -0.035), put(0.125, -0.03, -0.035)};
		polygons[index] =  new polygon3D(t, t[0], t[1], t[3], main.textures[29], 2f,1f, 3); 
		index++;
		
		t = new vector[]{ put(-0.125, 0.039, -0.047), put(0.125, 0.039, -0.047), put(0.125, -0.03, -0.035), put(-0.125, -0.03, -0.035)};
		polygons[index] =  new polygon3D(t, t[0], t[1], t[3], main.textures[29], 2f,1f, 3); 
		index++;
		
		
		for(int i = 14; i < 20; i++){
			t = new vector[]{edge1[i], edge2[i], edge2[i+1], edge1[i+1]};
			polygons[index] =  new polygon3D(t, t[0], t[1], t[3], main.textures[29], 0.2f,0.02f, 3); 
			index++;
			
			t = new vector[]{edge3[i], edge4[i], edge4[i+1], edge3[i+1]};
			polygons[index] =  new polygon3D(t, t[0], t[1], t[3], main.textures[29], 0.2f,0.02f, 3); 
			index++;
		}
		
		
		for(int i = 0; i < 7; i++){
			t = new vector[]{edge1[i], edge2[i], edge2[i+1], edge1[i+1]};
			polygons[index] =  new polygon3D(t, t[0], t[1], t[3], main.textures[29], 0.2f,0.02f, 3); 
			index++;
			
			t = new vector[]{edge3[i], edge4[i], edge4[i+1], edge3[i+1]};
			polygons[index] =  new polygon3D(t, t[0], t[1], t[3], main.textures[29], 0.2f,0.02f, 3); 
			index++;
		}
		
		t = new vector[]{edge2[0], edge1[0], edge1[20], edge2[20]};
		polygons[index] =  new polygon3D(t, t[0], t[1], t[3], main.textures[29], 0.2f,1f, 3); 
		index++;
		
		t = new vector[]{edge4[0], edge3[0], edge3[20], edge4[20]};
		polygons[index] =  new polygon3D(t, t[0], t[1], t[3], main.textures[29], 0.2f,1f, 3); 
		index++;
		
		t = new vector[]{edge1[0], edge1[1], edge1[2], edge1[3], edge1[4], edge1[5], edge1[6], edge1[7], edge1[8], edge1[9], edge1[10], edge1[11], put(0.13, -0.0132, -0.0075),put(0.13, -0.0132, -0.05)};
		polygons[index] =  new polygon3D(t, put(0.13, 0.075, 0.05), put(0.13, -0.075, 0.05), put(0.13, 0.075, -0.05), main.textures[29], 1f,1f, 3); 
		index++;
		
		//crate  mirror vertices 
		vector[] temp1 = new vector[t.length];
		for(int i = 0; i < t.length; i++){
			temp1[i] = t[t.length - 1 - i].myClone();
			temp1[i].add(-0.26f,0,0);
		}
		
		t = new vector[]{put(0.13, -0.0132, -0.05), edge1[12], edge1[13], edge1[14], edge1[15], edge1[16], edge1[17], edge1[18], edge1[19], edge1[20]};
		polygons[index] =  new polygon3D(t, put(0.13, 0.075, 0.05), put(0.13, -0.075, 0.05), put(0.13, 0.075, -0.05), main.textures[29], 1f,1f, 3); 
		index++;
	
		//crate  mirror vertices 
		vector[] temp2 = new vector[t.length];
		for(int i = 0; i < t.length; i++){
			temp2[i] = t[t.length - 1 - i].myClone();
			temp2[i].add(-0.26f,0,0);
		}
		
		polygons[index] =  new polygon3D(temp1, put(-0.13, 0.075, 0.05), put(-0.13, -0.075, 0.05), put(-0.13, 0.075, -0.05), main.textures[29], 1f,1f, 3); 
		index++;
		
		polygons[index] =  new polygon3D(temp2, put(-0.13, 0.075, 0.05), put(-0.13, -0.075, 0.05), put(-0.13, 0.075, -0.05), main.textures[29], 1f,1f, 3); 
		index++;
		
		
		
		
		for(int i = 0; i < polygons.length; i++){
			if(	polygons[i].diffuse_I >= 30)
				polygons[i].diffuse_I -= 5;
			polygons[i].diffuse_I-=5;
			if(polygons[i].diffuse_I < 10)
				polygons[i].diffuse_I = 10;
		}
		
		//define reflection polygons
		reflection = new polygon3D[polygons.length];
		
		vector temp = new vector(0,0,0);
		
		for(int i = 0; i < reflection.length; i++){
			t = new vector[polygons[i].vertex3D.length];
			for(int j = 0; j < t.length; j++){
				temp.set(polygons[i].vertex3D[j]); 
				temp.y = (float)(-0.1 - (temp.y - (-0.1)));
				t[t.length - 1 - j] = temp.myClone();
			}
			
			vector origin = polygons[i].origin.myClone();
			origin.y = (float)(-0.1 - (origin.y - (-0.1)));
			vector rightEnd = polygons[i].rightEnd.myClone();
			rightEnd.y = (float)(-0.1 - (rightEnd.y - (-0.1)));
			vector bottomEnd = polygons[i].bottomEnd.myClone();
			bottomEnd.y = (float)(-0.1 - (bottomEnd.y - (-0.1)));
			texture theTexture = polygons[i].myTexture;
			float scaleX = polygons[i].scaleX;
			float scaleY = polygons[i].scaleY;
			
			reflection[i] = new polygon3D(t,origin, rightEnd, bottomEnd,theTexture, scaleX, scaleY,  8);
			reflection[i].diffuse_I = polygons[i].diffuse_I - 15;
			if(reflection[i].diffuse_I < 0)
				reflection[i].diffuse_I = 1;
			if(reflection[i].diffuse_I > 10)
				reflection[i].diffuse_I = 10;
			reflection[i].diffuse_I = 0;
		}
		
	}
	
	public void drawReflection(){
		for(int i = 0; i < reflection.length; i++){
			reflection[i].update();
			reflection[i].draw();
		}
	}
	
	
}
