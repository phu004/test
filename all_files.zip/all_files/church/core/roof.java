package core;
//3d model: church roof 
public class roof extends solidObject{
	
	public roof(vector centre){
		//centre point of the model (in world coordinate)
		start = centre.myClone();
		this.centre = start.myClone();
		tempCentre = start.myClone();
		
		//define reference axis (in world coordinate)
		iDirection = new vector(1,0,0);
		jDirection = new vector(0,1,0);
		kDirection = new vector(0,0,1);
		
		//create a rough 3D cuboid boundary for this model.
		makeBoundary(0.4f, 0.319f, 0.599f);
	
		
		//create polygons
		makePolygons();
	}
	
	
	//all the polygon vertices  are hard coded here
	public void makePolygons(){
		polygons = new polygon3D[96];
		vector[] t;
		
		 t = new vector[]{put(0, 0.08, -0.601), put(0, 0.08, 0.601), put(-0.4, -0.32, 0.601), put(-0.4, -0.32, -0.601)};
		 polygons[0] = new polygon3D(t, t[0], t[1], t[3], main.textures[22], 8,4, 6); 
		 polygons[0].diffuse_I = 25;
		
		 
		 t = new vector[]{put(0.4, -0.32, -0.601), put(0.4, -0.32, 0.601), put(0, 0.08, 0.601) ,put(0, 0.08, -0.601)};
		 polygons[1] = new polygon3D(t, t[0], t[1], t[3], main.textures[22], 8,4, 6); 
		 polygons[1].diffuse_I = 25;
		 
		 
		 int index = 2;
		 double w = 0.04;
		 double h = 0.04;
		 double l = 0.02;
		 double z = 0.6;
		 int I = 60;
		 
		 for(int i = 0; i < 8; i ++){
			
			 if( i == 2 || i == 4 || i == 6){
				 t = new vector[]{put(-0.24, -0.2, z-l), put(-0.24, -0.2, z), put(0.24, -0.2, z), put(0.24, -0.2, z-l)};
				 polygons[index] = new polygon3D(t, t[3], t[0], t[2], main.textures[23], 8,1, 3); 
				 polygons[index].diffuse_I = I;
				 index++;
				 
				 t = new vector[]{put(0.27, -0.23, z-l), put(0.27, -0.23, z), put(-0.27, -0.23, z), put(-0.27, -0.23, z-l)};
				 polygons[index] = new polygon3D(t, t[3], t[0], t[2], main.textures[23], 8,1, 3); 
				 polygons[index].diffuse_I = 63;
				 index++;
				 
				 t = new vector[]{put(0.16, -0.231, z -0.01), put(0.161, -0.231, z -0.01), put(0.161, -0.32, z -0.01), put(0.16, -0.32, z -0.01)};
				 polygons[index] = new polygon3D(t, t[3], t[0], t[2], main.textures[23], 1,1, 3); 
				 polygons[index].diffuse_I = 0;
				 index++;
				 
				 t = new vector[]{put(0.16, -0.32, z -0.009), put(0.161, -0.32, z -0.009), put(0.161, -0.231, z -0.009), put(0.16, -0.231, z -0.009)};
				 polygons[index] = new polygon3D(t, t[3], t[0], t[2], main.textures[23], 1,1, 3); 
				 polygons[index].diffuse_I = 0;
				 index++;
				 
				 t = new vector[]{put(0.161, -0.231, z -0.01), put(0.161, -0.231, z -0.009), put(0.161, -0.32, z -0.009), put(0.161, -0.32, z -0.01)};
				 polygons[index] = new polygon3D(t, t[3], t[0], t[2], main.textures[23], 1,1, 3); 
				 polygons[index].diffuse_I = 0;
				 index++;
				 
				  t= new vector[]{put(0.16, -0.231, z -0.009), put(0.16, -0.231, z -0.01), put(0.16, -0.32, z -0.01), put(0.16, -0.32, z -0.009)};
				  polygons[index] = new polygon3D(t, t[3], t[0], t[2], main.textures[23], 1,1, 3); 
				  polygons[index].diffuse_I = 0;
				  index++;
				  
				  
				  t = new vector[]{put(-0.161, -0.231, z -0.01), put(-0.16, -0.231, z -0.01), put(-0.16, -0.32, z -0.01), put(-0.161, -0.32, z -0.01)};
				  polygons[index] = new polygon3D(t, t[3], t[0], t[2], main.textures[23], 1,1, 3); 
				  polygons[index].diffuse_I = 0;
				  index++;
					 
				  t = new vector[]{put(-0.161, -0.32, z -0.009), put(-0.16, -0.32, z -0.009), put(-0.16, -0.231, z -0.009), put(-0.161, -0.231, z -0.009)};
				  polygons[index] = new polygon3D(t, t[3], t[0], t[2], main.textures[23], 1,1, 3); 
				  polygons[index].diffuse_I = 0;
				  index++;
					 
				  t = new vector[]{put(-0.16, -0.231, z -0.01), put(-0.16, -0.231, z -0.009), put(-0.16, -0.32, z -0.009), put(-0.16, -0.32, z -0.01)};
				  polygons[index] = new polygon3D(t, t[3], t[0], t[2], main.textures[23], 1,1, 3); 
				  polygons[index].diffuse_I = 0;
				  index++;
					 
				  t= new vector[]{put(-0.161, -0.231, z -0.009), put(-0.161, -0.231, z -0.01), put(-0.161, -0.32, z -0.01), put(-0.161, -0.32, z -0.009)};
				  polygons[index] = new polygon3D(t, t[3], t[0], t[2], main.textures[23], 1,1, 3); 
				  polygons[index].diffuse_I = 0;
				  index++;			
			 }
			 
			 if(i != 7){
				 t = new vector[]{ put(-0.0149, 0.065, z - 0.147), put(0.0149, 0.065, z - 0.147), put(0.0149, 0.065, z - l),put(-0.0149, 0.065, z - l) };
				 polygons[index] = new polygon3D(t, t[3], t[0], t[2], main.textures[23], 8,1, 3); 
				 polygons[index].diffuse_I = 60;
				 index++;
			 }else{
				 t = new vector[]{ put(-0.0149, 0.065, z - 0.151), put(0.0149, 0.065, z - 0.151), put(0.0149, 0.065, z - l),put(-0.0149, 0.065, z - l) };
				 polygons[index] = new polygon3D(t, t[3], t[0], t[2], main.textures[23], 8,1, 3); 
				 polygons[index].diffuse_I = 60;
				 index++;
			 }
			 
			 t = new vector[]{put(0, 0.08 - h, z - l), put(0, 0.08 - h, z), put(-0.4 + w, -0.32, z), put(-0.4 + w, -0.32, z - l)};
			 polygons[index] = new polygon3D(t, t[3], t[0], t[2], main.textures[23], 8,1, 3); 
			 polygons[index].diffuse_I = I;
			 index++;
			 
			 t = new vector[]{put(0.4 - w, -0.32, z - l), put(0.4 - w, -0.32, z), put(0, 0.08 - h, z), put(0, 0.08 - h, z - l)};
			 polygons[index] = new polygon3D(t, t[3], t[0], t[2], main.textures[23], 8,1, 3); 
			 polygons[index].diffuse_I = I;
			 index++;
			 
			 
			 z -= 0.147;
			 I-=1;
		 }
		 
		 t = new vector[]{put(0, 0.08 - h, -0.6), put(0, 0.08 - h, -0.6+l), put(-0.4 + w, -0.32, -0.6+l), put(-0.4 + w, -0.32, -0.6)};
		 polygons[index] = new polygon3D(t, t[3], t[0], t[2], main.textures[23], 8,1, 3); 
		 polygons[index].diffuse_I = I;
		 index++;
		 
		 t = new vector[]{put(0.4 - w, -0.32, -0.6), put(0.4 - w, -0.32, -0.6+l), put(0, 0.08 - h, -0.6+l), put(0, 0.08 - h, -0.6)};
		 polygons[index] = new polygon3D(t, t[3], t[0], t[2], main.textures[23], 8,1, 3); 
		 polygons[index].diffuse_I = I;
		 index++;
		 
		 z = 0.6;
		 
		 for(int i = 0; i < 8; i ++){
			 
		 
			 t = new vector[]{put(-0.4, -0.32, z - l), put(-0.0149, 0.065, z - l), put(0, 0.065, z - l), put(0, 0.08 - h, z - l), put(-0.4 + w, -0.32, z - l)};
			 polygons[index] = new polygon3D(t, put(-0.4, -0.32, z - l), put(0, 0.08, z - l), put(-0.4 + w, -0.32, z - l), main.textures[23], 8,1, 3); 
			 polygons[index].diffuse_I = 40;
			 index++;
			 
			 t = new vector[]{put(0.4 -w, -0.32, z - l), put(0, 0.08 - h, z - l),  put(0, 0.065, z - l), put(0.0149, 0.065, z - l), put(0.4, -0.32, z - l) };
			 polygons[index] = new polygon3D(t, put(0.4 -w, -0.32, z - l), put(0, 0.08 - h, z - l), put(0.4, -0.32, z - l), main.textures[23], 8,1, 3); 
			 polygons[index].diffuse_I = 40;
			 index++;
			 
			 if( i == 2 || i ==4 || i == 6){
				 t = new vector[]{put(-0.24, -0.2, z-l), put(0.24, -0.2, z-l), put(0.27, -0.23, z-l), put(-0.27, -0.23, z-l)};
				 polygons[index] = new polygon3D(t, t[0], t[1], t[3], main.textures[23], 8,1, 3); 
				 polygons[index].diffuse_I = 40;
				 index++;
			 }
			 
			 z -= 0.147;
		 }
		 
		 t = new vector[]{put(0, 0.065, -0.6 + l), put(-0.0149, 0.065, -0.6 + l), put(-0.4, -0.32, -0.6 + l), put(-0.4 + w, -0.32, -0.6 + l), put(0, 0.08 - h, -0.6 + l)};
		 polygons[index] = new polygon3D(t, put(0, 0.08, -0.6 + l), put(-0.4, -0.32, -0.6 + l), put(0, 0.08 - h, -0.6 + l), main.textures[23], 8,1, 3); 
		 polygons[index].diffuse_I = 63;
		 index++;
		 
		 t = new vector[]{put(0, 0.065, -0.6 + l), put(0, 0.08 - h, -0.6 + l), put(0.4 - w, -0.32, -0.6 + l), put(0.4, -0.32, -0.6 + l), put(0.0149, 0.065, -0.6 + l)};
		 polygons[index] = new polygon3D(t, put(0, 0.08 - h, -0.6 + l), put(0.4 - w, -0.32, -0.6 + l), put(0, 0.08, -0.6 + l), main.textures[23], 8,1, 3); 
		 polygons[index].diffuse_I = 63;
		 index++;
		 
		 
		 for(int i = 0; i < 7; i++){
			 z += 0.147;
			 t = new vector[]{put(0, 0.065, z),put(-0.0149, 0.065, z),  put(-0.4, -0.32, z), put(-0.4 + w, -0.32, z), put(0, 0.08 - h, z)};
			 polygons[index] = new polygon3D(t, put(0, 0.08, z), put(-0.4, -0.32, z), put(0, 0.08 - h, z), main.textures[23], 8,1, 3); 
			 polygons[index].diffuse_I = 63;
			 index++;
			 
			 t = new vector[]{put(0, 0.065, z), put(0, 0.08 - h, z), put(0.4 - w, -0.32, z), put(0.4, -0.32, z), put(0.0149, 0.065, z)};
			 polygons[index] = new polygon3D(t, put(0, 0.08 - h, z), put(0.4 - w, -0.32, z), put(0, 0.08, z), main.textures[23], 8,1, 3); 
			 polygons[index].diffuse_I = 63;
			 index++;
			 
			 if( i == 1 || i ==3 || i == 5){
				 t = new vector[]{put(-0.27, -0.23, z), put(0.27, -0.23, z), put(0.24, -0.2, z), put(-0.24, -0.2, z)};
				 polygons[index] = new polygon3D(t, t[0], t[1], t[3], main.textures[23], 8,1, 3); 
				 polygons[index].diffuse_I = 63;
				 index++;
			 }
		 }
		 
		 for(int i = 2; i < polygons.length; i++){
			if(polygons[i].diffuse_I > 5)
				polygons[i].diffuse_I-=10;
		 }
		 
		 sortedPolygons = false;
		 sortIndexStart = 2;
		 
	}
	
	public void drawReflection(){}
}
